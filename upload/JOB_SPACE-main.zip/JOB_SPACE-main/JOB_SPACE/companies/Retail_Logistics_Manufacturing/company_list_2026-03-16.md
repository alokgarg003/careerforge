# Retail, Logistics & Manufacturing Companies

**Date:** 2026-03-16  
**Category:** Retail, Logistics & Manufacturing (Supply Chain Automation)  
**Focus:** Supply chain MFT  

## Company List
61. Tesco India – Already in Specialized_MFT_Integration
62. Walmart
63. Paychex – Already in Specialized_MFT_Integration
64. ADP
65. Dayton Parts
66. Schumann Printers
67. Airbus
68. ALSTOM
69. ABB
70. TJX Companies
71. Amazon (AWS Infrastructure Teams)
72. FedEx – Already in Sector_Specific_Fintech_Logistics
73. UPS
74. DHL – Already in Sector_Specific_Fintech_Logistics
75. Maersk
76. Home Depot
77. Target
78. Nike
79. Adidas
80. Coca-Cola

## Notes
- Supply chain automation with MFT.
- Logistics for tracking and data flow.