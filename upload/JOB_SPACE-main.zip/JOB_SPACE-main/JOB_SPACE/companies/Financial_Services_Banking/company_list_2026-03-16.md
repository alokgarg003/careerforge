# Financial Services & Banking Companies

**Date:** 2026-03-16  
**Category:** Financial Services & Banking (High Demand for MFT)  
**Focus:** Secure transactions and compliance  

## Company List
1. LSEG (London Stock Exchange Group) – Already in Specialized_MFT_Integration
2. American Express Global Business Travel – Already in Sector_Specific_Fintech_Logistics
3. IG Group – Already in Specialized_MFT_Integration
4. Société Générale – Already in Sector_Specific_Fintech_Logistics
5. Fidelity International
6. Alliant Credit Union
7. Think Mutual Bank
8. FPS Gold
9. Barclays
10. HSBC
11. JPMorgan Chase
12. Standard Chartered
13. Goldman Sachs
14. Morgan Stanley
15. Deutsche Bank
16. Wells Fargo
17. Bank of America
18. BNY Mellon
19. Northern Trust
20. State Street

## Notes
- These organizations use MFT for secure transactions.
- Many have remote opportunities.
- Focus on GoAnywhere MFT roles.