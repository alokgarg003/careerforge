#purana code



#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Incident Partitions Dashboard – Enhanced UI/UX
----------------------------------------------
A self-explanatory, insight-first dashboard to explore outputs of partition_incidents.py
under outputs_partitioned/, filter interactively, visualize trends, and download.

Run:
  streamlit run app.py
"""

from __future__ import annotations

from pathlib import Path
import re
import io
import math
from typing import Optional, Tuple, List

import pandas as pd
import numpy as np
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go  # for Sankey & dual-axis Pareto

# ---------- Config ----------
DEFAULT_OUT_ROOT = Path("outputs_partitioned")
GROUPS_ORDER = [
    "stuck-files", "ftp-errors", "config-file", "err-file-remove",
    "callout/mfterr03", "callout/mfterr04", "process-alert", "warnings", "misc"
]
PREVIEW_LIMIT = 10000  # max rows to display in table for performance
PX_THEME = "plotly"    # "plotly_dark" if you prefer; toggleable in UI
HEATMAP_DOW_ORDER = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]

# ---------- Page setup ----------
st.set_page_config(
    page_title="Incident Partitions Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)
st.markdown(
    """
    <style>
    /* tighten spacing & improve readability */
    .block-container { padding-top: 1rem; padding-bottom: 2rem; }
    .stMetric { text-align: center; }
    .caption { color: #6b7280; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------- Cached IO helpers ----------
@st.cache_data(ttl=300, show_spinner=False)
def list_runs(out_root: Path) -> list[Path]:
    if not out_root.exists():
        return []
    runs = sorted([p for p in out_root.iterdir() if p.is_dir() and p.name.startswith("run_")])
    return runs[::-1]  # newest first

@st.cache_data(ttl=300)
def read_summary(run_dir: Path) -> pd.DataFrame:
    p = run_dir / "_logs" / "summary.csv"
    if not p.exists():
        return pd.DataFrame(columns=["group", "count", "total_rows", "coverage_pct"])
    df = pd.read_csv(p)
    df["group"] = df["group"].astype(str)
    df.loc[df["group"].str.startswith("callout_"), "group"] = df["group"].str.replace("callout_", "callout/", regex=False)
    return df

def safe_glob_excel_or_csv(group_dir: Path, base_prefix: str = "ALL_") -> Optional[Path]:
    xl = list(group_dir.glob(f"{base_prefix}*.xlsx"))
    if xl: return xl[0]
    cs = list(group_dir.glob(f"{base_prefix}*.csv"))
    if cs: return cs[0]
    return None

@st.cache_data(ttl=300)
def load_group_df(run_dir: Path, group_key: str) -> pd.DataFrame:
    if group_key.startswith("callout/"):
        sub = group_key.split("/", 1)[1]  # mfterr03 or mfterr04
        group_dir = run_dir / "callout" / sub
    else:
        group_dir = run_dir / group_key
    path = safe_glob_excel_or_csv(group_dir)
    if not path:
        return pd.DataFrame()
    if path.suffix.lower() == ".xlsx":
        return pd.read_excel(path, engine="openpyxl")
    return pd.read_csv(path)

def parse_opened_to_datetime(s: pd.Series) -> pd.Series:
    if s is None:
        return pd.Series(dtype="datetime64[ns]")
    dt = pd.to_datetime(s, errors="coerce")
    if dt.notna().sum() > 0:
        return dt
    try:
        return pd.to_datetime(s, unit="d", origin="1899-12-30", errors="coerce")
    except Exception:
        return pd.to_datetime(s, errors="coerce")

def add_time_grains(df: pd.DataFrame) -> pd.DataFrame:
    if "Opened" in df.columns:
        dt = parse_opened_to_datetime(df["Opened"])
        df["Opened_dt"] = dt
        df["month"] = dt.dt.to_period("M").astype(str)
        df["date"] = dt.dt.date
        df["dow"] = dt.dt.day_name()
        df["hour"] = dt.dt.hour
    return df

def build_pareto_df(s: pd.Series) -> pd.DataFrame:
    top = s.value_counts().head(20)
    df = top.reset_index()
    df.columns = ["value", "count"]
    total = df["count"].sum()
    df["cum_pct"] = df["count"].cumsum() / total * 100.0 if total else 0.0
    return df

def filter_df(
    df: pd.DataFrame,
    interface: Optional[str],
    errfam: Optional[str],
    ftp_cmd: Optional[str],
    ftp_code: Optional[str],
    text_query: Optional[str],
    month_sel: Optional[List[str]],
    dow_sel: Optional[List[str]],
    hour_range: Optional[Tuple[int, int]],
) -> pd.DataFrame:
    if df.empty:
        return df
    m = pd.Series(True, index=df.index)
    if interface and "primary_interface" in df.columns:
        m &= (df["primary_interface"].astype(str) == interface)
    if errfam and "error_family" in df.columns:
        m &= (df["error_family"].astype(str) == errfam)
    if ftp_cmd and "ftp_command" in df.columns:
        m &= (df["ftp_command"].astype(str).str.upper() == ftp_cmd.upper())
    if ftp_code and "ftp_code" in df.columns:
        m &= (df["ftp_code"].astype(str) == ftp_code)
    if text_query:
        q = text_query.strip()
        cols = [c for c in ["Short description", "paths", "error_codes", "Resolution notes"] if c in df.columns]
        if cols:
            t = pd.concat([df[c].astype(str) for c in cols], axis=1).agg(" ".join, axis=1)
            m &= t.str.contains(re.escape(q), case=False, na=False)
    if "month" in df.columns and month_sel:
        m &= df["month"].isin(month_sel)
    if "dow" in df.columns and dow_sel:
        m &= df["dow"].isin(dow_sel)
    if "hour" in df.columns and hour_range:
        lo, hi = hour_range
        m &= df["hour"].between(int(lo), int(hi))
    return df[m]

# ---------- Unique Paths helpers ----------
@st.cache_data(ttl=300)
def _load_unique_paths_csv(root_dir: Path) -> pd.DataFrame:
    """
    Locate and load unique_paths_all.csv produced by the extractor.
    Search in common locations to be resilient.
    """
    candidates = [
        Path("unique_outputs/unique_paths_all.csv"),
        root_dir.parent / "unique_outputs" / "unique_paths_all.csv",
        root_dir / "unique_paths_all.csv",
    ]
    for p in candidates:
        if p.exists():
            try:
                return pd.read_csv(p)
            except Exception:
                pass
    return pd.DataFrame(columns=["path","incident_count","configuration_items","error_families","top_primary_interfaces"])

def _filter_unique_paths(
    up_df: pd.DataFrame,
    path_prefix: Optional[str],
    min_incidents: Optional[int],
    ci_sel: Optional[str],
    fam_sel: Optional[str],
    text_query: Optional[str],
) -> pd.DataFrame:
    if up_df.empty:
        return up_df
    m = pd.Series(True, index=up_df.index)
    if path_prefix:
        m &= up_df["path"].astype(str).str.startswith(path_prefix.strip())
    if min_incidents is not None:
        try:
            m &= pd.to_numeric(up_df["incident_count"], errors="coerce").fillna(0) >= int(min_incidents)
        except Exception:
            pass
    if ci_sel and ci_sel != "(any)":
        m &= up_df["configuration_items"].astype(str).str.contains(re.escape(ci_sel), case=False, na=False)
    if fam_sel and fam_sel != "(any)":
        m &= up_df["error_families"].astype(str).str.contains(re.escape(fam_sel), case=False, na=False)
    if text_query:
        q = text_query.strip()
        pool_cols = [c for c in ["path","configuration_items","error_families","top_primary_interfaces"] if c in up_df.columns]
        if pool_cols:
            t = up_df[pool_cols].astype(str).agg(" ".join, axis=1)
            m &= t.str.contains(re.escape(q), case=False, na=False)
    return up_df[m]

def _drill_through_group(df_group: pd.DataFrame, selected_path: str) -> pd.DataFrame:
    """
    Find incidents in the currently opened group (df) that reference the selected path.
    Match on 'paths' if present, else fallback to 'Short description'/'Resolution notes'.
    """
    if df_group is None or len(df_group) == 0 or not selected_path:
        return pd.DataFrame()
    m = pd.Series(False, index=df_group.index)
    if "paths" in df_group.columns:
        m |= df_group["paths"].astype(str).str.contains(re.escape(selected_path), case=False, na=False)
    if "Short description" in df_group.columns:
        m |= df_group["Short description"].astype(str).str.contains(re.escape(selected_path), case=False, na=False)
    if "Resolution notes" in df_group.columns:
        m |= df_group["Resolution notes"].astype(str).str.contains(re.escape(selected_path), case=False, na=False)
    return df_group[m]

# ---------- Sidebar: global controls ----------
st.sidebar.title("Controls")
root_input = st.sidebar.text_input("Output root folder", str(DEFAULT_OUT_ROOT))
out_root = Path(root_input).resolve()
runs = list_runs(out_root)
if not runs:
    st.warning(f"No runs found under: {out_root}\n\nRun the partitioner first.")
    st.stop()

run_names = [r.name for r in runs]
sel_run_name = st.sidebar.selectbox("Select run", run_names, index=0)
sel_run = out_root / sel_run_name

# Theme toggle for plotly visuals
dark_toggle = st.sidebar.toggle("Dark visuals", value=False, help="Toggle Plotly dark theme")
px_template = "plotly_dark" if dark_toggle else PX_THEME

# ---------- Load summary & build tabs ----------
summary = read_summary(sel_run)

st.title("Incident Partitions Dashboard")
st.caption("Explore grouped outputs from `partition_incidents.py` — filter, visualize, and download.")

tab_overview, tab_group, tab_unique, tab_insights, tab_export = st.tabs(
    ["Overview", "Analyze Group", "Unique Paths", "Insights & Trends", "Export"]
)

# ================================
# Tab: Overview
# ================================
with tab_overview:
    col1, col2 = st.columns([2, 1], gap="large")
    with col1:
        if len(summary) > 0:
            # Respect preferred group order; fill missing gracefully
            order = [g for g in GROUPS_ORDER if g in summary["group"].tolist()]
            fig_sum = px.bar(
                summary.sort_values("group", key=lambda x: x.map({v:i for i,v in enumerate(order)}).fillna(999)),
                x="group", y="count",
                title="Counts by group",
                text_auto=True,
                template=px_template,
            )
            fig_sum.update_traces(marker_color="#4f46e5")
            fig_sum.update_layout(xaxis_title=None, yaxis_title="Incident count")
            st.plotly_chart(fig_sum, use_container_width=True)
        else:
            st.info("No summary.csv found for this run.")

    with col2:
        if "coverage_pct" in summary.columns and len(summary) > 0:
            cov = float(summary["coverage_pct"].iloc[0])
            total = int(summary["total_rows"].iloc[0])
            st.metric("Total rows (all groups)", value=f"{total:,}")
            st.metric("Coverage (non-misc)", value=f"{cov:.1f}%")
            # Donut for misc vs non-misc
            try:
                misc_count = int(summary.loc[summary["group"] == "misc", "count"].sum())
                non_misc = total - misc_count
                fig_cov = px.pie(
                    names=["Non-misc", "Misc"],
                    values=[non_misc, misc_count],
                    hole=0.5,
                    title="Coverage breakdown",
                    template=px_template,
                    color_discrete_sequence=["#10b981", "#ef4444"],
                )
                st.plotly_chart(fig_cov, use_container_width=True)
            except Exception:
                pass
        st.caption(f"Run path: {sel_run}")

# ================================
# Tab: Analyze Group
# ================================
with tab_group:
    group_key = st.selectbox("Open group", GROUPS_ORDER, index=0, help="Choose a group to explore")
    df = load_group_df(sel_run, group_key)
    if df.empty:
        st.warning("No data file found in this group.")
        st.stop()
    df = add_time_grains(df)

    # Sidebar-like filters inline for discoverability (still using sidebar for global)
    st.subheader(f"Group: {group_key}")
    st.caption("Use filters to refine; visuals update live.")
    filt1, filt2, filt3, filt4 = st.columns(4)

    iface_opt = sorted(pd.unique(df["primary_interface"].dropna())) if "primary_interface" in df.columns else []
    errfam_opt = sorted(pd.unique(df["error_family"].dropna())) if "error_family" in df.columns else []
    ftp_cmd_opt = sorted(pd.unique(df["ftp_command"].dropna())) if "ftp_command" in df.columns else []
    ftp_code_opt = sorted(pd.unique(df["ftp_code"].dropna())) if "ftp_code" in df.columns else []

    with filt1:
        iface_sel = st.selectbox("Primary interface", ["(any)"] + iface_opt) if iface_opt else None
    with filt2:
        errfam_sel = st.selectbox("Error family", ["(any)"] + errfam_opt) if errfam_opt else None
    with filt3:
        ftp_cmd_sel = st.selectbox("FTP verb", ["(any)"] + ftp_cmd_opt) if ftp_cmd_opt else None
    with filt4:
        ftp_code_sel = st.selectbox("FTP code", ["(any)"] + ftp_code_opt) if ftp_code_opt else None

    text_query = st.text_input("Search text (Short description / paths / codes / resolution)")

    col_a, col_b, col_c = st.columns([1.2, 1.2, 1])
    month_opt = sorted(pd.unique(df["month"].dropna())) if "month" in df.columns else []
    dow_opt = HEATMAP_DOW_ORDER if "dow" in df.columns else []
    with col_a:
        month_sel = st.multiselect("Months", month_opt) if month_opt else []
    with col_b:
        dow_sel = st.multiselect("Days of week", dow_opt) if dow_opt else []
    with col_c:
        hour_range = st.slider("Hour range", 0, 23, (0, 23)) if "hour" in df.columns else None

    # Apply filters
    df_f = filter_df(
        df,
        interface=None if not iface_sel or iface_sel == "(any)" else iface_sel,
        errfam=None if not errfam_sel or errfam_sel == "(any)" else errfam_sel,
        ftp_cmd=None if not ftp_cmd_sel or ftp_cmd_sel == "(any)" else ftp_cmd_sel,
        ftp_code=None if not ftp_code_sel or ftp_code_sel == "(any)" else ftp_code_sel,
        text_query=text_query,
        month_sel=month_sel,
        dow_sel=dow_sel,
        hour_range=hour_range,
    )
    st.success(f"Filtered rows: {len(df_f):,} / {len(df):,}")

    # Quick insights text
    if "error_family" in df_f.columns and len(df_f) > 0:
        pareto_df = build_pareto_df(df_f["error_family"].dropna())
        top3_pct = (pareto_df["count"].head(3).sum() / max(pareto_df["count"].sum(), 1)) * 100
        st.caption(f"ℹ️ Top 3 error families account for {top3_pct:.1f}% of filtered incidents.")

    # Visuals row 1: interfaces & error family Pareto
    c1, c2 = st.columns(2)
    with c1:
        if "primary_interface" in df_f.columns:
            s = df_f["primary_interface"].dropna()
            if len(s) > 0:
                fig = px.bar(
                    s.value_counts().head(20),
                    title="Top interfaces (count)",
                    template=px_template
                )
                fig.update_traces(marker_color="#0ea5e9")
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No primary_interface values after filters.")
        else:
            st.info("Column 'primary_interface' not present.")

    with c2:
        if "error_family" in df_f.columns:
            p = build_pareto_df(df_f["error_family"].dropna())
            if len(p) > 0:
                fig = go.Figure()
                fig.add_bar(x=p["value"], y=p["count"], name="Count", marker_color="#f59e0b")
                fig.add_trace(
                    go.Scatter(
                        x=p["value"],
                        y=p["cum_pct"],
                        name="Cumulative %",
                        yaxis="y2",
                        mode="lines+markers",
                        line=dict(color="#22c55e", width=2)
                    )
                )
                fig.update_layout(
                    title="Error family Pareto (top 20)",
                    xaxis_title="error_family",
                    yaxis_title="Count",
                    template=px_template,
                    yaxis2=dict(title="Cumulative %", overlaying="y", side="right", range=[0, 100])
                )
                st.plotly_chart(fig, use_container_width=True)
                st.caption(f"Cumulative %: {p['cum_pct'].iloc[-1]:.1f}%")
            else:
                st.info("No error_family values after filters.")
        else:
            st.info("Column 'error_family' not present.")

    # Visuals row 2: Stuck metrics & Hour heatmap
    c3, c4 = st.columns(2)
    with c3:
        if "stuck_files_count" in df_f.columns or "stuck_for_minutes" in df_f.columns:
            sub = pd.DataFrame({
                "stuck_files_count": df_f.get("stuck_files_count", pd.Series(dtype=float)),
                "stuck_for_minutes": df_f.get("stuck_for_minutes", pd.Series(dtype=float)),
                "error_family": df_f.get("error_family", pd.Series(dtype=str)),
            })
            sub = sub.dropna(how="all")
            if len(sub) > 0:
                fig = px.histogram(sub, x="stuck_files_count", nbins=30, title="Distribution: stuck_files_count", template=px_template)
                st.plotly_chart(fig, use_container_width=True)
                if "stuck_for_minutes" in sub.columns and sub["stuck_for_minutes"].notna().sum() > 0:
                    fig2 = px.box(
                        sub.dropna(subset=["stuck_for_minutes"]),
                        x="error_family" if "error_family" in sub.columns else None,
                        y="stuck_for_minutes",
                        title="Stuck duration by error family (box plot)",
                        template=px_template
                    )
                    st.plotly_chart(fig2, use_container_width=True)
            else:
                st.info("No stuck metrics present after filters.")
        else:
            st.info("No stuck metrics columns present.")

    with c4:
        if all(c in df_f.columns for c in ["dow", "hour"]):
            pivot = df_f.pivot_table(index="dow", columns="hour", values=df_f.columns[0], aggfunc="count").fillna(0)
            pivot = pivot.reindex(HEATMAP_DOW_ORDER)
            fig = px.imshow(
                pivot.values,
                labels=dict(x="hour", y="day", color="count"),
                x=list(pivot.columns),
                y=list(pivot.index),
                aspect="auto",
                title="Hour-of-day heatmap (filtered)",
                template=px_template,
                color_continuous_scale="Blues" if not dark_toggle else "Viridis",
            )
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("Time grains unavailable; cannot render hour-of-day heatmap.")

    # Visuals row 3: Time trends & hierarchy
    c5, c6 = st.columns(2)
    with c5:
        if "month" in df_f.columns:
            ts = df_f.groupby("month").size().reset_index(name="count").sort_values("month")
            fig_ts = px.line(ts, x="month", y="count", markers=True, title="Monthly trend (filtered)", template=px_template)
            fig_ts.update_traces(line=dict(color="#7c3aed"))
            st.plotly_chart(fig_ts, use_container_width=True)
            # Animated top interfaces by month
            if "primary_interface" in df_f.columns:
                anim = (df_f.dropna(subset=["month", "primary_interface"])
                        .groupby(["month", "primary_interface"])
                        .size()
                        .reset_index(name="count"))
                fig_anim = px.bar(
                    anim.sort_values("count", ascending=False),
                    x="primary_interface", y="count",
                    color="primary_interface",
                    animation_frame="month",
                    title="Top interfaces by month (animated)",
                    template=px_template
                )
                fig_anim.update_layout(xaxis={'categoryorder':'total descending'})
                st.plotly_chart(fig_anim, use_container_width=True)
    with c6:
        # Sunburst error_family -> primary_interface -> ftp_command
        cols = [c in df_f.columns for c in ["error_family","primary_interface","ftp_command"]]
        if all(cols) and len(df_f) > 0:
            sb = df_f[["error_family","primary_interface","ftp_command"]].dropna()
            sb["count"] = 1
            fig_sb = px.sunburst(
                sb,
                path=["error_family","primary_interface","ftp_command"],
                values="count",
                title="Hierarchy: error → interface → FTP verb",
                template=px_template
            )
            st.plotly_chart(fig_sb, use_container_width=True)
        else:
            st.info("Sunburst needs columns: error_family, primary_interface, ftp_command.")

        # Optional Sankey: ftp_command -> ftp_code -> error_family
        if all(c in df_f.columns for c in ["ftp_command","ftp_code","error_family"]) and len(df_f) > 0:
            sank = df_f[["ftp_command","ftp_code","error_family"]].dropna()
            sank["count"] = 1
            by = sank.groupby(["ftp_command","ftp_code","error_family"])["count"].sum().reset_index()
            labels = pd.Index(pd.unique(by[["ftp_command","ftp_code","error_family"]].values.ravel())).tolist()
            label_idx = {l:i for i,l in enumerate(labels)}
            sources = by["ftp_command"].map(label_idx)
            mids = by["ftp_code"].map(label_idx)
            targets = by["error_family"].map(label_idx)
            # create two sets of links: command->code and code->family
            link_src = pd.concat([sources, mids], ignore_index=True)
            link_tgt = pd.concat([mids, targets], ignore_index=True)
            link_val = pd.concat([by["count"], by["count"]], ignore_index=True)
            fig_sk = go.Figure(data=[go.Sankey(
                node=dict(label=labels, pad=15, thickness=20),
                link=dict(source=link_src, target=link_tgt, value=link_val)
            )])
            fig_sk.update_layout(title_text="Flow: FTP verb → code → error family", template=px_template)
            st.plotly_chart(fig_sk, use_container_width=True)

    st.divider()
    # Table preview & download
    st.markdown("### Table preview")
    st.dataframe(df_f.head(PREVIEW_LIMIT), use_container_width=True, height=400)

    # Download filtered as CSV
    csv_bytes = df_f.to_csv(index=False).encode("utf-8")
    st.download_button("Download filtered CSV", data=csv_bytes, file_name=f"{group_key}_filtered.csv", mime="text/csv")

# ================================
# Tab: Unique Paths Explorer
# ================================
with tab_unique:
    st.markdown("### 🔎 Unique Paths Explorer (from unique_paths_all.csv)")
    up_df = _load_unique_paths_csv(out_root)

    if up_df.empty:
        st.info(
            "No `unique_paths_all.csv` found.\n\n"
            "Generate it with:\n"
            "  .\\.venv\\Scripts\\python.exe .\\extract_unique_paths.py --input .\\ALL_stuck-files.xlsx --out-dir .\\unique_outputs\n\n"
            "Or point the extractor to a specific group file:\n"
            "  --input .\\outputs_partitioned\\run_YYYY-MM-DD_HH-MM-SS\\stuck-files\\ALL_stuck-files.xlsx --sheet data\n"
        )
    else:
        # Filters row
        col_f1, col_f2, col_f3 = st.columns([1.6, 1.1, 1.3])
        with col_f1:
            path_prefix = st.text_input("Path starts with", value="/var/opt/transfers", help="Filter to a path prefix (e.g., /var/opt/transfers)")
        with col_f2:
            min_inc = st.number_input("Min incident count", min_value=0, value=50, step=5)
        with col_f3:
            txt = st.text_input("Search (path/CI/family/interfaces)")

        # Choices for CI and Family
        ci_choices = sorted(
            set(
                x.strip()
                for s in up_df["configuration_items"].dropna().astype(str).tolist()
                for x in s.split(";")
                if x.strip()
            )
        )
        fam_choices = sorted(
            set(
                x.strip()
                for s in up_df["error_families"].dropna().astype(str).tolist()
                for x in s.split(";")
                if x.strip()
            )
        )

        col_f4, col_f5 = st.columns(2)
        with col_f4:
            ci_sel = st.selectbox("Configuration item", ["(any)"] + ci_choices) if ci_choices else "(any)"
        with col_f5:
            fam_sel = st.selectbox("Error family", ["(any)"] + fam_choices) if fam_choices else "(any)"

        up_f = _filter_unique_paths(up_df, path_prefix, min_inc, ci_sel, fam_sel, txt)

        st.markdown("#### Top Paths by Incident Count")
        if len(up_f) > 0:
            fig_up = px.bar(
                up_f.sort_values("incident_count", ascending=False).head(30),
                x="incident_count",
                y="path",
                orientation="h",
                title="Top unique paths (filtered)",
                text_auto=True,
                template=px_template,
            )
            fig_up.update_layout(xaxis_title="Incident count", yaxis_title=None)
            st.plotly_chart(fig_up, use_container_width=True)
        else:
            st.info("No rows after filters.")

        # Table & download
        st.markdown("#### Unique Paths — Table")
        st.dataframe(up_f.head(PREVIEW_LIMIT), use_container_width=True, height=380)
        buf = io.BytesIO(up_f.to_csv(index=False).encode("utf-8"))
        st.download_button(
            "Download filtered unique paths (CSV)",
            data=buf,
            file_name="unique_paths_filtered.csv",
            mime="text/csv",
            use_container_width=True,
        )

        # Drill-through to current group
        st.markdown("#### Drill-through: Show matching incidents in the current group")
        path_pick = st.selectbox(
            "Choose a path to drill-through",
            options=["(select)"] + up_f["path"].astype(str).tolist(),
            index=0,
        )
        # Helper to apply as filter on Analyze Group tab
        if path_pick and path_pick != "(select)":
            st.button("Apply this path as text filter in Analyze Group", help="Copy selected path to the group text filter",
                      on_click=lambda: st.session_state.__setitem__('text_query_prefill', path_pick))
            df_drill = _drill_through_group(load_group_df(sel_run, GROUPS_ORDER[0]), path_pick)  # slight sample; main drill uses df below
            df_drill = _drill_through_group(df, path_pick)  # use currently loaded group
            cnt = len(df_drill)
            st.metric("Matching incidents in group", value=f"{cnt:,}")
            if cnt > 0:
                st.dataframe(df_drill.head(PREVIEW_LIMIT), use_container_width=True, height=380)
                buf2 = io.BytesIO(df_drill.to_csv(index=False).encode("utf-8"))
                st.download_button(
                    "Download drill-through incidents (CSV)",
                    data=buf2,
                    file_name=f"{group_key}_drill_{Path(path_pick).name}.csv",
                    mime="text/csv",
                    use_container_width=True,
                )
            else:
                st.info("No incidents in this group reference the selected path.")

# ================================
# Tab: Insights & Trends (auto-explain)
# ================================
with tab_insights:
    st.markdown("### Auto Insights")
    st.caption("Quick, self-explanatory highlights derived from the selected group & filters.")
    # We reuse df_f from Analyze Group tab if present; else compute with defaults.
    try:
        df_f  # noqa: F821
    except NameError:
        df = load_group_df(sel_run, GROUPS_ORDER[0])
        df = add_time_grains(df)
        df_f = df

    if df_f.empty:
        st.info("No data to generate insights.")
    else:
        bullets = []
        # Insight 1: busiest month/day/hour
        if "month" in df_f.columns and df_f["month"].notna().any():
            top_month = df_f["month"].value_counts().idxmax()
            bullets.append(f"**Busiest month:** `{top_month}` by incident volume.")
        if "dow" in df_f.columns and df_f["dow"].notna().any():
            top_dow = df_f["dow"].value_counts().idxmax()
            bullets.append(f"**Busiest weekday:** `{top_dow}` for incident occurrence.")
        if "hour" in df_f.columns and df_f["hour"].notna().any():
            top_hour = int(df_f["hour"].value_counts().idxmax())
            bullets.append(f"**Peak hour:** `{top_hour:02d}:00` (local server time).")

        # Insight 2: top interface & error family
        if "primary_interface" in df_f.columns and df_f["primary_interface"].notna().any():
            top_iface = df_f["primary_interface"].value_counts().idxmax()
            bullets.append(f"**Top interface:** `{top_iface}` appears most frequently.")
        if "error_family" in df_f.columns and df_f["error_family"].notna().any():
            top_err = df_f["error_family"].value_counts().idxmax()
            bullets.append(f"**Dominant error family:** `{top_err}`.")

        # Insight 3: stuck duration statistics
        if "stuck_for_minutes" in df_f.columns:
            s = pd.to_numeric(df_f["stuck_for_minutes"], errors="coerce").dropna()
            if len(s) > 0:
                bullets.append(f"**Stuck duration (median):** {int(s.median())} minutes; **95th percentile:** {int(s.quantile(0.95))} minutes.")

        # Insight 4: FTP code contribution
        if "ftp_code" in df_f.columns:
            vc = df_f["ftp_code"].astype(str).value_counts()
            if len(vc) > 0:
                top_code, top_code_cnt = vc.index[0], vc.iloc[0]
                bullets.append(f"**Leading FTP code:** `{top_code}` (count {top_code_cnt:,}).")

        st.markdown("\n".join([f"- {b}" for b in bullets]) or "No insights available.")

        st.divider()
        # Correlation heatmap (numeric columns)
        num_cols = df_f.select_dtypes(include=[np.number]).columns.tolist()
        if len(num_cols) >= 2:
            corr = df_f[num_cols].corr(numeric_only=True)
            fig_corr = px.imshow(
                corr.values,
                x=list(corr.columns),
                y=list(corr.index),
                color_continuous_scale="RdBu",
                zmin=-1, zmax=1,
                template=px_template,
                title="Correlation heatmap (numeric columns)"
            )
            st.plotly_chart(fig_corr, use_container_width=True)
        else:
            st.info("Not enough numeric columns to compute correlation heatmap.")

# ================================
# Tab: Export
# ================================
with tab_export:
    st.markdown("### Export & Sharing")
    st.caption("Download filtered data and auto-generated summary for reporting.")

    try:
        df_f  # noqa: F821
    except NameError:
        df = load_group_df(sel_run, GROUPS_ORDER[0])
        df = add_time_grains(df)
        df_f = df

    exp1, exp2 = st.columns([1.2, 1])
    with exp1:
        # CSV download
        st.download_button(
            "Download filtered CSV",
            data=df_f.to_csv(index=False).encode("utf-8"),
            file_name=f"{group_key}_filtered.csv",
            mime="text/csv",
            use_container_width=True,
        )
        # Excel download (multi-sheet)
        try:
            buf_xlsx = io.BytesIO()
            with pd.ExcelWriter(buf_xlsx, engine="openpyxl") as writer:
                df_f.to_excel(writer, index=False, sheet_name="filtered")
                # Add small pivot sheets if available
                if "error_family" in df_f.columns:
                    df_f["__count__"] = 1
                    piv_err = df_f.pivot_table(index="error_family", values="__count__", aggfunc="count").sort_values("__count__", ascending=False)
                    piv_err.to_excel(writer, sheet_name="error_family_pivot")
                if "primary_interface" in df_f.columns:
                    piv_if = df_f.pivot_table(index="primary_interface", values="__count__", aggfunc="count").sort_values("__count__", ascending=False)
                    piv_if.to_excel(writer, sheet_name="interface_pivot")
            st.download_button(
                "Download filtered Excel (multi-sheet)",
                data=buf_xlsx.getvalue(),
                file_name=f"{group_key}_filtered.xlsx",
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                use_container_width=True,
            )
        except Exception as e:
            st.warning(f"Excel export not available: {e}")

    with exp2:
        # Markdown summary
        md_lines = [
            f"# Incident Summary – {group_key}",
            f"- Run: `{sel_run_name}`",
            f"- Rows (filtered/total): **{len(df_f):,} / {len(df):,}**",
        ]
        if "month" in df_f.columns and df_f["month"].notna().any():
            md_lines.append(f"- Busiest month: **{df_f['month'].value_counts().idxmax()}**")
        if "dow" in df_f.columns and df_f["dow"].notna().any():
            md_lines.append(f"- Busiest weekday: **{df_f['dow'].value_counts().idxmax()}**")
        if "primary_interface" in df_f.columns and df_f["primary_interface"].notna().any():
            md_lines.append(f"- Top interface: **{df_f['primary_interface'].value_counts().idxmax()}**")
        if "error_family" in df_f.columns and df_f["error_family"].notna().any():
            md_lines.append(f"- Dominant error family: **{df_f['error_family'].value_counts().idxmax()}**")
        md_text = "\n".join(md_lines)
        st.download_button(
            "Download Markdown summary",
            data=md_text.encode("utf-8"),
            file_name=f"{group_key}_summary.md",
            mime="text/markdown",
            use_container_width=True,
        )

# Preserve caption
st.caption(f"Run folder: {sel_run}")
