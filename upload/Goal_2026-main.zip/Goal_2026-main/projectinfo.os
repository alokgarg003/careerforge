# Project Document: CareerForge OS

## Document Overview
This document presents an enhanced prototype version of your original idea, evolving from a simple LinkedIn ZIP parser into a comprehensive, privacy-first "Personal Intelligence OS" for solo users (especially developers and job seekers). It incorporates all discussions from our conversation history, including:
- Initial 2026 vision (privacy-first platform, AI/LLM integration, recommendations, free/premium tiers).
- Local-first redesign (offline, solo-use, avoiding API dependencies).
- Job matching with skills (using free APIs/scraping).
- Resume parsing, scoring, and ATS regeneration.
- Input parsing for intelligent commands (YAML structure).
- Gmail cleanup/automation (exporting, unsubscribing, labeling).
- Job application automation (prep for LinkedIn/Workday, AI answers).

The prototype is designed as a v1 MVP for your personal use, fully local (browser/Electron), with future scalability in mind. I've rethought pains like inbox overload and application tedium, enhancing for efficiency while solving real solo-user problems (e.g., time waste, decision fatigue).

This is a self-contained prototype spec—ready for you to implement or demo. It includes end-to-end understanding, pipeline, and detailed implementation steps/code snippets grounded in your existing React/Vite codebase.

---

## Project Name
**CareerForge OS**  
- **Rationale**: "Career" reflects the focus on professional growth/job hunting. "Forge" evokes building/forging your path (like blacksmithing tools from raw data). "OS" (Operating System) positions it as an intelligent "system" for career management—your personal command center.

---

## Project Intent
CareerForge OS is a privacy-first, local-first application that empowers solo users (e.g., developers, freshers, or anyone job-hunting) to transform their professional data (LinkedIn exports, resumes, emails) into actionable intelligence. The intent is to eliminate "hectic" manual workflows—parsing data, finding jobs, optimizing resumes, cleaning inboxes, and prepping applications—using free/open-source tools and local AI.

- **Core Philosophy**: Assume good intent from users; treat them as capable adults without lecturing. Focus on empowerment: No data leaves your device, no paid APIs/tokens, minimal dependencies. It's your "secret weapon" for career mapping, starting as a solo tool to attract audience/showcase your thinking.
- **Target User**: Solo devs/job seekers like you—excited about AI but frustrated by limits/stuck points. It solves isolation by automating tedium, giving clarity (e.g., "whom to connect," "what jobs match").

---

## Problems Solved and Future Use
### Problems Solved (Current Pain Points Addressed)
From our discussions, CareerForge OS tackles these solo-user irritations:
1. **Data Overload & Lack of Insights**: LinkedIn ZIPs are raw CSVs—hard to visualize/analyze. Solves: Auto-parses, visualizes (charts/filters), AI suggests (e.g., reconnection mapping).
2. **Job Hunting Hectic**: Manual searching/applying on LinkedIn/Workday (forms, questions, email verifies). Solves: Skill-based job fetching (APIs/scraping), AI-prepped answers/resumes, application tracking.
3. **Resume Frustrations**: Non-ATS formats get rejected; scoring gaps unknown. Solves: Local parse/score/regenerate with job keywords.
4. **Inbox Chaos**: Overflowing Gmail (subscriptions, alerts) hides real emails. Solves: Export to CSV (with sender/details), auto-unsubscribe/label/clean.
5. **Input/Output Mess**: Vague AI tools waste time/tokens. Solves: Structured YAML inputs for precise commands, chaining actions.
6. **Dependency Risks**: Paid APIs/token limits. Solves: Local LLM (Ollama), free APIs, offline fallbacks.

Overall: Reduces burnout—turns hours of manual work into minutes of intelligent automation.

### Future Use and Enhancements
- **Short-Term (Month 2-3)**: Open-source on GitHub for audience (devs/founders). Add premium tiers (e.g., pay-per-use advanced AI via hosted Ollama).
- **Medium-Term (2026 Q2)**: Multi-user platform—opt-in DB for shared insights (e.g., similar profiles), enterprise hooks (hiring patterns).
- **Long-Term**: Full "Career Ecosystem"—integrate more sources (e.g., GitHub activity), AI coaching (daily tips), community mapping (connect users ethically).
- **Scalability**: Modular design allows adding sources (e.g., Twitter exports) or tools (e.g., quantum-resistant encryption for privacy trends).
- **Problems for Future**: AI job displacement—CareerForge could evolve to "upskill recommender." Privacy regs (e.g., GDPR updates)—enhance consents. Economic shifts—add freelance gig matching.

---

## End-to-End Project Understanding Pipeline
CareerForge OS follows a modular, local pipeline: Input → Process → Output. It's end-to-end for a solo user—upload data, command the system, get insights/exports. No external calls except optional free APIs (with fallbacks).

1. **Input Stage**: User provides data/commands.
   - Sources: LinkedIn ZIP, resume PDF/DOCX, Gmail export (manual MBOX/CSV), YAML command.
   - Handling: Browser upload/FileReader, parsed via JSZip/PapaParse/open-resume.

2. **Processing Stage**: Intelligent core—parse, analyze, automate.
   - **Parsing**: Extract entities (skills, connections, jobs, emails) in-memory/sessionStorage.
   - **Command Parsing**: YAML to actions (e.g., js-yaml.load → chain tasks).
   - **AI Layer**: Local Ollama for insights (e.g., rank jobs, score resumes)—format prompts with context to save compute.
   - **Automation**: Job fetch (APIs/Pyodide scrape), Gmail cleanup (API/scripts), app prep (AI answers).
   - **Enhancements**: Filters/aggregations (e.g., group by sender/title), error boundaries.

3. **Output Stage**: Visual/actionable results.
   - Dashboards: Interactive tabs (Shadcn/Recharts).
   - Exports: CSV/Excel (PapaParse), PDF (jsPDF).
   - Reports: Step-by-step (e.g., "Jobs matched: 10, Resume score: 85%").

**Pipeline Flow Example** (for "Optimize for AI jobs"):
- Input: YAML + ZIP + Resume
- Process: Parse skills → Fetch jobs (API) → LLM rank/score/regenerate
- Output: Table of jobs + Scored report + ATS resume PDF

This pipeline is resilient: Offline fallbacks, progress bars, logs for debugging.

---

## Features with Discussion References
Each feature references our conversation history, enhanced for v1.

1. **LinkedIn Data Parsing & Visualization** (From initial vision + codebase docs).
   - Discussion: ZIP parser for connections/messages/jobs; dashboards for insights.
   - Enhancement: Add skills extraction; group by title/seniority. Solves "understand present connections."
   - Implementation: Enhance linkedin-parser.ts (see snippets below).

2. **Structured Input Parsing (YAML Commands)** (From input parsing discussion).
   - Discussion: Make app intelligent—parse user goals/actions to chain tasks.
   - Enhancement: Command Center tab for YAML; fallback to free-text.
   - Implementation: New input-parser.ts + UI.

3. **Local AI Insights & Recommendations** (From AI/LLM integration).
   - Discussion: Format inputs, avoid token limits; suggest reconnections/jobs.
   - Enhancement: Ollama for zero-cost; chain with parsing (e.g., "Suggest based on skills").
   - Implementation: use-ollama hook.

4. **Job Matching & Fetching** (From job listing/skills discussion).
   - Discussion: Match recent listings to skills; use free APIs, fallback scraping.
   - Enhancement: Prioritize CareerOneStop/Adzuna; LLM rank to save compute.
   - Implementation: In JobStrategyDashboard.tsx.

5. **Resume Optimization** (From resume parsing/scoring/regeneration).
   - Discussion: Parse PDF, score vs. job desc, regenerate ATS-friendly.
   - Enhancement: Local libs (open-resume/Pyodide); integrate with job matches.
   - Implementation: ResumeOptimizer.tsx.

6. **Gmail Cleanup & Export** (From recent Gmail request).
   - Discussion: Export to CSV (sender/details), unsubscribe, label/clean.
   - Enhancement: Integrate as optional module—API/scripts for solo use.
   - Implementation: New GmailTools.tsx (using Gmail API Python via Pyodide).

7. **Job Application Prep Automation** (From Workday/LinkedIn automation).
   - Discussion: Prep answers from resume/AI; handle questions humanely.
   - Enhancement: Generate responses/cover letters; track apps locally.
   - Implementation: Extend JobStrategyDashboard with prep button.

---

## Detailed Implementation for v1 Prototype
Build on your existing codebase. Install deps: `npm i js-yaml axios @pyodide/pyodide jsPDF use-ollama open-resume vite-plugin-electron electron`. Use Cursor/Copilot for coding.

### Week 1: Setup & Core Parsing (Jan 2-8)
- **Day 1**: Env setup. Install deps, run `ollama run mistral`, test Pyodide.
- **Day 2**: Enhance linkedin-parser.ts for skills/jobs.
  ```typescript
  // linkedin-parser.ts (enhance parseLinkedInExport)
  const skillsCsv = await getCsvContent(zip, 'Skills.csv');
  if (skillsCsv) data.skills = Papa.parse(skillsCsv, {header: true}).data.map(r => ({name: r['Skill Name'], endorsements: +r.Endorsements || 0}));
  ```
- **Day 3-4**: Add input-parser.ts + Gmail export prep (Pyodide script for MBOX to CSV).
  ```typescript
  // input-parser.ts
  import yaml from 'js-yaml';
  export function parseUserInput(text: string) {
    try { return yaml.load(text); } catch { return {goal: text}; }
  }
  ```
- **Day 5-6**: Resume upload/parse in ResumeOptimizer.tsx (use open-resume).
  ```typescript
  // ResumeOptimizer.tsx
  import { parseResume } from 'open-resume';
  const handleUpload = async (file) => setParsed(await parseResume(file));
  ```
- **Day 7**: Test pipeline basics.
- **Milestone**: Parse ZIP/resume, export CSV.

### Week 2: Visuals & Command Center (Jan 9-15)
- **Day 8-9**: Enhance dashboards with skills filters.
- **Day 10-11**: Job fetch in JobStrategyDashboard.tsx.
  ```typescript
  // JobStrategyDashboard.tsx
  import axios from 'axios';
  const fetchJobs = async (query) => {
    try { return (await axios.get(`https://api.careeronestop.org/v1/jobsearch?keyword=${query}`)).data.jobs; }
    catch { /* Pyodide fallback scrape */ }
  };
  ```
- **Day 12-13**: Add CommandCenter.tsx.
  ```typescript
  // CommandCenter.tsx
  import { parseUserInput } from '@/lib/input-parser';
  const [input, setInput] = useState(''); // Textarea
  const runCommand = () => {
    const parsed = parseUserInput(input);
    // Chain: if(parsed.actions.includes('fetch jobs')) fetchJobs(...);
  };
  ```
- **Day 14-15**: Polish UI.
- **Milestone**: Command runs basic actions.

### Week 3: AI & Resume/Job Integration (Jan 16-22)
- **Day 16-17**: Local AI hook.
  ```typescript
  // useLocalLLM.ts
  import { useOllama } from 'use-ollama';
  const { generate } = useOllama({model: 'mistral'});
  const getInsights = (parsed) => generate({prompt: `Goal: ${parsed.goal} Data: ${JSON.stringify(data)}`});
  ```
- **Day 18-19**: Resume scoring/regeneration via LLM.
- **Day 20-21**: Gmail cleanup in GmailTools.tsx (Pyodide for API scripts).
- **Day 22**: Test chaining.
- **Milestone**: Full AI-driven flows.

### Week 4: App Prep, Polish, Packaging (Jan 23-31)
- **Day 23-24**: Job app prep (LLM generate answers).
- **Day 25-26**: Electron packaging (update vite.config.ts).
- **Day 27-28**: End-to-end testing.
- **Day 29-31**: Buffer/docs.
- **Milestone**: Packaged app with all features.

---

## Conclusion
CareerForge OS v1 is your prototype ready for build—local, intelligent, pain-relieving. Implement step-by-step, and it'll transform your solo grind. Future: Expand to community tool. Let's forge ahead! 🚀
