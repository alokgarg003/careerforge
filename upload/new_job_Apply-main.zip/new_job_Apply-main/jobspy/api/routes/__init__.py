# jobspy/api/routes/__init__.py
"""API route modules."""
