# JobNotifier - Ethical Job Scraper

Personal, ethical job notification system for DevOps/Cloud engineers.

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set email password (for notifications)
export EMAIL_PASS="your-gmail-app-password"

# 3. Run once
python jobnotifier.py --once

# 4. Or run with scheduler (daily at 09:00)
python jobnotifier.py --schedule 09:00
```

## Configuration

Edit `config.yaml` to customize:
- **roles**: Job titles to search
- **skills**: Your skills for matching
- **locations**: Preferred locations
- **min_match_score**: Minimum relevance score (0-100)

## Output

- **jobs.csv**: All matching jobs (append-only)
- **errors.log**: Error tracking
- **Daily email**: Summary of new jobs

## Ethical Constraints

- ✅ Public APIs only (Remotive, Jobicy, Arbeitnow)
- ✅ Rate limiting with random delays
- ✅ robots.txt enforcement
- ✅ No login/authentication required
- ✅ 50-100 jobs/day limit
- ❌ No LinkedIn scraping
- ❌ No Selenium/browser automation

## Import to Dashboard

1. Run the scraper: `python jobnotifier.py --once`
2. Open your dashboard at /jobs
3. Upload `jobs.csv` using the import feature

## Gmail Setup

1. Enable 2FA on your Google account
2. Generate an App Password: Google Account → Security → App passwords
3. Use the app password (not your regular password)
