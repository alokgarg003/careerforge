#!/usr/bin/env python3
"""
JobNotifier - Ethical Job Notification Scraper
Personal, non-commercial use only. 50-100 jobs/day max.

Run: python jobnotifier.py
Schedule: Use cron or Task Scheduler for daily 09:00 execution
"""

import os
import re
import csv
import ssl
import json
import time
import random
import hashlib
import logging
import smtplib
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from urllib.parse import urljoin, urlparse
from urllib.robotparser import RobotFileParser

import yaml
import requests
from bs4 import BeautifulSoup

# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('errors.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# =============================================================================
# CONFIGURATION
# =============================================================================

DEFAULT_CONFIG = """
personal:
  roles:
    - DevOps Engineer
    - Cloud Support Engineer
    - Platform Engineer
    - Application Support Engineer

  skills:
    - AWS
    - Azure
    - Linux
    - Bash
    - Docker
    - ELK
    - Jenkins
    - Spring Boot
    - Microservices

  locations:
    - India
    - Delhi
    - remote

  experience_keywords:
    - Junior
    - Mid
    - 1-3 years
    - Entry-Level

  min_match_score: 70

sources:
  job_boards:
    - name: Remotive
      base_url: https://remotive.com/api/remote-jobs
      query_params: "?category=devops&limit=50"
      is_api: true
      robots_check: false
      max_pages: 1

    - name: Jobicy
      base_url: https://jobicy.com/api/v2/remote-jobs
      query_params: "?count=50&tag=devops"
      is_api: true
      robots_check: false
      max_pages: 1

    - name: Arbeitnow
      base_url: https://www.arbeitnow.com/api/job-board-api
      query_params: ""
      is_api: true
      robots_check: false
      max_pages: 1

  company_careers: []

email:
  from_address: yourjobnotifier@gmail.com
  to_address: alokgarg003@gmail.com
  smtp_server: smtp.gmail.com
  smtp_port: 587
  password_env_var: EMAIL_PASS

scraping:
  user_agents:
    - "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    - "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"
    - "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36"
  delay_min: 5
  delay_max: 10
  max_jobs_per_source: 20
  timeout: 30

logging:
  csv_file: jobs.csv
  error_log: errors.log
  hash_file: page_hashes.json
"""


def load_config(config_path: str = "config.yaml") -> dict:
    """Load configuration from YAML file or create default."""
    if os.path.exists(config_path):
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            logger.info(f"Loaded configuration from {config_path}")
            return config
    else:
        config = yaml.safe_load(DEFAULT_CONFIG)
        with open(config_path, 'w', encoding='utf-8') as f:
            yaml.dump(config, f, default_flow_style=False)
        logger.info(f"Created default configuration at {config_path}")
        return config


def get_email_password(config: dict) -> str:
    """Get email password from environment variable."""
    env_var = config.get('email', {}).get('password_env_var', 'EMAIL_PASS')
    password = os.environ.get(env_var, '')
    if not password:
        logger.warning(f"Email password not found in environment variable: {env_var}")
    return password


# =============================================================================
# ROBOTS.TXT ENFORCEMENT
# =============================================================================

_robots_cache = {}


def check_robots(url: str, user_agent: str = "*") -> bool:
    """Check if scraping is allowed by robots.txt. Returns True if allowed."""
    try:
        parsed = urlparse(url)
        robots_url = f"{parsed.scheme}://{parsed.netloc}/robots.txt"
        
        if robots_url in _robots_cache:
            rp = _robots_cache[robots_url]
        else:
            rp = RobotFileParser()
            rp.set_url(robots_url)
            try:
                rp.read()
                _robots_cache[robots_url] = rp
            except Exception as e:
                logger.debug(f"Could not fetch robots.txt for {parsed.netloc}: {e}")
                return True  # Allow if robots.txt not accessible
        
        allowed = rp.can_fetch(user_agent, url)
        if not allowed:
            logger.info(f"Robots.txt disallows scraping: {url}")
        return allowed
    except Exception as e:
        logger.error(f"Error checking robots.txt: {e}")
        return True  # Fail open - allow if check fails


# =============================================================================
# HTTP REQUEST UTILITIES
# =============================================================================

def get_random_user_agent(config: dict) -> str:
    """Get a random user agent from config."""
    agents = config.get('scraping', {}).get('user_agents', [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    ])
    return random.choice(agents)


def random_delay(config: dict):
    """Apply random delay between requests."""
    scraping_config = config.get('scraping', {})
    delay_min = scraping_config.get('delay_min', 5)
    delay_max = scraping_config.get('delay_max', 10)
    delay = random.uniform(delay_min, delay_max)
    logger.debug(f"Sleeping for {delay:.2f} seconds")
    time.sleep(delay)


def make_request(url: str, config: dict) -> requests.Response | None:
    """Make an HTTP request with error handling and rate limiting."""
    user_agent = get_random_user_agent(config)
    timeout = config.get('scraping', {}).get('timeout', 30)
    
    headers = {
        'User-Agent': user_agent,
        'Accept': 'application/json, text/html, */*',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    
    try:
        response = requests.get(url, headers=headers, timeout=timeout)
        
        if response.status_code == 429:
            logger.warning(f"Rate limited (429) for {url}. Backing off.")
            time.sleep(60)  # Back off for 1 minute
            return None
        
        if response.status_code == 403:
            logger.warning(f"Access forbidden (403) for {url}. Skipping.")
            return None
        
        response.raise_for_status()
        return response
        
    except requests.exceptions.Timeout:
        logger.error(f"Request timeout for {url}")
        return None
    except requests.exceptions.RequestException as e:
        logger.error(f"Request failed for {url}: {e}")
        return None


# =============================================================================
# URL BUILDING
# =============================================================================

def build_urls(source: dict, config: dict) -> list[str]:
    """Build search URLs for a source based on config."""
    urls = []
    base_url = source.get('base_url', '')
    query_params = source.get('query_params', '')
    max_pages = source.get('max_pages', 1)
    pagination = source.get('pagination', '')
    
    personal = config.get('personal', {})
    roles = personal.get('roles', ['DevOps Engineer'])
    locations = personal.get('locations', ['remote'])
    skills = personal.get('skills', [])
    
    # For API sources, just use the direct URL
    if source.get('is_api', False):
        url = f"{base_url}{query_params}"
        urls.append(url)
        return urls
    
    # For HTML sources, build URLs with role/location combinations
    for role in roles[:2]:  # Limit to first 2 roles
        for location in locations[:2]:  # Limit to first 2 locations
            for page in range(max_pages):
                url = base_url + query_params
                
                # Replace placeholders
                role_slug = role.lower().replace(' ', '-')
                location_slug = location.lower().replace(' ', '-')
                skills_str = '+'.join(skills[:3])  # First 3 skills
                
                url = url.replace('{role}', role_slug)
                url = url.replace('{location}', location_slug)
                url = url.replace('{skills}', skills_str)
                
                if pagination and page > 0:
                    page_param = pagination.replace('{page*10}', str(page * 10))
                    page_param = page_param.replace('{page}', str(page + 1))
                    url += page_param
                
                urls.append(url)
    
    return urls


# =============================================================================
# JOB PARSING - API SOURCES
# =============================================================================

def parse_remotive_jobs(data: dict) -> list[dict]:
    """Parse jobs from Remotive API response."""
    jobs = []
    for job in data.get('jobs', []):
        jobs.append({
            'title': job.get('title', ''),
            'company': job.get('company_name', ''),
            'location': job.get('candidate_required_location', 'Remote'),
            'link': job.get('url', ''),
            'snippet': job.get('description', '')[:500] if job.get('description') else '',
            'date': job.get('publication_date', ''),
            'source': 'Remotive',
            'salary': job.get('salary', ''),
        })
    return jobs


def parse_jobicy_jobs(data: dict) -> list[dict]:
    """Parse jobs from Jobicy API response."""
    jobs = []
    for job in data.get('jobs', []):
        jobs.append({
            'title': job.get('jobTitle', ''),
            'company': job.get('companyName', ''),
            'location': job.get('jobGeo', 'Remote'),
            'link': job.get('url', ''),
            'snippet': job.get('jobExcerpt', ''),
            'date': job.get('pubDate', ''),
            'source': 'Jobicy',
            'salary': f"{job.get('annualSalaryMin', '')} - {job.get('annualSalaryMax', '')}",
        })
    return jobs


def parse_arbeitnow_jobs(data: dict) -> list[dict]:
    """Parse jobs from Arbeitnow API response."""
    jobs = []
    for job in data.get('data', []):
        jobs.append({
            'title': job.get('title', ''),
            'company': job.get('company_name', ''),
            'location': job.get('location', 'Remote'),
            'link': job.get('url', ''),
            'snippet': job.get('description', '')[:500] if job.get('description') else '',
            'date': job.get('created_at', ''),
            'source': 'Arbeitnow',
            'salary': '',
        })
    return jobs


# =============================================================================
# SCRAPING SOURCES
# =============================================================================

def scrape_api_source(source: dict, config: dict) -> list[dict]:
    """Scrape jobs from an API source."""
    jobs = []
    urls = build_urls(source, config)
    source_name = source.get('name', 'Unknown')
    max_jobs = config.get('scraping', {}).get('max_jobs_per_source', 20)
    
    for url in urls:
        logger.info(f"Fetching from {source_name}: {url}")
        
        response = make_request(url, config)
        if not response:
            continue
        
        try:
            data = response.json()
            
            if source_name == 'Remotive':
                jobs.extend(parse_remotive_jobs(data))
            elif source_name == 'Jobicy':
                jobs.extend(parse_jobicy_jobs(data))
            elif source_name == 'Arbeitnow':
                jobs.extend(parse_arbeitnow_jobs(data))
            
            random_delay(config)
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse error for {source_name}: {e}")
            continue
    
    logger.info(f"Found {len(jobs)} jobs from {source_name}")
    return jobs[:max_jobs]


def scrape_html_source(source: dict, config: dict) -> list[dict]:
    """Scrape jobs from an HTML source (placeholder for custom parsers)."""
    # Note: HTML scraping requires site-specific selectors
    # This is a template - implement per-site logic as needed
    jobs = []
    source_name = source.get('name', 'Unknown')
    
    # Check robots.txt first
    if source.get('robots_check', True):
        if not check_robots(source.get('base_url', '')):
            logger.info(f"Skipping {source_name} - disallowed by robots.txt")
            return jobs
    
    urls = build_urls(source, config)
    
    for url in urls:
        logger.info(f"Scraping {source_name}: {url}")
        
        response = make_request(url, config)
        if not response:
            continue
        
        try:
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Generic job card extraction - customize per site
            # This is a placeholder - real implementation needs site-specific selectors
            logger.warning(f"HTML parsing for {source_name} requires custom selectors")
            
            random_delay(config)
            
        except Exception as e:
            logger.error(f"Parse error for {source_name}: {e}")
            continue
    
    return jobs


def scrape_source(source: dict, config: dict) -> list[dict]:
    """Route to appropriate scraper based on source type."""
    if source.get('is_api', False):
        return scrape_api_source(source, config)
    else:
        return scrape_html_source(source, config)


# =============================================================================
# CHANGE DETECTION (COMPANY PAGES)
# =============================================================================

def load_page_hashes(config: dict) -> dict:
    """Load stored page content hashes."""
    hash_file = config.get('logging', {}).get('hash_file', 'page_hashes.json')
    if os.path.exists(hash_file):
        with open(hash_file, 'r') as f:
            return json.load(f)
    return {}


def save_page_hashes(hashes: dict, config: dict):
    """Save page content hashes."""
    hash_file = config.get('logging', {}).get('hash_file', 'page_hashes.json')
    with open(hash_file, 'w') as f:
        json.dump(hashes, f, indent=2)


def check_page_changed(url: str, content: str, config: dict) -> bool:
    """Check if page content has changed since last scrape."""
    hashes = load_page_hashes(config)
    content_hash = hashlib.md5(content.encode()).hexdigest()
    
    if url in hashes and hashes[url] == content_hash:
        logger.debug(f"No change detected for {url}")
        return False
    
    hashes[url] = content_hash
    save_page_hashes(hashes, config)
    return True


# =============================================================================
# JOB FILTERING AND SCORING
# =============================================================================

def calculate_match_score(job: dict, config: dict) -> int:
    """Calculate relevance score for a job based on skills and experience."""
    personal = config.get('personal', {})
    skills = [s.lower() for s in personal.get('skills', [])]
    experience_keywords = [e.lower() for e in personal.get('experience_keywords', [])]
    
    # Combine all text fields for matching
    job_text = ' '.join([
        job.get('title', ''),
        job.get('snippet', ''),
        job.get('company', ''),
    ]).lower()
    
    # Count skill matches
    skill_matches = sum(1 for skill in skills if skill in job_text)
    total_skills = len(skills) if skills else 1
    
    # Base score from skill matches
    score = (skill_matches / total_skills) * 100
    
    # Bonus for experience keyword matches
    for keyword in experience_keywords:
        if keyword in job_text:
            score += 10
            break
    
    # Clamp to 0-100
    return min(100, max(0, int(score)))


def is_recent_job(job: dict, max_age_hours: int = 48) -> bool:
    """Check if job was posted within the specified time window."""
    date_str = job.get('date', '')
    if not date_str:
        return True  # Include if no date available
    
    try:
        # Try multiple date formats
        formats = [
            '%Y-%m-%dT%H:%M:%S',
            '%Y-%m-%dT%H:%M:%S.%fZ',
            '%Y-%m-%d',
            '%d %b %Y',
            '%B %d, %Y',
        ]
        
        job_date = None
        for fmt in formats:
            try:
                job_date = datetime.strptime(date_str[:19], fmt[:len(date_str)])
                break
            except ValueError:
                continue
        
        if job_date:
            age = datetime.now() - job_date
            return age < timedelta(hours=max_age_hours)
        
        return True  # Include if date can't be parsed
        
    except Exception as e:
        logger.debug(f"Date parse error: {e}")
        return True


def filter_and_score(jobs: list[dict], config: dict) -> list[dict]:
    """Filter jobs by score and recency, then sort by relevance."""
    min_score = config.get('personal', {}).get('min_match_score', 70)
    scored_jobs = []
    
    for job in jobs:
        # Check recency
        if not is_recent_job(job):
            continue
        
        # Calculate score
        score = calculate_match_score(job, config)
        job['match_score'] = score
        
        # Filter by minimum score
        if score >= min_score:
            scored_jobs.append(job)
    
    # Sort by score descending
    scored_jobs.sort(key=lambda x: x.get('match_score', 0), reverse=True)
    
    logger.info(f"Filtered to {len(scored_jobs)} jobs above {min_score}% match")
    return scored_jobs


# =============================================================================
# DEDUPLICATION
# =============================================================================

def generate_job_hash(job: dict) -> str:
    """Generate unique hash for a job to detect duplicates."""
    unique_str = f"{job.get('title', '').lower()}{job.get('company', '').lower()}{job.get('link', '')}"
    return hashlib.md5(unique_str.encode()).hexdigest()


def deduplicate(jobs: list[dict]) -> list[dict]:
    """Remove duplicate job listings."""
    seen_hashes = set()
    unique_jobs = []
    
    for job in jobs:
        job_hash = generate_job_hash(job)
        if job_hash not in seen_hashes:
            seen_hashes.add(job_hash)
            job['hash'] = job_hash
            unique_jobs.append(job)
    
    logger.info(f"Deduplicated: {len(jobs)} -> {len(unique_jobs)} jobs")
    return unique_jobs


# =============================================================================
# CSV LOGGING
# =============================================================================

def load_existing_hashes(csv_file: str) -> set:
    """Load hashes of previously saved jobs."""
    hashes = set()
    if os.path.exists(csv_file):
        try:
            with open(csv_file, 'r', encoding='utf-8', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if 'hash' in row:
                        hashes.add(row['hash'])
        except Exception as e:
            logger.error(f"Error loading existing CSV: {e}")
    return hashes


def log_to_csv(jobs: list[dict], config: dict) -> int:
    """Append new jobs to CSV file. Returns count of new jobs added."""
    csv_file = config.get('logging', {}).get('csv_file', 'jobs.csv')
    existing_hashes = load_existing_hashes(csv_file)
    
    # Filter out jobs we've already saved
    new_jobs = [j for j in jobs if j.get('hash') not in existing_hashes]
    
    if not new_jobs:
        logger.info("No new jobs to add to CSV")
        return 0
    
    # Define CSV columns
    fieldnames = [
        'title', 'company', 'location', 'link', 'snippet', 
        'date', 'source', 'salary', 'match_score', 'hash', 'scraped_at'
    ]
    
    file_exists = os.path.exists(csv_file)
    
    try:
        with open(csv_file, 'a', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
            
            if not file_exists:
                writer.writeheader()
            
            for job in new_jobs:
                job['scraped_at'] = datetime.now().isoformat()
                writer.writerow(job)
        
        logger.info(f"Added {len(new_jobs)} new jobs to {csv_file}")
        return len(new_jobs)
        
    except Exception as e:
        logger.error(f"Error writing to CSV: {e}")
        return 0


# =============================================================================
# EMAIL NOTIFICATION
# =============================================================================

def send_email(jobs: list[dict], config: dict, new_count: int) -> bool:
    """Send email notification with job summary."""
    email_config = config.get('email', {})
    
    from_addr = email_config.get('from_address', '')
    to_addr = email_config.get('to_address', '')
    smtp_server = email_config.get('smtp_server', 'smtp.gmail.com')
    smtp_port = email_config.get('smtp_port', 587)
    password = get_email_password(config)
    
    if not all([from_addr, to_addr, password]):
        logger.warning("Email not configured properly. Skipping notification.")
        return False
    
    # Build email content
    subject = f"JobNotifier: {new_count} New Jobs Found - {datetime.now().strftime('%Y-%m-%d')}"
    
    # Summary by source
    source_counts = {}
    for job in jobs:
        source = job.get('source', 'Unknown')
        source_counts[source] = source_counts.get(source, 0) + 1
    
    body = f"""
JobNotifier Daily Report
========================
Date: {datetime.now().strftime('%Y-%m-%d %H:%M')}
New Jobs Found: {new_count}
Total Matching Jobs: {len(jobs)}

Jobs by Source:
"""
    for source, count in source_counts.items():
        body += f"  - {source}: {count}\n"
    
    body += "\nTop 10 Jobs:\n" + "-" * 40 + "\n"
    
    for job in jobs[:10]:
        body += f"""
Title: {job.get('title', 'N/A')}
Company: {job.get('company', 'N/A')}
Location: {job.get('location', 'N/A')}
Match Score: {job.get('match_score', 'N/A')}%
Link: {job.get('link', 'N/A')}
---
"""
    
    body += f"\nFull results saved to: {config.get('logging', {}).get('csv_file', 'jobs.csv')}"
    
    try:
        msg = MIMEMultipart()
        msg['From'] = from_addr
        msg['To'] = to_addr
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'plain'))
        
        context = ssl.create_default_context()
        
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls(context=context)
            server.login(from_addr, password)
            server.sendmail(from_addr, to_addr, msg.as_string())
        
        logger.info(f"Email sent successfully to {to_addr}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        return False


# =============================================================================
# MAIN EXECUTION
# =============================================================================

def run_scraper():
    """Main scraper execution function."""
    logger.info("=" * 50)
    logger.info("JobNotifier Starting...")
    logger.info("=" * 50)
    
    # Load configuration
    config = load_config()
    
    all_jobs = []
    
    # Scrape job boards
    for source in config.get('sources', {}).get('job_boards', []):
        try:
            jobs = scrape_source(source, config)
            all_jobs.extend(jobs)
        except Exception as e:
            logger.error(f"Error scraping {source.get('name')}: {e}")
            continue
    
    # Scrape company career pages
    for source in config.get('sources', {}).get('company_careers', []):
        try:
            jobs = scrape_source(source, config)
            all_jobs.extend(jobs)
        except Exception as e:
            logger.error(f"Error scraping {source.get('name')}: {e}")
            continue
    
    logger.info(f"Total raw jobs collected: {len(all_jobs)}")
    
    # Process jobs
    unique_jobs = deduplicate(all_jobs)
    filtered_jobs = filter_and_score(unique_jobs, config)
    
    # Log to CSV
    new_count = log_to_csv(filtered_jobs, config)
    
    # Send email notification
    if filtered_jobs:
        send_email(filtered_jobs, config, new_count)
    else:
        logger.info("No matching jobs found. Skipping email.")
    
    logger.info("JobNotifier completed successfully")
    return filtered_jobs


def main():
    """Entry point with scheduling support."""
    import argparse
    
    parser = argparse.ArgumentParser(description='JobNotifier - Ethical Job Scraper')
    parser.add_argument('--once', action='store_true', help='Run once and exit')
    parser.add_argument('--schedule', type=str, default='09:00', help='Daily run time (HH:MM)')
    args = parser.parse_args()
    
    if args.once:
        run_scraper()
    else:
        import schedule
        
        schedule.every().day.at(args.schedule).do(run_scraper)
        logger.info(f"Scheduled daily run at {args.schedule}")
        
        # Run immediately on first start
        run_scraper()
        
        while True:
            schedule.run_pending()
            time.sleep(60)


if __name__ == '__main__':
    main()
