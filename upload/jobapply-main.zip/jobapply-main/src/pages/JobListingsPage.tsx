import { JobListings } from "@/components/jobs/JobListings";

export default function JobListingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Job Listings</h1>
        <p className="text-muted-foreground">
          Import, browse, and filter aggregated job postings
        </p>
      </div>

      <JobListings />
    </div>
  );
}
