import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { LinkedInProvider, useLinkedIn } from '@/context/LinkedInContext';
import { LinkedInUpload } from '@/components/linkedin/LinkedInUpload';
import { DataDiscoveryPanel } from '@/components/linkedin/DataDiscoveryPanel';
import { CareerGrowthDashboard } from '@/components/linkedin/CareerGrowthDashboard';
import { NetworkAnalyticsDashboard } from '@/components/linkedin/NetworkAnalyticsDashboard';
import { CompanyIntelligenceDashboard } from '@/components/linkedin/CompanyIntelligenceDashboard';
import { JobSearchStrategyDashboard } from '@/components/linkedin/JobSearchStrategyDashboard';
import { EthicsIntentSection } from '@/components/linkedin/EthicsIntentSection';
import { ResumeOptimizer } from '@/components/linkedin/ResumeOptimizer';
import { AIInsightsPanel } from '@/components/linkedin/AIInsightsPanel';
import { Badge } from '@/components/ui/badge';
import { Trash2 } from 'lucide-react';

function LinkedInContent() {
  const { data, clearData } = useLinkedIn();
  const [activeTab, setActiveTab] = useState('career');

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-bold text-foreground">Personal Intelligence OS</h1>
            <Badge variant="outline">Local-First • Privacy-First</Badge>
          </div>
          <p className="text-muted-foreground mt-1">
            Career intelligence dashboard • All data processed client-side • No server uploads
          </p>
        </div>
        {data.isLoaded && (
          <Button variant="outline" size="sm" onClick={clearData}>
            <Trash2 className="h-4 w-4 mr-2" />
            Clear Data
          </Button>
        )}
      </div>

      <LinkedInUpload />

      {data.isLoaded && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-8">
            <TabsTrigger value="career">Career</TabsTrigger>
            <TabsTrigger value="network">Network</TabsTrigger>
            <TabsTrigger value="companies">Companies</TabsTrigger>
            <TabsTrigger value="jobs">Job Search</TabsTrigger>
            <TabsTrigger value="resume">Resume</TabsTrigger>
            <TabsTrigger value="ai">AI Insights</TabsTrigger>
            <TabsTrigger value="data">Data</TabsTrigger>
            <TabsTrigger value="ethics">Ethics</TabsTrigger>
          </TabsList>
          <TabsContent value="career" className="mt-6">
            <CareerGrowthDashboard />
          </TabsContent>
          <TabsContent value="network" className="mt-6">
            <NetworkAnalyticsDashboard />
          </TabsContent>
          <TabsContent value="companies" className="mt-6">
            <CompanyIntelligenceDashboard />
          </TabsContent>
          <TabsContent value="jobs" className="mt-6">
            <JobSearchStrategyDashboard />
          </TabsContent>
          <TabsContent value="resume" className="mt-6">
            <ResumeOptimizer />
          </TabsContent>
          <TabsContent value="ai" className="mt-6">
            <AIInsightsPanel />
          </TabsContent>
          <TabsContent value="data" className="mt-6">
            <DataDiscoveryPanel />
          </TabsContent>
          <TabsContent value="ethics" className="mt-6">
            <EthicsIntentSection />
          </TabsContent>
        </Tabs>
      )}

      {!data.isLoaded && <EthicsIntentSection />}
    </div>
  );
}

export default function LinkedInIntelligencePage() {
  return (
    <LinkedInProvider>
      <LinkedInContent />
    </LinkedInProvider>
  );
}