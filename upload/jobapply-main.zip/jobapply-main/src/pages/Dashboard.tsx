import { StatsCard } from "@/components/StatsCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Briefcase, Building2, Target, TrendingUp, Sparkles, Search, ArrowRight, Zap, ExternalLink } from "lucide-react";
import { useJobContext } from "@/context/JobContext";
import { ALIGNMENT_COLORS, ALIGNMENT_LABELS } from "@/types/job";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link, useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Progress } from "@/components/ui/progress";

export default function Dashboard() {
  const { stats, filteredJobs } = useJobContext();
  const navigate = useNavigate();

  const topSources = Object.entries(stats.bySource)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 4);

  const alignmentStats = Object.entries(stats.byAlignment || {})
    .sort((a, b) => (b[1] as number) - (a[1] as number));

  const topMatchingJobs = [...filteredJobs]
    .filter(j => j.matchScore !== undefined && j.resumeAlignmentLevel !== 'Ignore')
    .sort((a, b) => (b.matchScore || 0) - (a.matchScore || 0))
    .slice(0, 5);

  const uniqueCompanies = new Set(filteredJobs.map(j => j.company)).size;
  const strongMatches = filteredJobs.filter(j => j.resumeAlignmentLevel === 'Strong Match').length;

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-success';
    if (score >= 50) return 'text-info';
    if (score >= 30) return 'text-warning';
    return 'text-muted-foreground';
  };

  const getScoreBg = (score: number) => {
    if (score >= 70) return 'bg-success/20';
    if (score >= 50) return 'bg-info/20';
    if (score >= 30) return 'bg-warning/20';
    return 'bg-muted';
  };

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">
            <span className="gradient-text">Command Center</span>
          </h1>
          <p className="text-muted-foreground mt-1">
            Your privacy-first career intelligence dashboard
          </p>
        </div>
        <div className="flex gap-3">
          <Button 
            onClick={() => navigate('/live-jobs')}
            className="gradient-primary text-white glow-primary"
          >
            <Sparkles className="h-4 w-4 mr-2" />
            Fetch Live Jobs
          </Button>
          <Button variant="outline" onClick={() => navigate('/jobs')}>
            <Search className="h-4 w-4 mr-2" />
            Browse Jobs
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
        <StatsCard
          title="Total Jobs"
          value={stats.total}
          icon={Briefcase}
          description="In your database"
          variant="primary"
          onClick={() => navigate('/jobs')}
        />
        <StatsCard
          title="Companies"
          value={uniqueCompanies}
          icon={Building2}
          description="Unique employers"
          variant="accent"
        />
        <StatsCard
          title="Strong Matches"
          value={strongMatches}
          icon={Target}
          description="High alignment jobs"
          variant="success"
          onClick={() => navigate('/jobs')}
        />
        <StatsCard
          title="Match Score"
          value={`${stats.avgMatchScore}%`}
          icon={TrendingUp}
          description="Average quality"
          variant={stats.avgMatchScore >= 60 ? 'success' : 'warning'}
        />
      </div>

      {/* Quick Actions */}
      {stats.total === 0 && (
        <Card className="glass border-primary/30 glow-primary">
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <div className="h-16 w-16 rounded-2xl gradient-primary flex items-center justify-center">
                <Zap className="h-8 w-8 text-white" />
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-lg font-semibold">Get Started</h3>
                <p className="text-muted-foreground text-sm mt-1">
                  Import your job data or fetch live listings to begin your career intelligence journey
                </p>
              </div>
              <div className="flex gap-3">
                <Button variant="outline" onClick={() => navigate('/jobs')}>
                  Import CSV
                </Button>
                <Button 
                  onClick={() => navigate('/live-jobs')}
                  className="gradient-primary text-white"
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  Fetch Live Jobs
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-2 gap-6">
        {/* Jobs by Source */}
        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <Briefcase className="h-4 w-4 text-primary" />
              </div>
              Jobs by Source
            </CardTitle>
          </CardHeader>
          <CardContent>
            {topSources.length > 0 ? (
              <div className="space-y-4">
                {topSources.map(([source, count]) => {
                  const percentage = Math.round((count / stats.total) * 100);
                  return (
                    <div key={source} className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground capitalize">{source}</span>
                        <span className="font-medium">{count} <span className="text-muted-foreground">({percentage}%)</span></span>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-sm">No data yet</p>
                <Button variant="link" className="mt-2 text-primary" onClick={() => navigate('/jobs')}>
                  Import jobs to get started
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Resume Alignment */}
        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-success/20 flex items-center justify-center">
                <Target className="h-4 w-4 text-success" />
              </div>
              Resume Alignment
            </CardTitle>
          </CardHeader>
          <CardContent>
            {alignmentStats.length > 0 ? (
              <div className="space-y-3">
                {alignmentStats.map(([level, count]) => {
                  const countNum = count as number;
                  const percentage = Math.round((countNum / stats.total) * 100);
                  return (
                    <div key={level} className="flex items-center gap-3">
                      <Badge 
                        variant="outline"
                        className={cn('text-xs border shrink-0 w-28 justify-center', ALIGNMENT_COLORS[level as keyof typeof ALIGNMENT_COLORS])}
                      >
                        {ALIGNMENT_LABELS[level as keyof typeof ALIGNMENT_LABELS] || level}
                      </Badge>
                      <div className="flex-1">
                        <Progress value={percentage} className="h-2" />
                      </div>
                      <span className="text-sm font-medium w-16 text-right">{countNum}</span>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground text-sm">No alignment data available</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Top Matching Jobs */}
      <Card className="glass-hover">
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            Top Matching Jobs
          </CardTitle>
          <Button variant="ghost" size="sm" className="text-primary" asChild>
            <Link to="/jobs" className="flex items-center gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </CardHeader>
        <CardContent>
          {topMatchingJobs.length > 0 ? (
            <div className="space-y-3">
              {topMatchingJobs.map((job) => (
                <div 
                  key={job.id} 
                  className="flex items-center gap-4 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors group"
                >
                  <div className={cn(
                    'w-12 h-12 rounded-xl flex items-center justify-center font-bold text-sm shrink-0',
                    getScoreBg(job.matchScore || 0),
                    getScoreColor(job.matchScore || 0)
                  )}>
                    {job.matchScore}%
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium truncate">{job.title}</span>
                      {job.url && (
                        <a 
                          href={job.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {job.company} • {job.location || 'Remote'}
                    </p>
                  </div>
                  {job.resumeAlignmentLevel && job.resumeAlignmentLevel !== 'Unknown' && (
                    <Badge 
                      variant="outline"
                      className={cn('text-xs shrink-0 border', ALIGNMENT_COLORS[job.resumeAlignmentLevel])}
                    >
                      {job.resumeAlignmentLevel}
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-muted-foreground text-sm">No jobs imported yet</p>
              <div className="flex justify-center gap-3 mt-4">
                <Button variant="outline" size="sm" onClick={() => navigate('/jobs')}>
                  Import CSV
                </Button>
                <Button size="sm" className="gradient-primary text-white" onClick={() => navigate('/live-jobs')}>
                  <Sparkles className="h-4 w-4 mr-2" />
                  Fetch Live Jobs
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
