// ============================================================================
// Live Jobs Page - Real-time Job Scraping from Free APIs
// ============================================================================

import { useState, useCallback } from 'react';
import { 
  Search, 
  Loader2, 
  Download, 
  RefreshCw, 
  ExternalLink, 
  Filter,
  Sparkles,
  TrendingUp,
  Zap,
  Globe,
  CheckCircle2,
  XCircle,
  Clock,
  Briefcase
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { searchAllJobAPIs, getAPIStatus, clearJobCache } from '@/lib/job-scraper';
import { exportJobsToCSV, analyzeSkillTrends } from '@/lib/job-matching';
import { JobMatch } from '@/types/resume';
import { cn } from '@/lib/utils';

export default function LiveJobsPage() {
  const { toast } = useToast();
  const [fetchedJobs, setFetchedJobs] = useState<JobMatch[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchProgress, setSearchProgress] = useState('');
  const [customKeywords, setCustomKeywords] = useState('');
  const [lastSearchSources, setLastSearchSources] = useState<{ name: string; count: number; success: boolean }[]>([]);
  const [filterScore, setFilterScore] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('score');

  // Skills can be manually entered
  const userSkills: string[] = [];

  // Suggested search keywords
  const suggestedKeywords = [
    'React Developer',
    'Python Engineer',
    'DevOps',
    'Data Scientist',
    'Product Manager',
    'UX Designer',
    'Full Stack',
    'Machine Learning',
  ];

  // Fetch jobs from free APIs
  const handleFetchJobs = useCallback(async () => {
    const keywords = customKeywords.trim()
      ? customKeywords.split(',').map(k => k.trim()).filter(Boolean)
      : userSkills.slice(0, 5);

    if (keywords.length === 0) {
      toast({
        title: 'Enter search keywords',
        description: 'Type skills or job titles to search for',
        variant: 'destructive',
      });
      return;
    }

    setIsSearching(true);
    setSearchProgress('Connecting to job APIs...');

    try {
      const result = await searchAllJobAPIs(
        { keywords, remote: true },
        userSkills.length > 0 ? userSkills : keywords,
        {
          maxResults: 100,
          onProgress: (source, count) => {
            setSearchProgress(`Found ${count} jobs from ${source}...`);
          },
        }
      );

      setFetchedJobs(result.jobs);
      setLastSearchSources(result.sources);

      const successfulSources = result.sources.filter(s => s.success && s.count > 0);
      toast({
        title: '✨ Job search complete!',
        description: `Found ${result.jobs.length} jobs from ${successfulSources.length} sources`,
      });
    } catch (error) {
      toast({
        title: 'Search failed',
        description: error instanceof Error ? error.message : 'Failed to fetch jobs',
        variant: 'destructive',
      });
    } finally {
      setIsSearching(false);
      setSearchProgress('');
    }
  }, [customKeywords, userSkills, toast]);

  // Export jobs to CSV
  const handleExportJobs = useCallback(() => {
    if (fetchedJobs.length === 0) {
      toast({ title: 'No jobs to export', variant: 'destructive' });
      return;
    }

    const csv = exportJobsToCSV(fetchedJobs);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `live-jobs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({ title: 'Jobs exported!', description: `${fetchedJobs.length} jobs saved to CSV` });
  }, [fetchedJobs, toast]);

  // Clear cache and refresh
  const handleClearCache = useCallback(() => {
    clearJobCache();
    setFetchedJobs([]);
    setLastSearchSources([]);
    toast({ title: 'Cache cleared', description: 'Ready for fresh job search' });
  }, [toast]);

  // Filter and sort jobs
  const filteredJobs = fetchedJobs
    .filter(job => {
      if (filterScore === 'all') return true;
      if (filterScore === 'high') return job.matchScore >= 70;
      if (filterScore === 'medium') return job.matchScore >= 40 && job.matchScore < 70;
      if (filterScore === 'low') return job.matchScore < 40;
      return true;
    })
    .sort((a, b) => {
      if (sortBy === 'score') return b.matchScore - a.matchScore;
      if (sortBy === 'date') return (b.postedDate?.getTime() || 0) - (a.postedDate?.getTime() || 0);
      if (sortBy === 'company') return a.company.localeCompare(b.company);
      return 0;
    });

  // Analyze skill trends
  const skillTrends = analyzeSkillTrends(fetchedJobs);

  // Stats
  const highMatchCount = fetchedJobs.filter(j => j.matchScore >= 70).length;
  const avgScore = fetchedJobs.length > 0 
    ? Math.round(fetchedJobs.reduce((sum, j) => sum + j.matchScore, 0) / fetchedJobs.length)
    : 0;

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">
          <span className="gradient-text">Live Job Search</span>
        </h1>
        <p className="text-muted-foreground mt-1">
          Fetch real-time job listings from free public APIs • 100% Privacy-First
        </p>
      </div>

      {/* Search Section */}
      <Card className="glass border-primary/20">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg gradient-primary flex items-center justify-center">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            Search Jobs
          </CardTitle>
          <CardDescription>
            Enter skills or job titles to search across Remotive, Jobicy, and Arbeitnow
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Input */}
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="e.g., React, Python, DevOps, Data Science..."
                value={customKeywords}
                onChange={(e) => setCustomKeywords(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleFetchJobs()}
                className="pl-10"
              />
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={handleFetchJobs} 
                disabled={isSearching}
                className="gradient-primary text-white glow-primary"
              >
                {isSearching ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Zap className="h-4 w-4 mr-2" />
                    Search Jobs
                  </>
                )}
              </Button>
              <Button variant="outline" size="icon" onClick={handleClearCache} title="Clear cache">
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Suggested Keywords */}
          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-muted-foreground">Quick search:</span>
            {suggestedKeywords.map((keyword) => (
              <Badge
                key={keyword}
                variant="outline"
                className="cursor-pointer hover:bg-primary/20 hover:border-primary/50 transition-colors"
                onClick={() => {
                  setCustomKeywords(keyword);
                  handleFetchJobs();
                }}
              >
                {keyword}
              </Badge>
            ))}
          </div>

          {/* Progress */}
          {isSearching && (
            <div className="space-y-2">
              <Progress value={66} className="h-2" />
              <p className="text-sm text-muted-foreground flex items-center gap-2">
                <Loader2 className="h-3 w-3 animate-spin" />
                {searchProgress}
              </p>
            </div>
          )}

          {/* API Status */}
          <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-border">
            <span className="text-xs text-muted-foreground flex items-center gap-1">
              <Globe className="h-3 w-3" />
              API Sources:
            </span>
            {lastSearchSources.length > 0 ? (
              lastSearchSources.map((source) => (
                <Badge
                  key={source.name}
                  variant={source.success ? 'default' : 'secondary'}
                  className={cn(
                    "text-xs",
                    source.success && source.count > 0 && "bg-success/20 text-success border-success/30"
                  )}
                >
                  {source.success ? (
                    <CheckCircle2 className="h-3 w-3 mr-1" />
                  ) : (
                    <XCircle className="h-3 w-3 mr-1" />
                  )}
                  {source.name}: {source.count}
                </Badge>
              ))
            ) : (
              getAPIStatus().map((api) => (
                <Badge key={api.name} variant="outline" className="text-xs">
                  {api.name}
                </Badge>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {fetchedJobs.length > 0 && (
        <>
          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="glass-hover">
              <CardContent className="pt-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Briefcase className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{fetchedJobs.length}</p>
                    <p className="text-xs text-muted-foreground">Total Jobs</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-hover">
              <CardContent className="pt-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-success/20 flex items-center justify-center">
                    <CheckCircle2 className="h-5 w-5 text-success" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{highMatchCount}</p>
                    <p className="text-xs text-muted-foreground">High Match (70%+)</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-hover">
              <CardContent className="pt-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-accent/20 flex items-center justify-center">
                    <TrendingUp className="h-5 w-5 text-accent" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{avgScore}%</p>
                    <p className="text-xs text-muted-foreground">Avg Match Score</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="glass-hover">
              <CardContent className="pt-4">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-warning/20 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{lastSearchSources.filter(s => s.success).length}</p>
                    <p className="text-xs text-muted-foreground">API Sources</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters & Actions */}
          <div className="flex flex-col sm:flex-row justify-between gap-4">
            <div className="flex flex-wrap gap-3">
              <Select value={filterScore} onValueChange={setFilterScore}>
                <SelectTrigger className="w-[160px]">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter by score" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Jobs</SelectItem>
                  <SelectItem value="high">High Match (70%+)</SelectItem>
                  <SelectItem value="medium">Medium (40-69%)</SelectItem>
                  <SelectItem value="low">Low (&lt;40%)</SelectItem>
                </SelectContent>
              </Select>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[160px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="score">Match Score</SelectItem>
                  <SelectItem value="date">Date Posted</SelectItem>
                  <SelectItem value="company">Company</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button variant="outline" onClick={handleExportJobs}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>

          {/* Trending Skills */}
          {skillTrends.trending.length > 0 && (
            <Card className="glass-hover">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-accent" />
                  Trending Skills in These Jobs
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {skillTrends.trending.map((skill, i) => (
                    <Badge
                      key={skill}
                      variant={i < 3 ? 'default' : 'secondary'}
                      className={cn(i < 3 && 'bg-accent/20 text-accent border-accent/30')}
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Job Cards */}
          <Tabs defaultValue="cards" className="space-y-4">
            <TabsList>
              <TabsTrigger value="cards">Cards ({filteredJobs.length})</TabsTrigger>
              <TabsTrigger value="compact">Compact List</TabsTrigger>
            </TabsList>

            <TabsContent value="cards" className="space-y-3">
              <div className="grid gap-4 max-h-[800px] overflow-y-auto pr-2 scrollbar-thin">
                {filteredJobs.slice(0, 50).map((job) => (
                  <JobCard key={job.id} job={job} />
                ))}
              </div>
              {filteredJobs.length > 50 && (
                <p className="text-center text-sm text-muted-foreground py-2">
                  Showing 50 of {filteredJobs.length} jobs. Export to CSV to see all.
                </p>
              )}
            </TabsContent>

            <TabsContent value="compact">
              <Card>
                <CardContent className="pt-4">
                  <div className="divide-y divide-border max-h-[600px] overflow-y-auto scrollbar-thin">
                    {filteredJobs.slice(0, 100).map((job) => (
                      <div key={job.id} className="flex items-center gap-4 py-3 hover:bg-muted/50 px-2 rounded-lg transition-colors">
                        <div className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center font-bold text-sm shrink-0",
                          job.matchScore >= 70 ? "bg-success/20 text-success" :
                          job.matchScore >= 40 ? "bg-warning/20 text-warning" :
                          "bg-muted text-muted-foreground"
                        )}>
                          {job.matchScore}%
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium truncate">{job.title}</span>
                            {job.url && (
                              <a href={job.url} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80">
                                <ExternalLink className="h-3 w-3" />
                              </a>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground">{job.company} • {job.location}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </>
      )}

      {/* Empty State */}
      {fetchedJobs.length === 0 && !isSearching && (
        <Card className="glass border-dashed">
          <CardContent className="pt-12 pb-12">
            <div className="text-center space-y-4">
              <div className="h-16 w-16 rounded-2xl gradient-primary mx-auto flex items-center justify-center">
                <Search className="h-8 w-8 text-white" />
              </div>
              <div>
                <h3 className="text-lg font-semibold">Search for Jobs</h3>
                <p className="text-muted-foreground text-sm mt-1">
                  Enter keywords above to fetch real-time job listings from free APIs
                </p>
              </div>
              <div className="flex justify-center gap-2 flex-wrap pt-2">
                {suggestedKeywords.slice(0, 4).map((keyword) => (
                  <Button
                    key={keyword}
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setCustomKeywords(keyword);
                    }}
                  >
                    {keyword}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Job Card Component
function JobCard({ job }: { job: JobMatch }) {
  return (
    <Card className="glass-hover group">
      <CardContent className="pt-4">
        <div className="flex items-start gap-4">
          {/* Score */}
          <div className={cn(
            "w-14 h-14 rounded-xl flex flex-col items-center justify-center font-bold shrink-0",
            job.matchScore >= 70 ? "bg-success/20 text-success glow-success" :
            job.matchScore >= 40 ? "bg-warning/20 text-warning" :
            "bg-muted text-muted-foreground"
          )}>
            <span className="text-xl">{job.matchScore}</span>
            <span className="text-[10px]">match</span>
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-semibold">{job.title}</h4>
                  {job.url && (
                    <a
                      href={job.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-primary opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                </div>
                <p className="text-sm text-muted-foreground">{job.company} • {job.location}</p>
              </div>
              {job.salary && (
                <Badge variant="outline" className="shrink-0 text-success border-success/30">
                  {job.salary}
                </Badge>
              )}
            </div>

            {/* Matching Skills */}
            {job.matchingSkills.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {job.matchingSkills.slice(0, 6).map((skill) => (
                  <Badge key={skill} variant="secondary" className="text-xs bg-success/10 text-success border-success/20">
                    ✓ {skill}
                  </Badge>
                ))}
                {job.matchingSkills.length > 6 && (
                  <Badge variant="outline" className="text-xs">
                    +{job.matchingSkills.length - 6}
                  </Badge>
                )}
              </div>
            )}

            {/* Missing Skills */}
            {job.missingSkills.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {job.missingSkills.slice(0, 4).map((skill) => (
                  <Badge key={skill} variant="outline" className="text-xs text-warning border-warning/30">
                    {skill}
                  </Badge>
                ))}
              </div>
            )}

            {/* Description Preview */}
            {job.description && (
              <p className="text-xs text-muted-foreground mt-3 line-clamp-2">
                {job.description}
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
