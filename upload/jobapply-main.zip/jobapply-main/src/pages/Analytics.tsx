import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, AreaChart, Area, RadarChart, PolarGrid, PolarAngleAxis, Radar } from 'recharts';
import { useJobContext } from "@/context/JobContext";
import { SOURCE_LABELS, EXPERIENCE_LABELS } from "@/types/job";
import { TrendingUp, BarChart3, PieChartIcon, Target } from "lucide-react";

export default function Analytics() {
  const { jobs, stats } = useJobContext();

  // Jobs by source
  const sourceData = Object.entries(stats.bySource).map(([source, count]) => ({
    name: SOURCE_LABELS[source as keyof typeof SOURCE_LABELS] || source,
    value: count,
  }));

  // Jobs by alignment with colors
  const alignmentData = Object.entries(stats.byAlignment).map(([level, count]) => ({
    name: level,
    value: count,
    color: level === 'Strong Match' ? 'hsl(142, 71%, 45%)' : 
           level === 'Good Match' ? 'hsl(200, 98%, 48%)' : 
           level === 'Stretch Role' ? 'hsl(38, 92%, 50%)' : 'hsl(215, 16%, 47%)',
  }));

  // Match score distribution
  const scoreRanges = [
    { range: '0-30', count: jobs.filter(j => (j.matchScore || 0) <= 30).length, fill: 'hsl(var(--muted-foreground))' },
    { range: '31-50', count: jobs.filter(j => (j.matchScore || 0) > 30 && (j.matchScore || 0) <= 50).length, fill: 'hsl(var(--warning))' },
    { range: '51-70', count: jobs.filter(j => (j.matchScore || 0) > 50 && (j.matchScore || 0) <= 70).length, fill: 'hsl(var(--info))' },
    { range: '71-100', count: jobs.filter(j => (j.matchScore || 0) > 70).length, fill: 'hsl(var(--success))' },
  ];

  // Top companies
  const companyCount: Record<string, number> = {};
  jobs.forEach(job => {
    companyCount[job.company] = (companyCount[job.company] || 0) + 1;
  });
  const topCompanies = Object.entries(companyCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([name, count]) => ({ name: name.slice(0, 20), count }));

  // Experience distribution
  const experienceData = Object.entries(
    jobs.reduce((acc, job) => {
      const level = EXPERIENCE_LABELS[job.experienceLevel] || 'Unknown';
      acc[level] = (acc[level] || 0) + 1;
      return acc;
    }, {} as Record<string, number>)
  ).map(([name, value]) => ({ name, value }));

  // Skill radar data (mock based on common skills)
  const skillRadarData = [
    { skill: 'Technical', value: Math.min(100, stats.avgMatchScore + 15) },
    { skill: 'Experience', value: Math.min(100, stats.avgMatchScore + 5) },
    { skill: 'Location', value: Math.min(100, stats.avgMatchScore + 20) },
    { skill: 'Industry', value: Math.min(100, stats.avgMatchScore) },
    { skill: 'Salary', value: Math.min(100, stats.avgMatchScore - 10) },
  ];

  const COLORS = ['hsl(var(--primary))', 'hsl(var(--success))', 'hsl(var(--warning))', 'hsl(var(--accent))', 'hsl(var(--info))', 'hsl(var(--destructive))'];

  if (jobs.length === 0) {
    return (
      <div className="space-y-6 animate-fade-in">
        <div>
          <h1 className="text-3xl font-bold">
            <span className="gradient-text">Analytics</span>
          </h1>
          <p className="text-muted-foreground mt-1">Visualize your job search data</p>
        </div>
        <Card className="glass border-dashed">
          <CardContent className="py-16 text-center">
            <div className="h-16 w-16 rounded-2xl bg-muted mx-auto flex items-center justify-center mb-4">
              <BarChart3 className="h-8 w-8 text-muted-foreground" />
            </div>
            <p className="text-muted-foreground">
              No job data available. Import jobs or fetch live listings to see analytics.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-fade-in">
      <div>
        <h1 className="text-3xl font-bold">
          <span className="gradient-text">Analytics</span>
        </h1>
        <p className="text-muted-foreground mt-1">Insights from {stats.total} jobs in your database</p>
      </div>

      {/* Top Row - Key Charts */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-primary/20 flex items-center justify-center">
                <BarChart3 className="h-4 w-4 text-primary" />
              </div>
              Jobs by Source
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={sourceData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                <XAxis type="number" className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="name" width={80} className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
                <Bar dataKey="value" fill="hsl(var(--primary))" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-success/20 flex items-center justify-center">
                <PieChartIcon className="h-4 w-4 text-success" />
              </div>
              Resume Alignment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={alignmentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={{ stroke: 'hsl(var(--muted-foreground))' }}
                >
                  {alignmentData.map((entry, index) => (
                    <Cell key={index} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Middle Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-accent/20 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-accent" />
              </div>
              Match Score Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={scoreRanges}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="range" className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <YAxis className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="count" 
                  stroke="hsl(var(--primary))" 
                  fill="hsl(var(--primary) / 0.3)"
                  strokeWidth={2}
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-warning/20 flex items-center justify-center">
                <Target className="h-4 w-4 text-warning" />
              </div>
              Fit Analysis Radar
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <RadarChart data={skillRadarData}>
                <PolarGrid stroke="hsl(var(--border))" />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 12, fill: 'hsl(var(--muted-foreground))' }} />
                <Radar 
                  name="Your Fit" 
                  dataKey="value" 
                  stroke="hsl(var(--primary))" 
                  fill="hsl(var(--primary) / 0.3)" 
                  strokeWidth={2}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid lg:grid-cols-2 gap-6">
        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Experience Level</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={experienceData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                  labelLine={{ stroke: 'hsl(var(--muted-foreground))' }}
                >
                  {experienceData.map((_, index) => (
                    <Cell key={index} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="glass-hover">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Top Companies</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={topCompanies} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" horizontal={false} />
                <XAxis type="number" className="text-muted-foreground" tick={{ fontSize: 12 }} />
                <YAxis type="category" dataKey="name" width={120} className="text-muted-foreground" tick={{ fontSize: 11 }} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '12px',
                  }}
                />
                <Bar dataKey="count" fill="hsl(var(--accent))" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
