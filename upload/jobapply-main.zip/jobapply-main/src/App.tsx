import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Layout } from "./components/Layout";
import { JobProvider } from "./context/JobContext";
import { LinkedInProvider } from "./context/LinkedInContext";
import { RouteErrorBoundary } from "./components/RouteErrorBoundary";
import Dashboard from "./pages/Dashboard";
import JobListingsPage from "./pages/JobListingsPage";
import LiveJobsPage from "./pages/LiveJobsPage";
import Analytics from "./pages/Analytics";
import LinkedInIntelligencePage from "./pages/LinkedInIntelligencePage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <JobProvider>
        <LinkedInProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <RouteErrorBoundary>
              <Routes>
                <Route path="/" element={<Layout />}>
                  <Route index element={<Dashboard />} />
                  <Route path="jobs" element={<JobListingsPage />} />
                  <Route path="live-jobs" element={<LiveJobsPage />} />
                  <Route path="analytics" element={<Analytics />} />
                  <Route path="linkedin" element={<LinkedInIntelligencePage />} />
                </Route>
                <Route path="*" element={<NotFound />} />
              </Routes>
            </RouteErrorBoundary>
          </BrowserRouter>
        </LinkedInProvider>
      </JobProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
