import type { Job, JobSource, ExperienceLevel, JobType, ResumeAlignmentLevel } from '@/types/job';

// Generate unique ID
const generateId = (): string => {
  return `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Normalize source string to JobSource type
const normalizeSource = (source: string): JobSource => {
  const normalized = source.toLowerCase().trim();
  const sourceMap: Record<string, JobSource> = {
    linkedin: 'linkedin',
    indeed: 'indeed',
    naukri: 'naukri',
    wellfound: 'wellfound',
    angellist: 'wellfound',
    glassdoor: 'glassdoor',
  };
  return sourceMap[normalized] || 'other';
};

// Parse experience range to normalized level
const normalizeExperience = (exp: string): ExperienceLevel => {
  const normalized = exp.toLowerCase().trim();
  
  // Handle ranges like "1-2 years", "3+ years", etc.
  const match = normalized.match(/(\d+)/);
  if (match) {
    const years = parseInt(match[1]);
    if (years <= 1) return 'entry';
    if (years <= 2) return 'junior';
    if (years <= 4) return 'mid';
    if (years <= 7) return 'senior';
    if (years <= 10) return 'lead';
    return 'executive';
  }
  
  if (normalized.includes('entry') || normalized.includes('fresher')) return 'entry';
  if (normalized.includes('junior') || normalized.includes('jr')) return 'junior';
  if (normalized.includes('mid') || normalized.includes('intermediate')) return 'mid';
  if (normalized.includes('senior') || normalized.includes('sr')) return 'senior';
  if (normalized.includes('lead') || normalized.includes('principal')) return 'lead';
  if (normalized.includes('exec') || normalized.includes('director') || normalized.includes('vp')) return 'executive';
  return 'unknown';
};

// Normalize job type based on work_from_home_type and is_remote
const normalizeJobType = (type: string, isRemote?: boolean, workFromHome?: string): JobType => {
  // Check work from home type first
  if (workFromHome) {
    const wfh = workFromHome.toLowerCase().trim();
    if (wfh === 'hybrid') return 'hybrid';
    if (wfh === 'remote') return 'remote';
  }
  
  if (isRemote) return 'remote';
  
  const normalized = type.toLowerCase().trim();
  if (normalized.includes('full')) return 'full-time';
  if (normalized.includes('part')) return 'part-time';
  if (normalized.includes('contract') || normalized.includes('freelance')) return 'contract';
  if (normalized.includes('intern')) return 'internship';
  if (normalized.includes('remote')) return 'remote';
  if (normalized.includes('hybrid')) return 'hybrid';
  return 'unknown';
};

// Normalize resume alignment level
const normalizeAlignmentLevel = (level: string): ResumeAlignmentLevel => {
  const normalized = level.trim();
  if (normalized === 'Strong Match') return 'Strong Match';
  if (normalized === 'Good Match') return 'Good Match';
  if (normalized === 'Stretch Role') return 'Stretch Role';
  if (normalized === 'Ignore') return 'Ignore';
  return 'Unknown';
};

// Parse CSV string to array of objects
const parseCSVString = (csv: string): Record<string, string>[] => {
  const lines = csv.split('\n').filter(line => line.trim());
  if (lines.length < 2) return [];

  // Parse header
  const headers = parseCSVLine(lines[0]);
  
  // Parse data rows
  return lines.slice(1).map(line => {
    const values = parseCSVLine(line);
    const row: Record<string, string> = {};
    headers.forEach((header, index) => {
      row[header.toLowerCase().trim().replace(/ /g, '_')] = values[index] || '';
    });
    return row;
  });
};

// Parse a single CSV line handling quoted values
const parseCSVLine = (line: string): string[] => {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') {
        current += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  
  result.push(current.trim());
  return result;
};

// Get column value from row - supports exact match and partial match
const getColumnValue = (row: Record<string, string>, possibleNames: string[]): string => {
  // First try exact match
  for (const name of possibleNames) {
    const normalizedName = name.toLowerCase().replace(/ /g, '_');
    if (row[normalizedName]) return row[normalizedName];
  }
  // Then try partial match
  for (const name of possibleNames) {
    const key = Object.keys(row).find(k => k.toLowerCase().includes(name.toLowerCase()));
    if (key && row[key]) return row[key];
  }
  return '';
};

// Main parse function - handles JobSpy backend format
export const parseJobsCSV = (csvContent: string): Job[] => {
  const rows = parseCSVString(csvContent);
  const jobs: Job[] = [];
  const seenUrls = new Set<string>();

  for (const row of rows) {
    const url = getColumnValue(row, ['job_url', 'url', 'link', 'joburl', 'job link']);
    
    // Skip duplicates by URL
    if (url && seenUrls.has(url)) continue;
    if (url) seenUrls.add(url);

    const title = getColumnValue(row, ['title', 'job_title', 'jobtitle', 'position', 'role']);
    const company = getColumnValue(row, ['company_name', 'company', 'companyname', 'employer', 'organization']);
    
    // Skip rows without essential data
    if (!title || !company) continue;

    // Parse backend-specific fields
    const isRemoteStr = getColumnValue(row, ['is_remote']);
    const isRemote = isRemoteStr.toLowerCase() === 'true';
    const workFromHomeType = getColumnValue(row, ['work_from_home_type']);
    const experienceRange = getColumnValue(row, ['experience_range', 'experience', 'level']);
    const matchScoreStr = getColumnValue(row, ['match_score']);
    const matchScore = matchScoreStr ? parseInt(matchScoreStr) : undefined;

    const job: Job = {
      id: generateId(),
      title,
      company,
      location: getColumnValue(row, ['location', 'city', 'place', 'job_location']),
      experienceLevel: normalizeExperience(experienceRange),
      experienceRange: experienceRange || undefined,
      jobType: normalizeJobType(
        getColumnValue(row, ['type', 'job_type', 'jobtype', 'employment_type']),
        isRemote,
        workFromHomeType
      ),
      postedDate: getColumnValue(row, ['date', 'posted', 'posted_date', 'posteddate', 'date_posted', 'created']),
      source: normalizeSource(
        getColumnValue(row, ['site', 'source', 'platform', 'job_source'])
      ),
      url: url || '#',
      scrapeTimestamp: getColumnValue(row, ['timestamp', 'scraped', 'scrape_timestamp', 'created_at']) || new Date().toISOString(),
      description: getColumnValue(row, ['description', 'job_description', 'details', 'summary']),
      salary: getColumnValue(row, ['salary', 'compensation', 'pay', 'salary_range']),
      // JobSpy specific fields
      keySkills: getColumnValue(row, ['key_skills', 'skills']) || undefined,
      matchScore: matchScore,
      whyThisJobFits: getColumnValue(row, ['why_this_job_fits', 'fit_reason']) || undefined,
      missingSkills: getColumnValue(row, ['missing_skills']) || undefined,
      resumeAlignmentLevel: normalizeAlignmentLevel(
        getColumnValue(row, ['resume_alignment_level', 'alignment'])
      ),
      isRemote,
      workFromHomeType: workFromHomeType || undefined,
    };

    jobs.push(job);
  }

  return jobs;
};

// Export jobs to CSV
export const exportJobsToCSV = (jobs: Job[]): string => {
  const headers = [
    'Title',
    'Company',
    'Location',
    'Experience Range',
    'Job Type',
    'Source',
    'URL',
    'Key Skills',
    'Match Score',
    'Why This Job Fits',
    'Missing Skills',
    'Resume Alignment Level',
    'Is Remote',
    'Work From Home Type',
  ];

  const escapeCSV = (value: string | number | boolean | undefined): string => {
    if (value === undefined || value === null) return '';
    const str = String(value);
    if (str.includes(',') || str.includes('"') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const rows = jobs.map(job => [
    escapeCSV(job.title),
    escapeCSV(job.company),
    escapeCSV(job.location),
    escapeCSV(job.experienceRange),
    escapeCSV(job.jobType),
    escapeCSV(job.source),
    escapeCSV(job.url),
    escapeCSV(job.keySkills),
    escapeCSV(job.matchScore),
    escapeCSV(job.whyThisJobFits),
    escapeCSV(job.missingSkills),
    escapeCSV(job.resumeAlignmentLevel),
    escapeCSV(job.isRemote),
    escapeCSV(job.workFromHomeType),
  ]);

  return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
};

// Download CSV file
export const downloadCSV = (jobs: Job[], filename?: string): void => {
  const csv = exportJobsToCSV(jobs);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  
  const date = new Date().toISOString().split('T')[0].replace(/-/g, '_');
  link.setAttribute('href', url);
  link.setAttribute('download', filename || `jobs_${date}.csv`);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
