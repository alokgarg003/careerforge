// ============================================================================
// Job Matching Engine (Enhanced)
// ============================================================================
// Matches user skills to job listings with improved scoring.
// All processing happens locally - privacy-first design.
// ============================================================================

import { JobMatch, JobSearchQuery } from '@/types/resume';

// === Enhanced Skill Keywords for Matching ===
const SKILL_ALIASES: Record<string, string[]> = {
  'javascript': ['js', 'node', 'nodejs', 'node.js', 'es6', 'es2015', 'ecmascript'],
  'typescript': ['ts'],
  'python': ['py', 'django', 'flask', 'fastapi', 'pytorch', 'tensorflow'],
  'react': ['reactjs', 'react.js', 'redux', 'next.js', 'nextjs', 'react native'],
  'vue': ['vuejs', 'vue.js', 'nuxt', 'nuxt.js'],
  'angular': ['angularjs', 'ng'],
  'aws': ['amazon web services', 'ec2', 's3', 'lambda', 'cloudformation'],
  'gcp': ['google cloud', 'google cloud platform', 'bigquery'],
  'azure': ['microsoft azure', 'azure devops'],
  'docker': ['containers', 'containerization', 'dockerfile'],
  'kubernetes': ['k8s', 'helm', 'eks', 'gke', 'aks'],
  'machine learning': ['ml', 'ai', 'artificial intelligence', 'deep learning', 'neural network'],
  'sql': ['mysql', 'postgresql', 'postgres', 'database', 'db', 'oracle', 'sqlite'],
  'nosql': ['mongodb', 'redis', 'dynamodb', 'cassandra', 'couchdb'],
  'devops': ['cicd', 'ci/cd', 'continuous integration', 'continuous deployment'],
  'agile': ['scrum', 'kanban', 'sprint', 'jira'],
};

// === Extended Keywords for Job Analysis ===
const JOB_KEYWORDS = [
  // Programming Languages
  'python', 'javascript', 'typescript', 'java', 'c++', 'c#', 'go', 'golang', 'rust', 'ruby', 'php', 'swift', 'kotlin', 'scala', 'r',
  // Frontend
  'react', 'vue', 'angular', 'svelte', 'html', 'css', 'sass', 'tailwind', 'bootstrap', 'jquery', 'webpack', 'vite',
  // Backend
  'node', 'express', 'django', 'flask', 'fastapi', 'spring', 'rails', 'laravel', 'asp.net', 'graphql', 'rest', 'api',
  // Database
  'sql', 'postgresql', 'mysql', 'mongodb', 'redis', 'elasticsearch', 'dynamodb', 'cassandra', 'sqlite', 'oracle',
  // Cloud
  'aws', 'azure', 'gcp', 'cloud', 'serverless', 'lambda', 'ec2', 's3',
  // DevOps
  'docker', 'kubernetes', 'k8s', 'terraform', 'ansible', 'jenkins', 'github actions', 'gitlab ci', 'ci/cd',
  // Data & AI
  'machine learning', 'ml', 'ai', 'deep learning', 'tensorflow', 'pytorch', 'data science', 'data engineering',
  'pandas', 'numpy', 'spark', 'hadoop', 'etl', 'analytics', 'tableau', 'power bi',
  // General
  'git', 'linux', 'unix', 'agile', 'scrum', 'microservices', 'architecture', 'testing', 'tdd', 'bdd',
];

// === Generate Search Query from Skills ===
export function buildSearchQuery(
  skills: string[],
  options?: {
    location?: string;
    remote?: boolean;
    experienceLevel?: string;
  }
): string {
  // Prioritize technical skills for job search
  const prioritySkills = skills.slice(0, 5);
  const query = prioritySkills.join(' ');
  
  let fullQuery = query;
  if (options?.location) {
    fullQuery += ` ${options.location}`;
  }
  if (options?.remote) {
    fullQuery += ' remote';
  }
  if (options?.experienceLevel) {
    fullQuery += ` ${options.experienceLevel}`;
  }
  
  return fullQuery;
}

// === Enhanced Match Score Calculation ===
export function calculateMatchScore(
  jobDescription: string,
  userSkills: string[],
): { score: number; matchingSkills: string[]; missingKeywords: string[] } {
  const jobLower = jobDescription.toLowerCase();
  const matchingSkills: string[] = [];
  const expandedUserSkills = new Set<string>();
  
  // Expand user skills with aliases
  for (const skill of userSkills) {
    const lower = skill.toLowerCase();
    expandedUserSkills.add(lower);
    
    // Add aliases
    for (const [base, aliases] of Object.entries(SKILL_ALIASES)) {
      if (lower === base || aliases.includes(lower)) {
        expandedUserSkills.add(base);
        aliases.forEach(a => expandedUserSkills.add(a));
      }
    }
  }
  
  // Check for matching skills
  for (const skill of userSkills) {
    const lower = skill.toLowerCase();
    if (jobLower.includes(lower)) {
      matchingSkills.push(skill);
    } else {
      // Check aliases
      for (const [base, aliases] of Object.entries(SKILL_ALIASES)) {
        if (lower === base && aliases.some(a => jobLower.includes(a))) {
          matchingSkills.push(skill);
          break;
        }
        if (aliases.includes(lower) && jobLower.includes(base)) {
          matchingSkills.push(skill);
          break;
        }
      }
    }
  }
  
  // Find missing keywords from job description
  const missingKeywords: string[] = [];
  for (const keyword of JOB_KEYWORDS) {
    if (jobLower.includes(keyword) && !expandedUserSkills.has(keyword)) {
      missingKeywords.push(keyword);
    }
  }
  
  // Calculate score with weighting
  const totalRelevantKeywords = matchingSkills.length + missingKeywords.length;
  let score = 50; // Base score
  
  if (totalRelevantKeywords > 0) {
    // Matching skills contribute more than missing keywords penalty
    const matchWeight = matchingSkills.length * 12;
    const missWeight = missingKeywords.length * 3;
    score = Math.round((matchWeight / (matchWeight + missWeight)) * 100);
  }
  
  // Bonus for having many matches
  if (matchingSkills.length >= 5) score = Math.min(100, score + 10);
  if (matchingSkills.length >= 8) score = Math.min(100, score + 5);
  
  return {
    score: Math.min(100, Math.max(0, score)),
    matchingSkills: [...new Set(matchingSkills)],
    missingKeywords: [...new Set(missingKeywords)].slice(0, 8),
  };
}

// === Parse Job from Manual Entry ===
export function createManualJob(
  title: string,
  company: string,
  description: string,
  userSkills: string[],
  url?: string,
  location?: string,
): JobMatch {
  const { score, matchingSkills, missingKeywords } = calculateMatchScore(description, userSkills);
  
  return {
    id: `manual-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    title,
    company,
    location: location || '',
    description,
    url,
    source: 'manual',
    matchScore: score,
    matchingSkills,
    missingSkills: missingKeywords,
    matchReasons: [
      `${matchingSkills.length} matching skills found`,
      score >= 80 ? 'Excellent match!' : score >= 70 ? 'Strong match' : score >= 50 ? 'Moderate match' : 'Consider upskilling',
    ],
    saved: false,
    applied: false,
  };
}

// === Rank Jobs by Match ===
export function rankJobsByMatch(
  jobs: JobMatch[],
  userSkills: string[],
): JobMatch[] {
  // Recalculate scores and sort
  const scoredJobs = jobs.map(job => {
    const { score, matchingSkills, missingKeywords } = calculateMatchScore(
      job.description,
      userSkills,
    );
    
    return {
      ...job,
      matchScore: score,
      matchingSkills,
      missingSkills: missingKeywords,
      matchReasons: [
        `${matchingSkills.length} matching skills`,
        score >= 70 ? 'Good alignment' : 'Skills gap identified',
      ],
    };
  });
  
  return scoredJobs.sort((a, b) => b.matchScore - a.matchScore);
}

// === Generate Match Insights ===
export function generateMatchInsights(
  jobs: JobMatch[],
  userSkills: string[],
): {
  averageScore: number;
  mostRequestedSkills: { skill: string; count: number }[];
  skillGaps: string[];
  bestMatchingSkills: string[];
  recommendations: string[];
} {
  if (jobs.length === 0) {
    return {
      averageScore: 0,
      mostRequestedSkills: [],
      skillGaps: [],
      bestMatchingSkills: [],
      recommendations: ['Add more jobs to see insights'],
    };
  }
  
  const averageScore = Math.round(
    jobs.reduce((sum, job) => sum + job.matchScore, 0) / jobs.length
  );
  
  // Count skill mentions across all jobs
  const skillCounts: Record<string, number> = {};
  const missingCounts: Record<string, number> = {};
  const matchingCounts: Record<string, number> = {};
  
  for (const job of jobs) {
    for (const skill of job.matchingSkills) {
      matchingCounts[skill] = (matchingCounts[skill] || 0) + 1;
    }
    for (const skill of job.missingSkills) {
      missingCounts[skill] = (missingCounts[skill] || 0) + 1;
    }
    
    // Count all mentioned skills
    const allMentioned = [...job.matchingSkills, ...job.missingSkills];
    for (const skill of allMentioned) {
      skillCounts[skill] = (skillCounts[skill] || 0) + 1;
    }
  }
  
  const mostRequestedSkills = Object.entries(skillCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10)
    .map(([skill, count]) => ({ skill, count }));
  
  const skillGaps = Object.entries(missingCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6)
    .map(([skill]) => skill);
  
  const bestMatchingSkills = Object.entries(matchingCounts)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 6)
    .map(([skill]) => skill);
  
  // Generate recommendations
  const recommendations: string[] = [];
  
  if (averageScore < 50) {
    recommendations.push('Consider focusing on jobs that better match your current skillset');
  }
  
  if (skillGaps.length > 0) {
    recommendations.push(`Top skills to develop: ${skillGaps.slice(0, 3).join(', ')}`);
  }
  
  if (bestMatchingSkills.length > 0) {
    recommendations.push(`Your strongest skills: ${bestMatchingSkills.slice(0, 3).join(', ')}`);
  }
  
  if (averageScore >= 70) {
    recommendations.push('Great match rate! Apply to your top-scoring positions');
  }
  
  return {
    averageScore,
    mostRequestedSkills,
    skillGaps,
    bestMatchingSkills,
    recommendations,
  };
}

// === Job Search via Public APIs ===
export async function searchJobsPublic(
  query: JobSearchQuery,
): Promise<{ jobs: Partial<JobMatch>[]; source: string; error?: string }> {
  // This is now a fallback - use job-scraper.ts for actual API calls
  try {
    return {
      jobs: [],
      source: 'manual',
      error: 'Use the Job Search feature to fetch jobs from free APIs',
    };
  } catch (error) {
    return {
      jobs: [],
      source: 'error',
      error: error instanceof Error ? error.message : 'Job search failed',
    };
  }
}

// === Export Jobs to CSV ===
export function exportJobsToCSV(jobs: JobMatch[]): string {
  const headers = ['Title', 'Company', 'Location', 'Match Score', 'Matching Skills', 'Missing Skills', 'URL', 'Applied', 'Saved', 'Notes'];
  
  const rows = jobs.map(job => [
    job.title,
    job.company,
    job.location,
    job.matchScore.toString(),
    job.matchingSkills.join('; '),
    job.missingSkills.join('; '),
    job.url || '',
    job.applied ? 'Yes' : 'No',
    job.saved ? 'Yes' : 'No',
    job.notes || '',
  ]);
  
  const csv = [headers, ...rows]
    .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
    .join('\n');
  
  return csv;
}

// === Analyze Skill Trends ===
export function analyzeSkillTrends(jobs: JobMatch[]): {
  trending: string[];
  emerging: string[];
  declining: string[];
} {
  const skillOccurrences: Record<string, number> = {};
  
  for (const job of jobs) {
    const allSkills = [...job.matchingSkills, ...job.missingSkills];
    for (const skill of allSkills) {
      skillOccurrences[skill] = (skillOccurrences[skill] || 0) + 1;
    }
  }
  
  const sorted = Object.entries(skillOccurrences)
    .sort(([, a], [, b]) => b - a);
  
  const trending = sorted.slice(0, 8).map(([skill]) => skill);
  
  // AI/ML and cloud skills are generally "emerging"
  const emergingKeywords = ['ai', 'machine learning', 'llm', 'gpt', 'generative', 'kubernetes', 'terraform', 'rust', 'go'];
  const emerging = sorted
    .filter(([skill]) => emergingKeywords.some(k => skill.toLowerCase().includes(k)))
    .slice(0, 5)
    .map(([skill]) => skill);
  
  return {
    trending,
    emerging,
    declining: [], // Would need historical data
  };
}
