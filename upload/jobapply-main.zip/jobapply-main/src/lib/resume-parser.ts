// ============================================================================
// Resume Parser (Enhanced Client-Side)
// ============================================================================
// Parses PDF and text-based resumes entirely in the browser.
// No data is sent to any server.
// Enhanced with better text extraction, section detection, and skill parsing.
// ============================================================================

import { ParsedResume, initialParsedResume } from '@/types/resume';

// === Main Resume Parser ===
export async function parseResumeFile(file: File): Promise<ParsedResume> {
  const resume = { ...initialParsedResume };
  resume.fileName = file.name;
  resume.parsedAt = new Date();

  let text = '';

  if (file.type === 'application/pdf') {
    text = await extractPDFText(file);
  } else if (file.type === 'text/plain' || file.name.endsWith('.txt')) {
    text = await file.text();
  } else if (file.name.endsWith('.md')) {
    text = await file.text();
  } else if (file.name.endsWith('.docx')) {
    text = await extractDocxText(file);
  } else {
    text = await file.text();
  }

  resume.rawText = text;

  // Extract structured data from text
  extractContactInfo(text, resume);
  extractExperience(text, resume);
  extractEducation(text, resume);
  extractSkills(text, resume);
  extractSummary(text, resume);
  extractCertifications(text, resume);

  return resume;
}

// === Enhanced PDF Text Extraction ===
async function extractPDFText(file: File): Promise<string> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const text = new TextDecoder('utf-8', { fatal: false }).decode(bytes);
    
    const textContent: string[] = [];
    
    // Method 1: Extract text between stream/endstream markers
    const streamRegex = /stream[\r\n]+([\s\S]*?)[\r\n]+endstream/gi;
    let match;
    
    while ((match = streamRegex.exec(text)) !== null) {
      const content = match[1];
      // Try to decode if it looks like Flate encoded
      const readable = content
        .replace(/[^\x20-\x7E\n\r\t]/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      if (readable.length > 10 && /[a-zA-Z]{3,}/.test(readable)) {
        textContent.push(readable);
      }
    }
    
    // Method 2: Extract text from Tj/TJ operators (PDF text operators)
    const tjRegex = /\(([^)]+)\)\s*Tj/g;
    while ((match = tjRegex.exec(text)) !== null) {
      const clean = match[1]
        .replace(/\\([0-7]{3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)))
        .replace(/\\(.)/g, '$1')
        .replace(/[^\x20-\x7E]/g, '');
      if (clean.length > 1) {
        textContent.push(clean);
      }
    }
    
    // Method 3: Extract text from parentheses (common in PDF strings)
    const parenRegex = /\(([^)]{3,100})\)/g;
    while ((match = parenRegex.exec(text)) !== null) {
      const clean = match[1]
        .replace(/\\([0-7]{3})/g, (_, oct) => String.fromCharCode(parseInt(oct, 8)))
        .replace(/\\(.)/g, '$1')
        .replace(/[^\x20-\x7E\s]/g, '')
        .trim();
      if (clean.length > 2 && /[a-zA-Z]{2,}/.test(clean)) {
        textContent.push(clean);
      }
    }
    
    // Method 4: Look for plain text sections
    const plainTextMatches = text.match(/[A-Z][a-z]+(?:\s+[A-Za-z]+){2,}/g) || [];
    textContent.push(...plainTextMatches.filter(t => t.length > 10));
    
    // Deduplicate and join
    const uniqueText = [...new Set(textContent)];
    return uniqueText.join('\n').slice(0, 15000);
  } catch (error) {
    console.warn('PDF extraction error:', error);
    return '';
  }
}

// === DOCX Text Extraction (Basic) ===
async function extractDocxText(file: File): Promise<string> {
  try {
    // DOCX is a ZIP file containing XML
    const JSZip = (await import('jszip')).default;
    const zip = new JSZip();
    const contents = await zip.loadAsync(file);
    
    // Main document content is in word/document.xml
    const docXml = await contents.file('word/document.xml')?.async('string');
    if (!docXml) return '';
    
    // Extract text from XML tags
    const textContent: string[] = [];
    const textRegex = /<w:t[^>]*>([^<]*)<\/w:t>/g;
    let match;
    
    while ((match = textRegex.exec(docXml)) !== null) {
      if (match[1].trim()) {
        textContent.push(match[1]);
      }
    }
    
    return textContent.join(' ').replace(/\s+/g, ' ').trim();
  } catch (error) {
    console.warn('DOCX extraction error:', error);
    return '';
  }
}

// === Enhanced Contact Information Extraction ===
function extractContactInfo(text: string, resume: ParsedResume): void {
  // Email pattern (more comprehensive)
  const emailMatch = text.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
  if (emailMatch) {
    resume.email = emailMatch[0];
  }

  // Phone pattern (multiple formats)
  const phonePatterns = [
    /(?:\+1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}/,
    /\+\d{1,3}[-.\s]?\d{2,4}[-.\s]?\d{3,4}[-.\s]?\d{3,4}/,
    /\d{3}[-.\s]\d{3}[-.\s]\d{4}/,
  ];
  
  for (const pattern of phonePatterns) {
    const phoneMatch = text.match(pattern);
    if (phoneMatch) {
      resume.phone = phoneMatch[0];
      break;
    }
  }

  // Name extraction (enhanced)
  const lines = text.split('\n').filter(l => l.trim());
  if (lines.length > 0) {
    // Look for name at the beginning
    for (let i = 0; i < Math.min(3, lines.length); i++) {
      const line = lines[i].trim();
      // Check if it looks like a name (2-4 capitalized words, no special chars)
      if (/^[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}$/.test(line) && line.length < 50) {
        resume.name = line;
        break;
      }
      // Also check for ALL CAPS name
      if (/^[A-Z]+(?:\s+[A-Z]+){1,3}$/.test(line) && line.length < 50) {
        resume.name = line.split(' ').map(w => w.charAt(0) + w.slice(1).toLowerCase()).join(' ');
        break;
      }
    }
  }

  // Location patterns (enhanced)
  const locationPatterns = [
    /(?:Location|Address|Based in|Located in)[:\s]+([^\n|•]+)/i,
    /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?,\s*[A-Z]{2}(?:\s+\d{5})?)/,
    /([A-Z][a-z]+,\s*[A-Z][a-z]+(?:,\s*[A-Z][a-z]+)?)/,
  ];
  
  for (const pattern of locationPatterns) {
    const match = text.match(pattern);
    if (match) {
      resume.location = (match[1] || match[0]).trim();
      break;
    }
  }
}

// === Enhanced Experience Extraction ===
function extractExperience(text: string, resume: ParsedResume): void {
  // Look for experience section with various headers
  const expHeaders = [
    /(?:professional\s+)?experience/i,
    /work\s+history/i,
    /employment(?:\s+history)?/i,
    /career\s+history/i,
  ];
  
  let expSection = '';
  for (const header of expHeaders) {
    const match = text.match(new RegExp(`${header.source}[\\s\\S]*?(?=education|skills|certifications|projects|awards|references|$)`, 'i'));
    if (match && match[0].length > expSection.length) {
      expSection = match[0];
    }
  }
  
  if (!expSection) return;
  
  const lines = expSection.split('\n').filter(l => l.trim());
  
  // Patterns for role detection
  const rolePatterns = [
    /^(.+?)\s+(?:at|@|[-–])\s+(.+?)(?:\s*[|,]\s*(.+))?$/i,
    /^(.+?)\s*[-–]\s*(.+?)(?:\s*[|,]\s*(.+))?$/i,
  ];
  
  const datePattern = /(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)[a-z]*\.?\s+\d{4}\s*[-–]\s*(?:Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|Jun(?:e)?|Jul(?:y)?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?|Present|Current|Now)[a-z]*\.?\s*\d{0,4}/gi;
  
  let currentExp: ParsedResume['experience'][0] | null = null;
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    if (!trimmedLine) continue;
    
    // Check for role pattern
    let roleMatch = null;
    for (const pattern of rolePatterns) {
      roleMatch = trimmedLine.match(pattern);
      if (roleMatch) break;
    }
    
    const dateMatch = trimmedLine.match(datePattern);
    
    if (roleMatch && !dateMatch) {
      if (currentExp && currentExp.title) {
        resume.experience.push(currentExp);
      }
      currentExp = {
        title: roleMatch[1].trim(),
        company: roleMatch[2].trim(),
        location: roleMatch[3]?.trim() || '',
        startDate: '',
        endDate: '',
        description: '',
        highlights: [],
      };
    } else if (dateMatch && currentExp) {
      const dates = dateMatch[0].split(/[-–]/);
      currentExp.startDate = dates[0]?.trim() || '';
      currentExp.endDate = dates[1]?.trim() || 'Present';
    } else if (currentExp) {
      if (trimmedLine.match(/^[•\-\*\u2022\u2023\u25E6]\s*/)) {
        currentExp.highlights.push(trimmedLine.replace(/^[•\-\*\u2022\u2023\u25E6]\s*/, ''));
      } else if (trimmedLine.length > 20) {
        currentExp.description += ' ' + trimmedLine;
      }
    }
  }
  
  if (currentExp && currentExp.title) {
    resume.experience.push(currentExp);
  }
  
  // Clean up descriptions
  resume.experience = resume.experience.map(exp => ({
    ...exp,
    description: exp.description.trim(),
  }));
}

// === Enhanced Education Extraction ===
function extractEducation(text: string, resume: ParsedResume): void {
  const eduSection = text.match(/(?:education|academic|qualifications|degrees?)[\s\S]*?(?=experience|skills|certifications|projects|$)/i);
  
  if (!eduSection) return;
  
  const eduText = eduSection[0];
  const lines = eduText.split('\n').filter(l => l.trim());
  
  // Look for degree patterns
  const degreePatterns = [
    /((?:Bachelor|Master|Doctor|Ph\.?D\.?|MBA|B\.?S\.?|M\.?S\.?|B\.?A\.?|M\.?A\.?|Associate|Diploma)[\w\s]*?)(?:\s+(?:in|of)\s+(.+?))?(?:\s*[,\-–|]\s*(.+))?$/i,
    /([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\s*[,\-–]\s*(\d{4})/,
  ];
  
  for (const line of lines) {
    const trimmedLine = line.trim();
    if (!trimmedLine || trimmedLine.length < 5) continue;
    
    for (const pattern of degreePatterns) {
      const match = trimmedLine.match(pattern);
      if (match) {
        resume.education.push({
          institution: match[3]?.trim() || '',
          degree: match[1]?.trim() || trimmedLine,
          field: match[2]?.trim() || '',
          graduationDate: '',
        });
        break;
      }
    }
  }
}

// === Enhanced Skills Extraction ===
function extractSkills(text: string, resume: ParsedResume): void {
  // Comprehensive tech skills list
  const techSkills = [
    // Programming Languages
    'JavaScript', 'TypeScript', 'Python', 'Java', 'C++', 'C#', 'Go', 'Rust', 'Ruby', 'PHP', 'Swift', 'Kotlin', 'Scala', 'R', 'MATLAB',
    // Frontend
    'React', 'Vue', 'Angular', 'Svelte', 'Next.js', 'Nuxt', 'jQuery', 'Redux', 'MobX', 'Zustand',
    // Backend
    'Node.js', 'Express', 'Django', 'Flask', 'FastAPI', 'Spring', 'Rails', 'Laravel', 'ASP.NET',
    // Databases
    'SQL', 'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'Elasticsearch', 'DynamoDB', 'Cassandra', 'Oracle', 'SQLite',
    // Cloud & DevOps
    'AWS', 'Azure', 'GCP', 'Docker', 'Kubernetes', 'Terraform', 'Ansible', 'Jenkins', 'CircleCI', 'GitHub Actions',
    // Data & AI/ML
    'Machine Learning', 'Deep Learning', 'TensorFlow', 'PyTorch', 'Scikit-learn', 'Pandas', 'NumPy', 'Spark', 'Hadoop',
    'NLP', 'Computer Vision', 'Data Science', 'Data Engineering', 'ETL', 'Data Visualization', 'Tableau', 'Power BI',
    // Other Tech
    'GraphQL', 'REST', 'API', 'Git', 'Linux', 'CI/CD', 'Agile', 'Scrum', 'Microservices', 'Serverless',
    'HTML', 'CSS', 'Sass', 'Tailwind', 'Bootstrap', 'Material UI', 'Figma', 'Sketch', 'Adobe XD',
    // Soft Skills
    'Leadership', 'Communication', 'Problem Solving', 'Teamwork', 'Project Management', 'Product Management',
  ];
  
  const foundSkills = new Set<string>();
  const lowerText = text.toLowerCase();
  
  for (const skill of techSkills) {
    // Check for exact word match (not partial)
    const regex = new RegExp(`\\b${skill.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i');
    if (regex.test(lowerText)) {
      foundSkills.add(skill);
    }
  }
  
  // Also look for Skills section and extract items
  const skillsSectionPatterns = [
    /(?:skills|technical skills|core competencies|technologies)[:\s]*([^\n]+(?:\n[^\n]+)?)/i,
    /(?:proficient in|expertise in|experienced with)[:\s]*([^\n]+)/i,
  ];
  
  for (const pattern of skillsSectionPatterns) {
    const skillsSection = text.match(pattern);
    if (skillsSection) {
      const skillsText = skillsSection[1];
      const words = skillsText.split(/[,;|•·\n]+/);
      for (const word of words) {
        const cleaned = word.trim();
        if (cleaned.length > 2 && cleaned.length < 40 && !cleaned.includes(':') && /^[A-Za-z]/.test(cleaned)) {
          foundSkills.add(cleaned);
        }
      }
    }
  }
  
  resume.skills = Array.from(foundSkills);
}

// === Summary Extraction ===
function extractSummary(text: string, resume: ParsedResume): void {
  const summaryPatterns = [
    /(?:summary|profile|objective|about(?:\s+me)?)[:\s]*([^\n]+(?:\n[^\n]+){0,5})/i,
    /^([A-Z][^.]+\.\s+[A-Z][^.]+\.(?:\s+[A-Z][^.]+\.)?)/m,
  ];
  
  for (const pattern of summaryPatterns) {
    const match = text.match(pattern);
    if (match) {
      const summary = match[1].trim().replace(/\s+/g, ' ');
      if (summary.length > 50 && summary.length < 1000) {
        resume.summary = summary;
        break;
      }
    }
  }
}

// === Certifications Extraction ===
function extractCertifications(text: string, resume: ParsedResume): void {
  const certSection = text.match(/(?:certifications?|certificates?|licenses?|credentials?)[:\s]*([\s\S]*?)(?=education|experience|skills|projects|$)/i);
  
  if (!certSection) return;
  
  const certText = certSection[1];
  const lines = certText.split('\n').filter(l => l.trim());
  
  const certs: string[] = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.length > 5 && trimmed.length < 100) {
      // Clean up bullet points and numbers
      const cleaned = trimmed.replace(/^[\d.)\-•\*\u2022]+\s*/, '');
      if (cleaned.length > 5) {
        certs.push(cleaned);
      }
    }
  }
  
  resume.certifications = certs.slice(0, 20);
}

// === Skill Extraction from LinkedIn + Resume Combined ===
export function extractCombinedSkills(
  linkedInSkills: { name: string; endorsementCount?: number }[],
  resumeSkills: string[],
): {
  allSkills: string[];
  technicalSkills: string[];
  softSkills: string[];
  endorsedSkills: { skill: string; endorsements: number }[];
} {
  const technicalKeywords = [
    'javascript', 'python', 'java', 'react', 'node', 'sql', 'aws', 'docker',
    'kubernetes', 'git', 'api', 'database', 'cloud', 'machine learning', 'ai',
    'typescript', 'html', 'css', 'linux', 'agile', 'devops', 'ci/cd', 'go',
    'rust', 'c++', 'c#', 'ruby', 'php', 'swift', 'kotlin', 'scala', 'mongodb',
    'postgresql', 'redis', 'graphql', 'rest', 'microservices', 'tensorflow',
    'pytorch', 'data', 'analytics', 'backend', 'frontend', 'fullstack', 'vue',
    'angular', 'next.js', 'django', 'flask', 'spring', 'express',
  ];
  
  const softKeywords = [
    'leadership', 'communication', 'teamwork', 'problem solving', 'management',
    'collaboration', 'presentation', 'negotiation', 'mentoring', 'strategy',
    'critical thinking', 'creativity', 'adaptability', 'time management',
    'decision making', 'conflict resolution', 'emotional intelligence',
  ];
  
  // Combine and dedupe (case-insensitive)
  const skillMap = new Map<string, string>();
  const technicalSkills: string[] = [];
  const softSkills: string[] = [];
  
  // Add LinkedIn skills
  for (const skill of linkedInSkills) {
    const key = skill.name.toLowerCase();
    if (!skillMap.has(key)) {
      skillMap.set(key, skill.name);
    }
  }
  
  // Add resume skills
  for (const skill of resumeSkills) {
    const key = skill.toLowerCase();
    if (!skillMap.has(key)) {
      skillMap.set(key, skill);
    }
  }
  
  // Categorize
  for (const [lowerSkill, originalSkill] of skillMap) {
    if (technicalKeywords.some(k => lowerSkill.includes(k))) {
      technicalSkills.push(originalSkill);
    } else if (softKeywords.some(k => lowerSkill.includes(k))) {
      softSkills.push(originalSkill);
    }
  }
  
  // Get endorsed skills sorted
  const endorsedSkills = linkedInSkills
    .filter(s => (s.endorsementCount || 0) > 0)
    .map(s => ({ skill: s.name, endorsements: s.endorsementCount || 0 }))
    .sort((a, b) => b.endorsements - a.endorsements);
  
  return {
    allSkills: Array.from(skillMap.values()),
    technicalSkills,
    softSkills,
    endorsedSkills,
  };
}
