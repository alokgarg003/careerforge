// ============================================================================
// LinkedIn Data Export Parser (Enhanced)
// ============================================================================
// Client-side parser for LinkedIn data exports (ZIP files containing CSVs).
// All parsing happens in the browser - no data is sent to any server.
// Privacy-sensitive data is filtered out during parsing.
// Enhanced with better column detection, date parsing, and skill extraction.
// ============================================================================

import JSZip from 'jszip';
import Papa from 'papaparse';
import {
  LinkedInData,
  LinkedInProfile,
  LinkedInPosition,
  LinkedInEducation,
  LinkedInSkill,
  LinkedInCertification,
  LinkedInCompany,
  LinkedInJobApplication,
  LinkedInSavedJob,
  ConnectionStats,
  LinkedInDataDiscovery,
  initialLinkedInData,
} from '@/types/linkedin';

// === Helper: Parse Date from LinkedIn format (Enhanced) ===
function parseLinkedInDate(dateStr: string | undefined): Date | null {
  if (!dateStr || dateStr.trim() === '' || dateStr.toLowerCase() === 'present') return null;
  
  const cleanStr = dateStr.trim();
  
  // Try various formats in order of specificity
  const formats = [
    // ISO format: 2020-01-15
    () => {
      const iso = new Date(cleanStr);
      return !isNaN(iso.getTime()) ? iso : null;
    },
    // Month Year: "Jan 2020", "January 2020"
    () => {
      const monthYearMatch = cleanStr.match(/^(\w+)\s+(\d{4})$/);
      if (monthYearMatch) {
        const monthMap: Record<string, number> = {
          jan: 0, january: 0, feb: 1, february: 1, mar: 2, march: 2,
          apr: 3, april: 3, may: 4, jun: 5, june: 5, jul: 6, july: 6,
          aug: 7, august: 7, sep: 8, sept: 8, september: 8, oct: 9, october: 9,
          nov: 10, november: 10, dec: 11, december: 11,
        };
        const month = monthMap[monthYearMatch[1].toLowerCase()];
        const year = parseInt(monthYearMatch[2]);
        if (month !== undefined && !isNaN(year)) {
          return new Date(year, month, 1);
        }
      }
      return null;
    },
    // Date format: "2020-01-15" or "01/15/2020" or "15/01/2020"
    () => {
      const dashParts = cleanStr.split('-');
      if (dashParts.length === 3) {
        const [y, m, d] = dashParts.map(Number);
        if (y > 1900 && m >= 1 && m <= 12 && d >= 1 && d <= 31) {
          return new Date(y, m - 1, d);
        }
      }
      return null;
    },
    () => {
      const slashParts = cleanStr.split('/');
      if (slashParts.length === 3) {
        // Try MM/DD/YYYY
        const [m, d, y] = slashParts.map(Number);
        if (y > 1900 && m >= 1 && m <= 12 && d >= 1 && d <= 31) {
          return new Date(y, m - 1, d);
        }
        // Try DD/MM/YYYY
        if (m >= 1 && m <= 31 && d >= 1 && d <= 12 && y > 1900) {
          return new Date(y, d - 1, m);
        }
      }
      return null;
    },
    // Year only: "2020"
    () => {
      const yearMatch = cleanStr.match(/^(\d{4})$/);
      if (yearMatch) {
        return new Date(parseInt(yearMatch[1]), 0, 1);
      }
      return null;
    },
    // LinkedIn timestamp: "15 Jan 2020"
    () => {
      const dmyMatch = cleanStr.match(/^(\d{1,2})\s+(\w+)\s+(\d{4})$/);
      if (dmyMatch) {
        const monthMap: Record<string, number> = {
          jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
          jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11,
        };
        const day = parseInt(dmyMatch[1]);
        const month = monthMap[dmyMatch[2].toLowerCase().slice(0, 3)];
        const year = parseInt(dmyMatch[3]);
        if (month !== undefined && !isNaN(day) && !isNaN(year)) {
          return new Date(year, month, day);
        }
      }
      return null;
    },
  ];

  for (const format of formats) {
    try {
      const date = format();
      if (date && !isNaN(date.getTime()) && date.getFullYear() > 1900) {
        return date;
      }
    } catch {
      continue;
    }
  }
  
  return null;
}

// === Helper: Get column value with multiple possible names (Enhanced) ===
function getColumnValue(row: Record<string, string>, possibleNames: string[]): string {
  // First try exact matches
  for (const name of possibleNames) {
    if (row[name] !== undefined && row[name] !== null) {
      return String(row[name]).trim();
    }
  }
  
  // Then try case-insensitive match
  const rowKeys = Object.keys(row);
  for (const name of possibleNames) {
    const lowerName = name.toLowerCase();
    for (const key of rowKeys) {
      if (key.toLowerCase() === lowerName) {
        return String(row[key] ?? '').trim();
      }
    }
  }
  
  // Try partial match
  for (const name of possibleNames) {
    const lowerName = name.toLowerCase();
    for (const key of rowKeys) {
      if (key.toLowerCase().includes(lowerName) || lowerName.includes(key.toLowerCase())) {
        return String(row[key] ?? '').trim();
      }
    }
  }
  
  return '';
}

// === Helper: Categorize file by name (Enhanced) ===
function categorizeFile(fileName: string): 'profile' | 'connections' | 'companies' | 'jobs' | 'skills' | 'education' | 'activity' | 'other' {
  const lowerName = fileName.toLowerCase();
  
  // Profile and positions
  if (lowerName.includes('profile') && !lowerName.includes('position')) return 'profile';
  if (lowerName.includes('position')) return 'profile';
  
  // Education and certifications
  if (lowerName.includes('education')) return 'education';
  if (lowerName.includes('certification') || lowerName.includes('certificate')) return 'education';
  if (lowerName.includes('course') || lowerName.includes('learning')) return 'education';
  
  // Skills
  if (lowerName.includes('skill') || lowerName.includes('endorsement')) return 'skills';
  
  // Connections
  if (lowerName.includes('connection') || lowerName.includes('contact')) return 'connections';
  
  // Companies
  if (lowerName.includes('company') || lowerName.includes('compan') || lowerName.includes('follow')) return 'companies';
  
  // Jobs
  if (lowerName.includes('job') || lowerName.includes('application') || lowerName.includes('saved')) return 'jobs';
  
  // Activity (privacy - we skip these)
  if (lowerName.includes('message') || lowerName.includes('invitation') || 
      lowerName.includes('reaction') || lowerName.includes('comment') ||
      lowerName.includes('share') || lowerName.includes('like') ||
      lowerName.includes('inbox') || lowerName.includes('conversation')) {
    return 'activity';
  }
  
  return 'other';
}

// === Parse Profile Data (Enhanced) ===
function parseProfile(rows: Record<string, string>[]): LinkedInProfile | null {
  if (rows.length === 0) return null;
  
  const row = rows[0];
  return {
    firstName: getColumnValue(row, ['First Name', 'firstName', 'first_name', 'FirstName']),
    lastName: getColumnValue(row, ['Last Name', 'lastName', 'last_name', 'LastName']),
    headline: getColumnValue(row, ['Headline', 'headline', 'Title', 'Professional Headline']),
    industry: getColumnValue(row, ['Industry', 'industry', 'Sector']),
    location: getColumnValue(row, ['Geo Location', 'Location', 'location', 'City', 'Country']),
    summary: getColumnValue(row, ['Summary', 'summary', 'About', 'Bio', 'Description']),
  };
}

// === Parse Positions Data (Enhanced) ===
function parsePositions(rows: Record<string, string>[]): LinkedInPosition[] {
  return rows.map(row => {
    const startDateStr = getColumnValue(row, ['Started On', 'startDate', 'Start Date', 'From', 'Start']);
    const endDateStr = getColumnValue(row, ['Finished On', 'endDate', 'End Date', 'To', 'End', 'Ended On']);
    
    return {
      companyName: getColumnValue(row, ['Company Name', 'companyName', 'Company', 'company', 'Organization', 'Employer']),
      title: getColumnValue(row, ['Title', 'title', 'Position', 'Role', 'Job Title', 'Position Title']),
      description: getColumnValue(row, ['Description', 'description', 'Summary', 'Details', 'Responsibilities']),
      location: getColumnValue(row, ['Location', 'location', 'City', 'Office Location']),
      startDate: parseLinkedInDate(startDateStr),
      endDate: parseLinkedInDate(endDateStr),
      isCurrent: !endDateStr || endDateStr.toLowerCase() === 'present' || endDateStr === '',
    };
  }).filter(p => p.companyName || p.title);
}

// === Parse Education Data (Enhanced) ===
function parseEducation(rows: Record<string, string>[]): LinkedInEducation[] {
  return rows.map(row => ({
    schoolName: getColumnValue(row, ['School Name', 'schoolName', 'Institution', 'University', 'College', 'School']),
    degreeName: getColumnValue(row, ['Degree Name', 'degreeName', 'Degree', 'Qualification', 'Degree Type']),
    fieldOfStudy: getColumnValue(row, ['Field Of Study', 'fieldOfStudy', 'Major', 'Field', 'Specialization', 'Subject']),
    startDate: parseLinkedInDate(getColumnValue(row, ['Start Date', 'startDate', 'Started', 'From'])),
    endDate: parseLinkedInDate(getColumnValue(row, ['End Date', 'endDate', 'Ended', 'To', 'Graduation Date', 'Graduated'])),
    notes: getColumnValue(row, ['Notes', 'notes', 'Activities', 'Description', 'Activities and Societies']),
  })).filter(e => e.schoolName);
}

// === Parse Skills Data (Enhanced) ===
function parseSkills(rows: Record<string, string>[]): LinkedInSkill[] {
  const skills: LinkedInSkill[] = [];
  const seenSkills = new Set<string>();
  
  for (const row of rows) {
    const name = getColumnValue(row, ['Name', 'name', 'Skill', 'skill', 'Skill Name', 'Competency']);
    const endorsementStr = getColumnValue(row, ['Endorsements', 'endorsementCount', 'Count', 'Endorsement Count', 'NumEndorsements']);
    
    if (name && !seenSkills.has(name.toLowerCase())) {
      seenSkills.add(name.toLowerCase());
      skills.push({
        name,
        endorsementCount: parseInt(endorsementStr) || 0,
      });
    }
  }
  
  // Sort by endorsements
  return skills.sort((a, b) => (b.endorsementCount || 0) - (a.endorsementCount || 0));
}

// === Parse Certifications Data (Enhanced) ===
function parseCertifications(rows: Record<string, string>[]): LinkedInCertification[] {
  return rows.map(row => ({
    name: getColumnValue(row, ['Name', 'name', 'Certification', 'Certificate Name', 'Title', 'Credential']),
    authority: getColumnValue(row, ['Authority', 'authority', 'Issuer', 'Issuing Organization', 'Provider', 'Organization']),
    licenseNumber: getColumnValue(row, ['License Number', 'licenseNumber', 'Credential ID', 'Certificate ID']),
    startDate: parseLinkedInDate(getColumnValue(row, ['Started On', 'startDate', 'Issue Date', 'Issued'])),
    endDate: parseLinkedInDate(getColumnValue(row, ['Finished On', 'endDate', 'Expiration Date', 'Expires'])),
  })).filter(c => c.name);
}

// === Parse Connections (Aggregated Only for Privacy) - Enhanced ===
function parseConnections(rows: Record<string, string>[]): ConnectionStats {
  const connectionsByMonth: Record<string, number> = {};
  const connectionsByYear: Record<string, number> = {};
  const industryDistribution: Record<string, number> = {};
  const locationDistribution: Record<string, number> = {};
  const companyDistribution: Record<string, number> = {};

  for (const row of rows) {
    // Parse connection date for growth analysis
    const connectedOn = getColumnValue(row, ['Connected On', 'connectedOn', 'Date', 'Connection Date', 'Connected']);
    const date = parseLinkedInDate(connectedOn);
    
    if (date) {
      const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
      const yearKey = `${date.getFullYear()}`;
      
      connectionsByMonth[monthKey] = (connectionsByMonth[monthKey] || 0) + 1;
      connectionsByYear[yearKey] = (connectionsByYear[yearKey] || 0) + 1;
    }

    // Extract industry if available
    const industry = getColumnValue(row, ['Industry', 'industry']);
    if (industry && industry.length > 0) {
      industryDistribution[industry] = (industryDistribution[industry] || 0) + 1;
    }

    // Extract company for diversity analysis
    const company = getColumnValue(row, ['Company', 'company', 'Position', 'Organization']);
    if (company && company.length > 0) {
      companyDistribution[company] = (companyDistribution[company] || 0) + 1;
    }

    // Extract position/title for industry inference
    const position = getColumnValue(row, ['Position', 'Title', 'Job Title']);
    if (position && position.length > 0) {
      // Infer industry from position
      const inferredIndustry = inferIndustryFromTitle(position);
      if (inferredIndustry) {
        locationDistribution[inferredIndustry] = (locationDistribution[inferredIndustry] || 0) + 1;
      }
    }
  }

  return {
    totalConnections: rows.length,
    connectionsByMonth: Object.entries(connectionsByMonth)
      .map(([month, count]) => ({ month, count }))
      .sort((a, b) => a.month.localeCompare(b.month)),
    connectionsByYear: Object.entries(connectionsByYear)
      .map(([year, count]) => ({ year, count }))
      .sort((a, b) => a.year.localeCompare(b.year)),
    industryDistribution: Object.entries(industryDistribution)
      .map(([industry, count]) => ({ industry, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20),
    locationDistribution: Object.entries(companyDistribution.length > 0 ? companyDistribution : locationDistribution)
      .map(([location, count]) => ({ location, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 20),
  };
}

// === Infer Industry from Job Title ===
function inferIndustryFromTitle(title: string): string | null {
  const lowerTitle = title.toLowerCase();
  
  const industryKeywords: Record<string, string[]> = {
    'Technology': ['engineer', 'developer', 'software', 'tech', 'it ', 'data', 'cloud', 'devops', 'architect'],
    'Finance': ['finance', 'banking', 'investment', 'accounting', 'financial', 'analyst'],
    'Healthcare': ['doctor', 'nurse', 'medical', 'healthcare', 'pharma', 'clinical'],
    'Marketing': ['marketing', 'brand', 'digital marketing', 'seo', 'content'],
    'Sales': ['sales', 'account executive', 'business development', 'bdr', 'sdr'],
    'HR': ['hr ', 'human resources', 'recruiter', 'talent', 'people operations'],
    'Design': ['designer', 'ux', 'ui', 'creative', 'graphic'],
    'Operations': ['operations', 'logistics', 'supply chain', 'procurement'],
    'Legal': ['lawyer', 'attorney', 'legal', 'counsel', 'paralegal'],
    'Education': ['teacher', 'professor', 'educator', 'instructor', 'academic'],
  };
  
  for (const [industry, keywords] of Object.entries(industryKeywords)) {
    if (keywords.some(kw => lowerTitle.includes(kw))) {
      return industry;
    }
  }
  
  return null;
}

// === Parse Companies Followed (Enhanced) ===
function parseCompanies(rows: Record<string, string>[]): LinkedInCompany[] {
  return rows.map(row => ({
    name: getColumnValue(row, ['Organization', 'Name', 'name', 'Company', 'Company Name']),
    industry: getColumnValue(row, ['Industry', 'industry', 'Sector']),
    location: getColumnValue(row, ['Location', 'location', 'Headquarters']),
    interactionType: 'followed' as const,
  })).filter(c => c.name);
}

// === Parse Job Applications (Enhanced) ===
function parseJobApplications(rows: Record<string, string>[]): LinkedInJobApplication[] {
  return rows.map(row => ({
    jobTitle: getColumnValue(row, ['Job Title', 'Title', 'title', 'Position', 'Role', 'Job']),
    companyName: getColumnValue(row, ['Company', 'Company Name', 'companyName', 'Organization', 'Employer']),
    applicationDate: parseLinkedInDate(getColumnValue(row, ['Application Date', 'Applied On', 'Date', 'Submitted', 'Applied'])),
    status: getColumnValue(row, ['Status', 'status', 'Application Status', 'State']),
  })).filter(j => j.jobTitle || j.companyName);
}

// === Parse Saved Jobs (Enhanced) ===
function parseSavedJobs(rows: Record<string, string>[]): LinkedInSavedJob[] {
  return rows.map(row => ({
    jobTitle: getColumnValue(row, ['Job Title', 'Title', 'title', 'Position', 'Role']),
    companyName: getColumnValue(row, ['Company', 'Company Name', 'companyName', 'Organization']),
    savedDate: parseLinkedInDate(getColumnValue(row, ['Saved On', 'Date', 'Saved Date', 'Saved'])),
  })).filter(j => j.jobTitle || j.companyName);
}

// === Parse CSV Content (Enhanced with better error handling) ===
async function parseCSV(content: string): Promise<Record<string, string>[]> {
  return new Promise((resolve, reject) => {
    // Clean content - handle BOM and weird characters
    const cleanContent = content.replace(/^\uFEFF/, '').trim();
    
    Papa.parse(cleanContent, {
      header: true,
      skipEmptyLines: 'greedy',
      transformHeader: (header) => header.trim(),
      transform: (value) => value?.trim() || '',
      complete: (results) => {
        // Filter out completely empty rows
        const validRows = (results.data as Record<string, string>[]).filter(row => 
          Object.values(row).some(v => v && v.trim())
        );
        resolve(validRows);
      },
      error: (error) => {
        console.warn('CSV parse error:', error);
        reject(error);
      },
    });
  });
}

// === Main Parser: Process LinkedIn ZIP Export (Enhanced) ===
export async function parseLinkedInExport(file: File): Promise<LinkedInData> {
  const zip = new JSZip();
  const contents = await zip.loadAsync(file);
  
  const data: LinkedInData = { ...initialLinkedInData };
  const discoveryFiles: LinkedInDataDiscovery['files'] = [];
  let earliestDate: Date | null = null;
  let latestDate: Date | null = null;

  // Collect all CSV files first
  const csvFiles: { path: string; zipEntry: JSZip.JSZipObject }[] = [];
  
  for (const [path, zipEntry] of Object.entries(contents.files)) {
    if (zipEntry.dir) continue;
    if (!path.toLowerCase().endsWith('.csv')) continue;
    csvFiles.push({ path, zipEntry });
  }

  // Process files in parallel for better performance
  const parsePromises = csvFiles.map(async ({ path, zipEntry }) => {
    try {
      const content = await zipEntry.async('string');
      const rows = await parseCSV(content);
      
      if (rows.length === 0) return null;

      const fileName = path.split('/').pop() || path;
      const category = categorizeFile(fileName);
      const columns = Object.keys(rows[0]);
      
      return { path, fileName, category, columns, rows };
    } catch (error) {
      console.warn(`Failed to parse ${path}:`, error);
      return null;
    }
  });

  const results = await Promise.all(parsePromises);

  // Process results
  for (const result of results) {
    if (!result) continue;
    
    const { path, fileName, category, columns, rows } = result;
    
    // Add to discovery
    discoveryFiles.push({
      name: fileName,
      category,
      rowCount: rows.length,
      columns,
      usableForAnalysis: category !== 'activity',
      privacyConcerns: columns.filter(col => 
        col.toLowerCase().includes('email') || 
        col.toLowerCase().includes('name') ||
        col.toLowerCase().includes('url') ||
        col.toLowerCase().includes('message')
      ),
    });

    // Parse based on file type
    const lowerPath = path.toLowerCase();
    
    if (lowerPath.includes('profile') && !lowerPath.includes('position')) {
      data.profile = parseProfile(rows);
    } else if (lowerPath.includes('position')) {
      data.positions = parsePositions(rows);
      // Update date range
      for (const pos of data.positions) {
        if (pos.startDate && (!earliestDate || pos.startDate < earliestDate)) {
          earliestDate = pos.startDate;
        }
        if (pos.endDate && (!latestDate || pos.endDate > latestDate)) {
          latestDate = pos.endDate;
        }
      }
    } else if (lowerPath.includes('education') && !lowerPath.includes('certification')) {
      data.education = parseEducation(rows);
    } else if (lowerPath.includes('skill')) {
      data.skills = parseSkills(rows);
    } else if (lowerPath.includes('certification') || lowerPath.includes('certificate')) {
      data.certifications = parseCertifications(rows);
    } else if (lowerPath.includes('connection')) {
      data.connectionStats = parseConnections(rows);
    } else if (lowerPath.includes('company') || lowerPath.includes('follow')) {
      const companies = parseCompanies(rows);
      data.companies = [...data.companies, ...companies];
    } else if (lowerPath.includes('application')) {
      data.jobApplications = parseJobApplications(rows);
    } else if (lowerPath.includes('saved') && lowerPath.includes('job')) {
      data.savedJobs = parseSavedJobs(rows);
    }
  }

  // Set data discovery summary
  data.dataDiscovery = {
    files: discoveryFiles,
    summary: {
      totalFiles: discoveryFiles.length,
      usableFiles: discoveryFiles.filter(f => f.usableForAnalysis).length,
      dateRange: {
        earliest: earliestDate ? earliestDate.toISOString().split('T')[0] : 'Unknown',
        latest: latestDate ? latestDate.toISOString().split('T')[0] : 'Present',
      },
    },
  };

  data.isLoaded = true;
  data.loadedAt = new Date();

  return data;
}

// === Calculate Career Analytics (Enhanced) ===
export function calculateCareerAnalytics(data: LinkedInData) {
  const { positions, skills, education, jobApplications, savedJobs, connectionStats } = data;

  // Calculate total experience with overlap handling
  let totalMonths = 0;
  const sortedPositions = [...positions].sort((a, b) => 
    (a.startDate?.getTime() || 0) - (b.startDate?.getTime() || 0)
  );
  
  for (const pos of sortedPositions) {
    if (pos.startDate) {
      const endDate = pos.endDate || new Date();
      const months = (endDate.getFullYear() - pos.startDate.getFullYear()) * 12 + 
                     (endDate.getMonth() - pos.startDate.getMonth());
      totalMonths += Math.max(0, months);
    }
  }

  // Unique companies
  const uniqueCompanies = new Set(positions.map(p => p.companyName).filter(Boolean));

  // Applications by month
  const appsByMonth: Record<string, number> = {};
  for (const app of jobApplications) {
    if (app.applicationDate) {
      const key = `${app.applicationDate.getFullYear()}-${String(app.applicationDate.getMonth() + 1).padStart(2, '0')}`;
      appsByMonth[key] = (appsByMonth[key] || 0) + 1;
    }
  }

  // Skill categories (enhanced grouping)
  const skillCategories: Record<string, number> = {
    'Technical': 0,
    'Leadership': 0,
    'Communication': 0,
    'Business': 0,
    'Analytics': 0,
    'Design': 0,
    'Other': 0,
  };

  const categoryKeywords: Record<string, string[]> = {
    'Technical': ['python', 'java', 'sql', 'javascript', 'react', 'node', 'aws', 'cloud', 'data', 'machine learning', 'ai', 'engineering', 'programming', 'software', 'api', 'database', 'devops', 'docker', 'kubernetes', 'linux', 'git', 'typescript', 'html', 'css', 'web', 'mobile', 'backend', 'frontend'],
    'Leadership': ['leadership', 'management', 'team', 'strategy', 'director', 'executive', 'lead', 'head of', 'vp', 'chief', 'mentor', 'coach'],
    'Communication': ['communication', 'presentation', 'writing', 'public speaking', 'negotiation', 'storytelling', 'documentation'],
    'Business': ['business', 'marketing', 'sales', 'finance', 'product', 'project management', 'operations', 'consulting', 'strategy'],
    'Analytics': ['analytics', 'analysis', 'statistics', 'metrics', 'reporting', 'research', 'insights', 'forecasting'],
    'Design': ['design', 'ux', 'ui', 'figma', 'sketch', 'adobe', 'creative', 'branding', 'visual'],
  };

  for (const skill of skills) {
    const lowerName = skill.name.toLowerCase();
    let categorized = false;
    
    for (const [category, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(k => lowerName.includes(k))) {
        skillCategories[category]++;
        categorized = true;
        break;
      }
    }
    
    if (!categorized) {
      skillCategories['Other']++;
    }
  }

  // Career progression analysis
  const careerProgression = positions
    .filter(p => p.startDate)
    .sort((a, b) => (a.startDate?.getTime() || 0) - (b.startDate?.getTime() || 0))
    .map(p => ({
      title: p.title,
      company: p.companyName,
      startYear: p.startDate?.getFullYear(),
      duration: p.startDate ? Math.round(
        ((p.endDate || new Date()).getTime() - p.startDate.getTime()) / (1000 * 60 * 60 * 24 * 30)
      ) : 0,
    }));

  return {
    totalYearsExperience: Math.round(totalMonths / 12 * 10) / 10,
    positionsCount: positions.length,
    companiesWorkedAt: uniqueCompanies.size,
    averageTenureMonths: positions.length > 0 ? Math.round(totalMonths / positions.length) : 0,
    topSkills: skills
      .sort((a, b) => (b.endorsementCount || 0) - (a.endorsementCount || 0))
      .slice(0, 15)
      .map(s => ({ skill: s.name, endorsements: s.endorsementCount || 0 })),
    skillCategories: Object.entries(skillCategories)
      .map(([category, count]) => ({ category, count }))
      .filter(c => c.count > 0)
      .sort((a, b) => b.count - a.count),
    degrees: education.map(e => e.degreeName).filter(Boolean),
    institutions: education.map(e => e.schoolName).filter(Boolean),
    totalApplications: jobApplications.length,
    applicationsByMonth: Object.entries(appsByMonth)
      .map(([month, count]) => ({ month, count }))
      .sort((a, b) => a.month.localeCompare(b.month)),
    savedJobsCount: savedJobs.length,
    networkStats: connectionStats,
    careerProgression,
  };
}
