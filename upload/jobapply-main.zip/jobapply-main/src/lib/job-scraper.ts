// ============================================================================
// Free Job Scraping & API Integration
// ============================================================================
// Client-side job fetching from free public APIs and job boards.
// All processing happens locally - privacy-first design.
// ============================================================================

import { JobMatch, JobSearchQuery } from '@/types/resume';

// === Free Job API Sources ===
interface JobAPISource {
  name: string;
  enabled: boolean;
  rateLimit: number; // requests per minute
  lastRequest: number;
}

const API_SOURCES: JobAPISource[] = [
  { name: 'remotive', enabled: true, rateLimit: 10, lastRequest: 0 },
  { name: 'jobicy', enabled: true, rateLimit: 10, lastRequest: 0 },
  { name: 'arbeitnow', enabled: true, rateLimit: 10, lastRequest: 0 },
];

// === Rate Limiting Cache ===
const requestCache = new Map<string, { data: JobMatch[]; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// === Remotive API (Free, No Key Required) ===
async function fetchRemotiveJobs(query: JobSearchQuery): Promise<JobMatch[]> {
  try {
    const searchTerms = query.keywords.slice(0, 3).join(' ').toLowerCase();
    
    // Map keywords to Remotive categories
    const categoryMap: Record<string, string> = {
      'software': 'software-dev',
      'developer': 'software-dev',
      'engineer': 'software-dev',
      'frontend': 'software-dev',
      'backend': 'software-dev',
      'fullstack': 'software-dev',
      'devops': 'devops-sysadmin',
      'data': 'data',
      'design': 'design',
      'product': 'product',
      'marketing': 'marketing',
      'sales': 'sales',
      'customer': 'customer-support',
      'hr': 'hr',
      'finance': 'finance-legal',
      'qa': 'qa',
      'writing': 'writing',
    };

    let category = '';
    for (const [keyword, cat] of Object.entries(categoryMap)) {
      if (searchTerms.includes(keyword)) {
        category = cat;
        break;
      }
    }

    const url = `https://remotive.com/api/remote-jobs${category ? `?category=${category}` : ''}`;
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Remotive API error');
    
    const data = await response.json();
    const jobs: JobMatch[] = (data.jobs || []).slice(0, 25).map((job: any) => ({
      id: `remotive-${job.id}`,
      title: job.title || 'Unknown Title',
      company: job.company_name || 'Unknown Company',
      location: job.candidate_required_location || 'Remote',
      description: stripHtml(job.description || ''),
      url: job.url,
      source: 'api' as const,
      postedDate: job.publication_date ? new Date(job.publication_date) : undefined,
      matchScore: 0,
      matchingSkills: [],
      missingSkills: [],
      matchReasons: [`Found on Remotive`, `Category: ${job.category || 'General'}`],
      saved: false,
      applied: false,
      salary: job.salary || undefined,
      tags: job.tags || [],
    }));

    return jobs;
  } catch (error) {
    console.warn('Remotive API failed:', error);
    return [];
  }
}

// === Jobicy API (Free, No Key Required) ===
async function fetchJobicyJobs(query: JobSearchQuery): Promise<JobMatch[]> {
  try {
    const searchTerms = query.keywords.slice(0, 3).join('+');
    const url = `https://jobicy.com/api/v2/remote-jobs?count=25&tag=${encodeURIComponent(searchTerms)}`;
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Jobicy API error');
    
    const data = await response.json();
    const jobs: JobMatch[] = (data.jobs || []).map((job: any) => ({
      id: `jobicy-${job.id || Date.now()}-${Math.random().toString(36).slice(2)}`,
      title: job.jobTitle || 'Unknown Title',
      company: job.companyName || 'Unknown Company',
      location: job.jobGeo || 'Remote',
      description: stripHtml(job.jobDescription || job.jobExcerpt || ''),
      url: job.url,
      source: 'api' as const,
      postedDate: job.pubDate ? new Date(job.pubDate) : undefined,
      matchScore: 0,
      matchingSkills: [],
      missingSkills: [],
      matchReasons: [`Found on Jobicy`, `Type: ${job.jobType || 'Remote'}`],
      saved: false,
      applied: false,
      salary: job.annualSalaryMin ? `$${job.annualSalaryMin}-${job.annualSalaryMax}` : undefined,
    }));

    return jobs;
  } catch (error) {
    console.warn('Jobicy API failed:', error);
    return [];
  }
}

// === Arbeitnow API (Free, No Key Required) ===
async function fetchArbeitnowJobs(query: JobSearchQuery): Promise<JobMatch[]> {
  try {
    const searchTerms = query.keywords.slice(0, 3).join(' ');
    const url = `https://www.arbeitnow.com/api/job-board-api`;
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Arbeitnow API error');
    
    const data = await response.json();
    
    // Filter by keywords
    const filteredJobs = (data.data || []).filter((job: any) => {
      const text = `${job.title} ${job.description}`.toLowerCase();
      return query.keywords.some(kw => text.includes(kw.toLowerCase()));
    });

    const jobs: JobMatch[] = filteredJobs.slice(0, 25).map((job: any) => ({
      id: `arbeitnow-${job.slug || Date.now()}-${Math.random().toString(36).slice(2)}`,
      title: job.title || 'Unknown Title',
      company: job.company_name || 'Unknown Company',
      location: job.location || (job.remote ? 'Remote' : 'Unknown'),
      description: stripHtml(job.description || ''),
      url: job.url,
      source: 'api' as const,
      postedDate: job.created_at ? new Date(job.created_at) : undefined,
      matchScore: 0,
      matchingSkills: [],
      missingSkills: [],
      matchReasons: [`Found on Arbeitnow`, job.remote ? 'Remote position' : ''],
      saved: false,
      applied: false,
      tags: job.tags || [],
    }));

    return jobs;
  } catch (error) {
    console.warn('Arbeitnow API failed:', error);
    return [];
  }
}

// === Combined Job Search ===
export async function searchAllJobAPIs(
  query: JobSearchQuery,
  userSkills: string[],
  options?: { maxResults?: number; onProgress?: (source: string, count: number) => void }
): Promise<{
  jobs: JobMatch[];
  sources: { name: string; count: number; success: boolean }[];
  totalFetched: number;
}> {
  const cacheKey = JSON.stringify(query);
  const cached = requestCache.get(cacheKey);
  
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
    return {
      jobs: cached.data,
      sources: [{ name: 'cache', count: cached.data.length, success: true }],
      totalFetched: cached.data.length,
    };
  }

  const results: { name: string; jobs: JobMatch[]; success: boolean }[] = [];
  
  // Fetch from all sources in parallel
  const [remotiveJobs, jobicyJobs, arbeitnowJobs] = await Promise.allSettled([
    fetchRemotiveJobs(query),
    fetchJobicyJobs(query),
    fetchArbeitnowJobs(query),
  ]);

  if (remotiveJobs.status === 'fulfilled') {
    results.push({ name: 'Remotive', jobs: remotiveJobs.value, success: true });
    options?.onProgress?.('Remotive', remotiveJobs.value.length);
  } else {
    results.push({ name: 'Remotive', jobs: [], success: false });
  }

  if (jobicyJobs.status === 'fulfilled') {
    results.push({ name: 'Jobicy', jobs: jobicyJobs.value, success: true });
    options?.onProgress?.('Jobicy', jobicyJobs.value.length);
  } else {
    results.push({ name: 'Jobicy', jobs: [], success: false });
  }

  if (arbeitnowJobs.status === 'fulfilled') {
    results.push({ name: 'Arbeitnow', jobs: arbeitnowJobs.value, success: true });
    options?.onProgress?.('Arbeitnow', arbeitnowJobs.value.length);
  } else {
    results.push({ name: 'Arbeitnow', jobs: [], success: false });
  }

  // Combine and deduplicate
  const allJobs = results.flatMap(r => r.jobs);
  const uniqueJobs = deduplicateJobs(allJobs);
  
  // Score jobs against user skills
  const scoredJobs = scoreJobsWithSkills(uniqueJobs, userSkills);
  
  // Sort by match score
  scoredJobs.sort((a, b) => b.matchScore - a.matchScore);
  
  // Limit results
  const limitedJobs = scoredJobs.slice(0, options?.maxResults || 75);
  
  // Cache results
  requestCache.set(cacheKey, { data: limitedJobs, timestamp: Date.now() });
  
  return {
    jobs: limitedJobs,
    sources: results.map(r => ({ name: r.name, count: r.jobs.length, success: r.success })),
    totalFetched: allJobs.length,
  };
}

// === Job Scoring with Skills ===
function scoreJobsWithSkills(jobs: JobMatch[], userSkills: string[]): JobMatch[] {
  const skillsLower = userSkills.map(s => s.toLowerCase());
  const expandedKeywords = expandSkillKeywords(skillsLower);
  
  return jobs.map(job => {
    const textLower = `${job.title} ${job.description}`.toLowerCase();
    const matchingSkills: string[] = [];
    const missingSkills: string[] = [];
    
    // Check for matching skills
    for (const skill of userSkills) {
      if (textLower.includes(skill.toLowerCase())) {
        matchingSkills.push(skill);
      }
    }
    
    // Check for common requirements user might be missing
    const commonRequirements = [
      'python', 'javascript', 'typescript', 'react', 'node', 'sql', 'aws',
      'docker', 'kubernetes', 'git', 'agile', 'scrum', 'api', 'rest',
      'machine learning', 'data', 'cloud', 'devops', 'linux', 'java', 'go',
    ];
    
    for (const req of commonRequirements) {
      if (textLower.includes(req) && !expandedKeywords.has(req)) {
        missingSkills.push(req);
      }
    }
    
    // Calculate match score
    const totalRelevantKeywords = matchingSkills.length + missingSkills.length;
    let matchScore = 50; // Base score
    
    if (totalRelevantKeywords > 0) {
      matchScore = Math.round((matchingSkills.length / totalRelevantKeywords) * 100);
    }
    
    // Boost score for title matches
    if (skillsLower.some(s => job.title.toLowerCase().includes(s))) {
      matchScore = Math.min(100, matchScore + 10);
    }
    
    // Generate match reasons
    const matchReasons = [
      ...job.matchReasons,
      matchingSkills.length > 0 ? `${matchingSkills.length} matching skills` : '',
      matchScore >= 70 ? 'Strong skills alignment' : '',
    ].filter(Boolean);
    
    return {
      ...job,
      matchScore,
      matchingSkills,
      missingSkills: missingSkills.slice(0, 5),
      matchReasons,
    };
  });
}

// === Expand Skill Keywords ===
function expandSkillKeywords(skills: string[]): Set<string> {
  const expanded = new Set(skills);
  
  const aliases: Record<string, string[]> = {
    'javascript': ['js', 'node', 'nodejs', 'node.js'],
    'typescript': ['ts'],
    'python': ['py', 'django', 'flask', 'pytorch', 'tensorflow'],
    'react': ['reactjs', 'react.js', 'redux', 'next.js', 'nextjs'],
    'vue': ['vuejs', 'vue.js', 'nuxt'],
    'angular': ['angularjs'],
    'aws': ['amazon web services', 'ec2', 's3', 'lambda'],
    'gcp': ['google cloud', 'google cloud platform'],
    'azure': ['microsoft azure'],
    'docker': ['containers', 'containerization'],
    'kubernetes': ['k8s'],
    'machine learning': ['ml', 'ai', 'artificial intelligence', 'deep learning'],
    'sql': ['mysql', 'postgresql', 'postgres', 'database'],
    'nosql': ['mongodb', 'redis', 'dynamodb'],
  };
  
  for (const skill of skills) {
    const additionalKeywords = aliases[skill] || [];
    additionalKeywords.forEach(kw => expanded.add(kw));
  }
  
  return expanded;
}

// === Deduplicate Jobs ===
function deduplicateJobs(jobs: JobMatch[]): JobMatch[] {
  const seen = new Set<string>();
  const unique: JobMatch[] = [];
  
  for (const job of jobs) {
    // Create a signature for deduplication
    const signature = `${job.title.toLowerCase().trim()}|${job.company.toLowerCase().trim()}`;
    
    if (!seen.has(signature)) {
      seen.add(signature);
      unique.push(job);
    }
  }
  
  return unique;
}

// === HTML Strip Utility ===
function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 2000);
}

// === Get API Status ===
export function getAPIStatus(): { name: string; enabled: boolean }[] {
  return API_SOURCES.map(s => ({ name: s.name, enabled: s.enabled }));
}

// === Clear Cache ===
export function clearJobCache(): void {
  requestCache.clear();
}
