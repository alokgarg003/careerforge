import { useState, useMemo, useCallback } from 'react';
import type { Job, JobFilters, JobSort, ResumeAlignmentLevel } from '@/types/job';
import { DEFAULT_FILTERS, DEFAULT_SORT } from '@/types/job';
import { parseJobsCSV } from '@/lib/csv-parser';

interface UseJobsReturn {
  jobs: Job[];
  filteredJobs: Job[];
  filters: JobFilters;
  sort: JobSort;
  isLoading: boolean;
  stats: {
    total: number;
    filtered: number;
    bySource: Record<string, number>;
    byType: Record<string, number>;
    byAlignment: Record<string, number>;
    avgMatchScore: number;
  };
  setFilters: (filters: Partial<JobFilters>) => void;
  setSort: (sort: Partial<JobSort>) => void;
  importFromCSV: (csvContent: string) => number;
  addJobs: (newJobs: Job[]) => void;
  clearJobs: () => void;
  resetFilters: () => void;
}

const STORAGE_KEY = 'job_aggregator_data';

// Load initial jobs from localStorage
const loadStoredJobs = (): Job[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
};

// Save jobs to localStorage
const saveJobs = (jobs: Job[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(jobs));
  } catch (e) {
    console.error('Failed to save jobs:', e);
  }
};

export const useJobs = (): UseJobsReturn => {
  const [jobs, setJobs] = useState<Job[]>(loadStoredJobs);
  const [isLoading, setIsLoading] = useState(false);
  const [filters, setFiltersState] = useState<JobFilters>(DEFAULT_FILTERS);
  const [sort, setSortState] = useState<JobSort>(DEFAULT_SORT);

  // Filter jobs based on current filters
  const filteredJobs = useMemo(() => {
    let result = [...jobs];

    // Search filter
    if (filters.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        job =>
          job.title.toLowerCase().includes(searchLower) ||
          job.company.toLowerCase().includes(searchLower) ||
          job.description?.toLowerCase().includes(searchLower) ||
          job.keySkills?.toLowerCase().includes(searchLower)
      );
    }

    // Source filter
    if (filters.source !== 'all') {
      result = result.filter(job => job.source === filters.source);
    }

    // Experience level filter
    if (filters.experienceLevel !== 'all') {
      result = result.filter(job => job.experienceLevel === filters.experienceLevel);
    }

    // Job type filter
    if (filters.jobType !== 'all') {
      result = result.filter(job => job.jobType === filters.jobType);
    }

    // Location filter
    if (filters.location) {
      const locationLower = filters.location.toLowerCase();
      result = result.filter(job => 
        job.location.toLowerCase().includes(locationLower)
      );
    }

    // Date range filter
    if (filters.dateRange !== 'all') {
      const now = new Date();
      const ranges: Record<string, number> = {
        '24h': 1,
        '7d': 7,
        '30d': 30,
      };
      const days = ranges[filters.dateRange];
      if (days) {
        const cutoff = new Date(now.getTime() - days * 24 * 60 * 60 * 1000);
        result = result.filter(job => {
          const jobDate = new Date(job.postedDate);
          return jobDate >= cutoff;
        });
      }
    }

    // Alignment level filter
    if (filters.alignmentLevel !== 'all') {
      result = result.filter(job => job.resumeAlignmentLevel === filters.alignmentLevel);
    }

    // Min match score filter
    if (filters.minMatchScore > 0) {
      result = result.filter(job => (job.matchScore || 0) >= filters.minMatchScore);
    }

    // Sort
    result.sort((a, b) => {
      let comparison = 0;
      
      switch (sort.field) {
        case 'postedDate':
          comparison = new Date(a.postedDate).getTime() - new Date(b.postedDate).getTime();
          break;
        case 'company':
          comparison = a.company.localeCompare(b.company);
          break;
        case 'title':
          comparison = a.title.localeCompare(b.title);
          break;
        case 'matchScore':
          comparison = (a.matchScore || 0) - (b.matchScore || 0);
          break;
      }
      
      return sort.order === 'desc' ? -comparison : comparison;
    });

    return result;
  }, [jobs, filters, sort]);

  // Calculate stats
  const stats = useMemo(() => {
    const bySource: Record<string, number> = {};
    const byType: Record<string, number> = {};
    const byAlignment: Record<string, number> = {};
    let totalScore = 0;
    let scoreCount = 0;

    jobs.forEach(job => {
      bySource[job.source] = (bySource[job.source] || 0) + 1;
      byType[job.jobType] = (byType[job.jobType] || 0) + 1;
      if (job.resumeAlignmentLevel) {
        byAlignment[job.resumeAlignmentLevel] = (byAlignment[job.resumeAlignmentLevel] || 0) + 1;
      }
      if (job.matchScore !== undefined) {
        totalScore += job.matchScore;
        scoreCount++;
      }
    });

    return {
      total: jobs.length,
      filtered: filteredJobs.length,
      bySource,
      byType,
      byAlignment,
      avgMatchScore: scoreCount > 0 ? Math.round(totalScore / scoreCount) : 0,
    };
  }, [jobs, filteredJobs]);

  const setFilters = useCallback((newFilters: Partial<JobFilters>) => {
    setFiltersState(prev => ({ ...prev, ...newFilters }));
  }, []);

  const setSort = useCallback((newSort: Partial<JobSort>) => {
    setSortState(prev => ({ ...prev, ...newSort }));
  }, []);

  const importFromCSV = useCallback((csvContent: string): number => {
    setIsLoading(true);
    try {
      const newJobs = parseJobsCSV(csvContent);
      
      // Deduplicate with existing jobs by URL
      const existingUrls = new Set(jobs.map(j => j.url));
      const uniqueNewJobs = newJobs.filter(j => !existingUrls.has(j.url));
      
      const updatedJobs = [...jobs, ...uniqueNewJobs];
      setJobs(updatedJobs);
      saveJobs(updatedJobs);
      
      return uniqueNewJobs.length;
    } finally {
      setIsLoading(false);
    }
  }, [jobs]);

  const addJobs = useCallback((newJobs: Job[]) => {
    const existingUrls = new Set(jobs.map(j => j.url));
    const uniqueNewJobs = newJobs.filter(j => !existingUrls.has(j.url));
    const updatedJobs = [...jobs, ...uniqueNewJobs];
    setJobs(updatedJobs);
    saveJobs(updatedJobs);
  }, [jobs]);

  const clearJobs = useCallback(() => {
    setJobs([]);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  const resetFilters = useCallback(() => {
    setFiltersState(DEFAULT_FILTERS);
  }, []);

  return {
    jobs,
    filteredJobs,
    filters,
    sort,
    isLoading,
    stats,
    setFilters,
    setSort,
    importFromCSV,
    addJobs,
    clearJobs,
    resetFilters,
  };
};
