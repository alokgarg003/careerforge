// ============================================================================
// Local LLM Hook (Ollama/LMStudio Integration)
// ============================================================================
// Provides interface to local LLM models for AI-powered insights.
// All processing happens locally - no data leaves the user's machine.
// ============================================================================

import { useState, useCallback, useRef } from 'react';
import { LocalAIConfig, DEFAULT_AI_CONFIG } from '@/types/resume';

interface GenerateOptions {
  prompt: string;
  context?: string;
  temperature?: number;
  maxTokens?: number;
}

interface LLMResponse {
  text: string;
  tokensUsed?: number;
  duration?: number;
}

export function useLocalLLM() {
  const [config, setConfig] = useState<LocalAIConfig>(DEFAULT_AI_CONFIG);
  const [isGenerating, setIsGenerating] = useState(false);
  const [lastError, setLastError] = useState<string | null>(null);
  const abortControllerRef = useRef<AbortController | null>(null);

  // Test connection to local LLM
  const testConnection = useCallback(async (customConfig?: Partial<LocalAIConfig>): Promise<boolean> => {
    const testConfig = { ...config, ...customConfig };
    
    try {
      const endpoint = testConfig.provider === 'ollama' 
        ? `${testConfig.endpoint}/api/tags`
        : `${testConfig.endpoint}/v1/models`;
      
      const response = await fetch(endpoint, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      });

      if (response.ok) {
        setConfig(prev => ({ ...prev, ...customConfig, isConnected: true, lastError: undefined }));
        setLastError(null);
        return true;
      }
      
      throw new Error(`Connection failed: ${response.status}`);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Connection failed';
      setLastError(message);
      setConfig(prev => ({ ...prev, isConnected: false, lastError: message }));
      return false;
    }
  }, [config]);

  // Generate text using local LLM
  const generate = useCallback(async (options: GenerateOptions): Promise<LLMResponse | null> => {
    if (!config.isConnected) {
      const connected = await testConnection();
      if (!connected) {
        setLastError('Local LLM not connected. Start Ollama with: ollama run mistral');
        return null;
      }
    }

    setIsGenerating(true);
    setLastError(null);
    abortControllerRef.current = new AbortController();

    const startTime = Date.now();

    try {
      let response: Response;
      let fullText = '';

      if (config.provider === 'ollama') {
        // Ollama API
        response = await fetch(`${config.endpoint}/api/generate`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: config.model,
            prompt: options.context 
              ? `Context:\n${options.context}\n\nTask:\n${options.prompt}`
              : options.prompt,
            stream: false,
            options: {
              temperature: options.temperature ?? 0.7,
              num_predict: options.maxTokens ?? 1024,
            },
          }),
          signal: abortControllerRef.current.signal,
        });

        if (!response.ok) {
          throw new Error(`Ollama error: ${response.status}`);
        }

        const data = await response.json();
        fullText = data.response || '';
      } else {
        // OpenAI-compatible API (LMStudio, etc.)
        response = await fetch(`${config.endpoint}/v1/chat/completions`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: config.model,
            messages: [
              ...(options.context ? [{ role: 'system', content: options.context }] : []),
              { role: 'user', content: options.prompt },
            ],
            temperature: options.temperature ?? 0.7,
            max_tokens: options.maxTokens ?? 1024,
          }),
          signal: abortControllerRef.current.signal,
        });

        if (!response.ok) {
          throw new Error(`LLM API error: ${response.status}`);
        }

        const data = await response.json();
        fullText = data.choices?.[0]?.message?.content || '';
      }

      const duration = Date.now() - startTime;

      return {
        text: fullText.trim(),
        duration,
      };
    } catch (error) {
      if (error instanceof Error && error.name === 'AbortError') {
        return null;
      }
      
      const message = error instanceof Error ? error.message : 'Generation failed';
      setLastError(message);
      setConfig(prev => ({ ...prev, isConnected: false }));
      return null;
    } finally {
      setIsGenerating(false);
      abortControllerRef.current = null;
    }
  }, [config, testConnection]);

  // Cancel ongoing generation
  const cancel = useCallback(() => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
      setIsGenerating(false);
    }
  }, []);

  // Update configuration
  const updateConfig = useCallback((updates: Partial<LocalAIConfig>) => {
    setConfig(prev => ({ ...prev, ...updates, isConnected: false }));
  }, []);

  // Generate career insight
  const generateCareerInsight = useCallback(async (
    skills: string[],
    positions: Array<{ title: string; company: string; years: number }>,
  ): Promise<string | null> => {
    const prompt = `Based on the following professional profile, provide 3 actionable career insights:

Skills: ${skills.slice(0, 20).join(', ')}

Experience:
${positions.slice(0, 5).map(p => `- ${p.title} at ${p.company} (${p.years} years)`).join('\n')}

Provide specific, actionable insights about:
1. Career trajectory and growth areas
2. Skills to develop next
3. Strategic networking suggestions

Keep each insight to 2-3 sentences.`;

    const result = await generate({ prompt });
    return result?.text || null;
  }, [generate]);

  // Score resume against job description
  const scoreResume = useCallback(async (
    resumeText: string,
    jobDescription: string,
  ): Promise<{ score: number; feedback: string } | null> => {
    const prompt = `Score this resume against the job description on a scale of 0-100.

RESUME:
${resumeText.slice(0, 3000)}

JOB DESCRIPTION:
${jobDescription.slice(0, 1500)}

Respond in this exact format:
SCORE: [number 0-100]
MATCHING SKILLS: [comma-separated list]
MISSING SKILLS: [comma-separated list]
IMPROVEMENTS: [3 bullet points]`;

    const result = await generate({ prompt, maxTokens: 800 });
    if (!result?.text) return null;

    // Parse score from response
    const scoreMatch = result.text.match(/SCORE:\s*(\d+)/i);
    const score = scoreMatch ? parseInt(scoreMatch[1], 10) : 50;

    return {
      score: Math.min(100, Math.max(0, score)),
      feedback: result.text,
    };
  }, [generate]);

  // Generate ATS-optimized resume
  const generateATSResume = useCallback(async (
    resumeText: string,
    jobDescription: string,
    targetKeywords: string[],
  ): Promise<string | null> => {
    const prompt = `Rewrite this resume to be ATS-friendly and optimized for the target job.

CURRENT RESUME:
${resumeText.slice(0, 2500)}

TARGET JOB KEYWORDS:
${targetKeywords.join(', ')}

JOB DESCRIPTION:
${jobDescription.slice(0, 1000)}

Guidelines:
- Use simple formatting (no tables, columns, graphics)
- Include target keywords naturally
- Use standard section headers
- Quantify achievements with numbers
- Keep it to 1-2 pages equivalent

Output the optimized resume in clean Markdown format.`;

    const result = await generate({ prompt, maxTokens: 2000 });
    return result?.text || null;
  }, [generate]);

  // Analyze network for job search
  const analyzeNetworkForJobs = useCallback(async (
    targetRole: string,
    connectionsByCompany: Record<string, number>,
    industries: string[],
  ): Promise<string | null> => {
    const topCompanies = Object.entries(connectionsByCompany)
      .sort(([, a], [, b]) => b - a)
      .slice(0, 10)
      .map(([company, count]) => `${company}: ${count} connections`);

    const prompt = `Suggest a networking strategy for finding a ${targetRole} role.

TOP CONNECTED COMPANIES:
${topCompanies.join('\n')}

INDUSTRIES: ${industries.join(', ')}

Provide:
1. Which 3 companies to prioritize for outreach
2. How to leverage existing connections
3. Cold outreach strategy for gaps
4. Specific actions to take this week`;

    const result = await generate({ prompt, maxTokens: 800 });
    return result?.text || null;
  }, [generate]);

  return {
    config,
    isGenerating,
    lastError,
    testConnection,
    generate,
    cancel,
    updateConfig,
    generateCareerInsight,
    scoreResume,
    generateATSResume,
    analyzeNetworkForJobs,
  };
}
