// ============================================================================
// LinkedIn Data Context
// ============================================================================
// Provides global state management for LinkedIn data analysis.
// All data is processed and stored client-side only.
// ============================================================================

import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { LinkedInData, initialLinkedInData } from '@/types/linkedin';
import { parseLinkedInExport, calculateCareerAnalytics } from '@/lib/linkedin-parser';
import { toast } from '@/hooks/use-toast';

interface LinkedInContextType {
  data: LinkedInData;
  analytics: ReturnType<typeof calculateCareerAnalytics> | null;
  isLoading: boolean;
  error: string | null;
  loadFromFile: (file: File) => Promise<void>;
  clearData: () => void;
}

const LinkedInContext = createContext<LinkedInContextType | undefined>(undefined);

const STORAGE_KEY = 'linkedin-career-intelligence-data';

export function LinkedInProvider({ children }: { children: React.ReactNode }) {
  const [data, setData] = useState<LinkedInData>(initialLinkedInData);
  const [analytics, setAnalytics] = useState<ReturnType<typeof calculateCareerAnalytics> | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const storageFailedRef = useRef(false); // Track if storage has failed to avoid repeated toasts

  // Load from sessionStorage on mount (ephemeral - clears on close)
  useEffect(() => {
    try {
      const stored = sessionStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed.loadedAt) parsed.loadedAt = new Date(parsed.loadedAt);
        if (parsed.positions) {
          parsed.positions = parsed.positions.map((p: any) => ({
            ...p,
            startDate: p.startDate ? new Date(p.startDate) : null,
            endDate: p.endDate ? new Date(p.endDate) : null,
          }));
        }
        if (parsed.education) {
          parsed.education = parsed.education.map((e: any) => ({
            ...e,
            startDate: e.startDate ? new Date(e.startDate) : null,
            endDate: e.endDate ? new Date(e.endDate) : null,
          }));
        }
        if (parsed.certifications) {
          parsed.certifications = parsed.certifications.map((c: any) => ({
            ...c,
            startDate: c.startDate ? new Date(c.startDate) : null,
            endDate: c.endDate ? new Date(c.endDate) : null,
          }));
        }
        if (parsed.jobApplications) {
          parsed.jobApplications = parsed.jobApplications.map((j: any) => ({
            ...j,
            applicationDate: j.applicationDate ? new Date(j.applicationDate) : null,
          }));
        }
        if (parsed.savedJobs) {
          parsed.savedJobs = parsed.savedJobs.map((j: any) => ({
            ...j,
            savedDate: j.savedDate ? new Date(j.savedDate) : null,
          }));
        }
        setData(parsed);
        if (parsed.isLoaded) {
          setAnalytics(calculateCareerAnalytics(parsed));
        }
      }
    } catch (err) {
      console.warn('Failed to load stored LinkedIn data:', err);
    }
  }, []);

  // Save to sessionStorage when data changes
  useEffect(() => {
    if (data.isLoaded) {
      try {
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        // Reset failure flag on success (in case storage was cleared)
        storageFailedRef.current = false;
      } catch (err) {
        // Handle quota exceeded or other storage errors
        const isQuotaError = err instanceof DOMException && (
          err.name === 'QuotaExceededError' ||
          err.name === 'NS_ERROR_DOM_QUOTA_REACHED' || // Firefox
          err.code === 22 // Legacy browsers
        );
        
        // Only show toast once per session to avoid spamming
        if (!storageFailedRef.current) {
          storageFailedRef.current = true;
          toast({
            title: 'Storage limit reached',
            description: isQuotaError 
              ? 'Your LinkedIn data is too large to save. Data will be available this session but won\'t persist if you refresh.'
              : 'Could not save data to browser storage. Data will only be available this session.',
            variant: 'destructive',
          });
        }
        console.warn('Failed to save LinkedIn data:', err);
      }
    }
  }, [data]);

  const loadFromFile = useCallback(async (file: File) => {
    setIsLoading(true);
    setError(null);

    try {
      const parsedData = await parseLinkedInExport(file);
      setData(parsedData);
      setAnalytics(calculateCareerAnalytics(parsedData));
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to parse LinkedIn export';
      setError(message);
      console.error('LinkedIn parse error:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const clearData = useCallback(() => {
    setData(initialLinkedInData);
    setAnalytics(null);
    setError(null);
    sessionStorage.removeItem(STORAGE_KEY);
  }, []);

  return (
    <LinkedInContext.Provider value={{ data, analytics, isLoading, error, loadFromFile, clearData }}>
      {children}
    </LinkedInContext.Provider>
  );
}

export function useLinkedIn() {
  const context = useContext(LinkedInContext);
  if (!context) {
    throw new Error('useLinkedIn must be used within a LinkedInProvider');
  }
  return context;
}
