import React, { createContext, useContext, ReactNode } from 'react';
import { useJobs } from '@/hooks/useJobs';
import type { Job, JobFilters, JobSort } from '@/types/job';

interface JobContextValue {
  jobs: Job[];
  filteredJobs: Job[];
  filters: JobFilters;
  sort: JobSort;
  isLoading: boolean;
  stats: {
    total: number;
    filtered: number;
    bySource: Record<string, number>;
    byType: Record<string, number>;
    byAlignment: Record<string, number>;
    avgMatchScore: number;
  };
  setFilters: (filters: Partial<JobFilters>) => void;
  setSort: (sort: Partial<JobSort>) => void;
  importFromCSV: (csvContent: string) => number;
  addJobs: (newJobs: Job[]) => void;
  clearJobs: () => void;
  resetFilters: () => void;
}

const JobContext = createContext<JobContextValue | null>(null);

export const JobProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const jobsState = useJobs();

  return (
    <JobContext.Provider value={jobsState}>
      {children}
    </JobContext.Provider>
  );
};

export const useJobContext = (): JobContextValue => {
  const context = useContext(JobContext);
  if (!context) {
    throw new Error('useJobContext must be used within a JobProvider');
  }
  return context;
};
