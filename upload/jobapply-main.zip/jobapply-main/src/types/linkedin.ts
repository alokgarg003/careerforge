// ============================================================================
// LinkedIn Data Export Types
// ============================================================================
// This file defines all TypeScript interfaces for LinkedIn data analysis.
// All types are designed to support client-side parsing without exposing
// personally identifiable information (PII) of other users.
// ============================================================================

// === Profile Data ===
export interface LinkedInProfile {
  firstName: string;
  lastName: string;
  headline: string;
  industry: string;
  location: string;
  summary: string;
}

// === Position/Experience Data ===
export interface LinkedInPosition {
  companyName: string;
  title: string;
  description: string;
  location: string;
  startDate: Date | null;
  endDate: Date | null;
  isCurrent: boolean;
}

// === Education Data ===
export interface LinkedInEducation {
  schoolName: string;
  degreeName: string;
  fieldOfStudy: string;
  startDate: Date | null;
  endDate: Date | null;
  notes: string;
}

// === Skills Data ===
export interface LinkedInSkill {
  name: string;
  endorsementCount?: number;
}

// === Connection Data (Aggregated Only) ===
// Individual connection details are NOT stored for privacy
export interface ConnectionStats {
  totalConnections: number;
  connectionsByMonth: { month: string; count: number }[];
  connectionsByYear: { year: string; count: number }[];
  industryDistribution: { industry: string; count: number }[];
  locationDistribution: { location: string; count: number }[];
}

// === Company Data ===
export interface LinkedInCompany {
  name: string;
  industry?: string;
  location?: string;
  interactionType: 'followed' | 'applied' | 'worked' | 'connected';
  userNotes?: string;
}

// === Job Application Data ===
export interface LinkedInJobApplication {
  jobTitle: string;
  companyName: string;
  applicationDate: Date | null;
  status?: string;
}

// === Saved Job Data ===
export interface LinkedInSavedJob {
  jobTitle: string;
  companyName: string;
  savedDate: Date | null;
}

// === Certification Data ===
export interface LinkedInCertification {
  name: string;
  authority: string;
  licenseNumber?: string;
  startDate: Date | null;
  endDate: Date | null;
}

// === Aggregated Analytics (Privacy-Safe) ===
export interface CareerAnalytics {
  // Career Growth Metrics
  totalYearsExperience: number;
  positionsCount: number;
  companiesWorkedAt: number;
  averageTenureMonths: number;
  
  // Skills Analysis
  topSkills: { skill: string; endorsements: number }[];
  skillCategories: { category: string; count: number }[];
  
  // Education Summary
  degrees: string[];
  institutions: string[];
  
  // Job Search Metrics
  totalApplications: number;
  applicationsByMonth: { month: string; count: number }[];
  savedJobsCount: number;
  
  // Network Metrics (Aggregated Only)
  networkStats: ConnectionStats;
}

// === Data Discovery Result ===
export interface LinkedInDataDiscovery {
  files: {
    name: string;
    category: 'profile' | 'connections' | 'companies' | 'jobs' | 'skills' | 'education' | 'activity' | 'other';
    rowCount: number;
    columns: string[];
    usableForAnalysis: boolean;
    privacyConcerns: string[];
  }[];
  summary: {
    totalFiles: number;
    usableFiles: number;
    dateRange: { earliest: string; latest: string };
  };
}

// === Complete LinkedIn Data State ===
export interface LinkedInData {
  profile: LinkedInProfile | null;
  positions: LinkedInPosition[];
  education: LinkedInEducation[];
  skills: LinkedInSkill[];
  certifications: LinkedInCertification[];
  companies: LinkedInCompany[];
  jobApplications: LinkedInJobApplication[];
  savedJobs: LinkedInSavedJob[];
  connectionStats: ConnectionStats;
  dataDiscovery: LinkedInDataDiscovery | null;
  isLoaded: boolean;
  loadedAt: Date | null;
}

// === Initial/Empty State ===
export const initialLinkedInData: LinkedInData = {
  profile: null,
  positions: [],
  education: [],
  skills: [],
  certifications: [],
  companies: [],
  jobApplications: [],
  savedJobs: [],
  connectionStats: {
    totalConnections: 0,
    connectionsByMonth: [],
    connectionsByYear: [],
    industryDistribution: [],
    locationDistribution: [],
  },
  dataDiscovery: null,
  isLoaded: false,
  loadedAt: null,
};

// === File Category Mapping ===
export const FILE_CATEGORY_MAP: Record<string, 'profile' | 'connections' | 'companies' | 'jobs' | 'skills' | 'education' | 'activity' | 'other'> = {
  'Profile': 'profile',
  'Positions': 'profile',
  'Education': 'education',
  'Skills': 'skills',
  'Certifications': 'education',
  'Connections': 'connections',
  'Companies Followed': 'companies',
  'Company Follows': 'companies',
  'Jobs': 'jobs',
  'Job Applications': 'jobs',
  'Saved Jobs': 'jobs',
  'Messages': 'activity',
  'Invitations': 'activity',
  'Reactions': 'activity',
  'Comments': 'activity',
  'Shares': 'activity',
  'Rich Media': 'other',
};

// === Privacy-Sensitive Fields (Always Excluded) ===
export const PRIVACY_SENSITIVE_FIELDS = [
  'Email Address',
  'email',
  'Phone Number',
  'phone',
  'Profile URL',
  'profileUrl',
  'First Name',
  'Last Name',
  'Name',
  'Message',
  'Content',
];
