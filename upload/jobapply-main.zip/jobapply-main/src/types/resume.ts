// ============================================================================
// Resume & Job Matching Types
// ============================================================================
// Types for resume parsing, scoring, ATS optimization, and job matching.
// All processing happens locally - no data leaves the browser.
// ============================================================================

// === Parsed Resume Data ===
export interface ParsedResume {
  // Contact info (user's own data)
  name: string;
  email: string;
  phone: string;
  location: string;
  
  // Professional summary
  summary: string;
  
  // Work experience
  experience: ResumeExperience[];
  
  // Education
  education: ResumeEducation[];
  
  // Skills extracted from resume
  skills: string[];
  
  // Certifications
  certifications: string[];
  
  // Raw text for AI analysis
  rawText: string;
  
  // Metadata
  fileName: string;
  parsedAt: Date;
}

export interface ResumeExperience {
  title: string;
  company: string;
  location: string;
  startDate: string;
  endDate: string;
  description: string;
  highlights: string[];
}

export interface ResumeEducation {
  institution: string;
  degree: string;
  field: string;
  graduationDate: string;
  gpa?: string;
}

// === Job Match Result ===
export interface JobMatch {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  url?: string;
  source: 'api' | 'manual';
  postedDate?: Date;
  salary?: string;
  tags?: string[];
  
  // Match analysis
  matchScore: number; // 0-100
  matchingSkills: string[];
  missingSkills: string[];
  matchReasons: string[];
  
  // User interaction
  saved: boolean;
  applied: boolean;
  notes?: string;
}

// === Resume Score Result ===
export interface ResumeScore {
  overallScore: number; // 0-100
  
  // Breakdown
  skillsMatch: number;
  experienceMatch: number;
  educationMatch: number;
  keywordDensity: number;
  
  // Feedback
  strengths: string[];
  gaps: string[];
  suggestions: string[];
  
  // Keywords analysis
  foundKeywords: string[];
  missingKeywords: string[];
  
  // ATS compatibility
  atsCompatibility: 'high' | 'medium' | 'low';
  atsIssues: string[];
}

// === ATS-Optimized Resume ===
export interface ATSResume {
  content: string; // Markdown or plain text
  format: 'markdown' | 'text';
  optimizedFor: string; // Job title/description
  keywordsAdded: string[];
  generatedAt: Date;
}

// === Local AI Configuration ===
export interface LocalAIConfig {
  provider: 'ollama' | 'lmstudio' | 'manual';
  endpoint: string;
  model: string;
  isConnected: boolean;
  lastError?: string;
}

export const DEFAULT_AI_CONFIG: LocalAIConfig = {
  provider: 'ollama',
  endpoint: 'http://localhost:11434',
  model: 'mistral',
  isConnected: false,
};

// === AI Insight Types ===
export interface AIInsight {
  id: string;
  type: 'career' | 'network' | 'job' | 'resume' | 'skill';
  title: string;
  content: string;
  confidence: 'high' | 'medium' | 'low';
  generatedAt: Date;
  context?: string;
}

// === Job Search Query ===
export interface JobSearchQuery {
  keywords: string[];
  location?: string;
  remote?: boolean;
  experienceLevel?: 'entry' | 'mid' | 'senior' | 'executive';
  datePosted?: 'day' | 'week' | 'month' | 'any';
}

// === Skill Extraction Result ===
export interface SkillExtraction {
  // From LinkedIn
  linkedInSkills: string[];
  endorsedSkills: { skill: string; endorsements: number }[];
  
  // From Resume
  resumeSkills: string[];
  
  // Combined & deduplicated
  allSkills: string[];
  
  // Categorized
  technicalSkills: string[];
  softSkills: string[];
  industrySkills: string[];
  
  // Skill gaps (from job market analysis)
  inDemandMissing: string[];
}

// === Initial States ===
export const initialParsedResume: ParsedResume = {
  name: '',
  email: '',
  phone: '',
  location: '',
  summary: '',
  experience: [],
  education: [],
  skills: [],
  certifications: [],
  rawText: '',
  fileName: '',
  parsedAt: new Date(),
};

export const initialSkillExtraction: SkillExtraction = {
  linkedInSkills: [],
  endorsedSkills: [],
  resumeSkills: [],
  allSkills: [],
  technicalSkills: [],
  softSkills: [],
  industrySkills: [],
  inDemandMissing: [],
};
