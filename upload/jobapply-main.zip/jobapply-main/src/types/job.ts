// Job listing schema - matches the backend output from JobSpy
export interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  experienceLevel: ExperienceLevel;
  experienceRange?: string; // Raw experience range from backend (e.g., "3+ years")
  jobType: JobType;
  postedDate: string;
  source: JobSource;
  url: string;
  scrapeTimestamp: string;
  description?: string;
  salary?: string;
  // Additional fields from JobSpy backend
  keySkills?: string;
  matchScore?: number;
  whyThisJobFits?: string;
  missingSkills?: string;
  resumeAlignmentLevel?: ResumeAlignmentLevel;
  isRemote?: boolean;
  workFromHomeType?: string;
}

export type ExperienceLevel = 
  | 'entry'
  | 'junior'
  | 'mid'
  | 'senior'
  | 'lead'
  | 'executive'
  | 'unknown';

export type JobType = 
  | 'full-time'
  | 'part-time'
  | 'contract'
  | 'internship'
  | 'remote'
  | 'hybrid'
  | 'unknown';

export type JobSource = 
  | 'linkedin'
  | 'indeed'
  | 'naukri'
  | 'wellfound'
  | 'glassdoor'
  | 'other';

export type ResumeAlignmentLevel = 
  | 'Strong Match'
  | 'Good Match'
  | 'Stretch Role'
  | 'Ignore'
  | 'Unknown';

export interface JobFilters {
  search: string;
  source: JobSource | 'all';
  experienceLevel: ExperienceLevel | 'all';
  jobType: JobType | 'all';
  location: string;
  dateRange: 'all' | '24h' | '7d' | '30d';
  alignmentLevel: ResumeAlignmentLevel | 'all';
  minMatchScore: number;
}

export type SortField = 'postedDate' | 'company' | 'title' | 'matchScore';
export type SortOrder = 'asc' | 'desc';

export interface JobSort {
  field: SortField;
  order: SortOrder;
}

export const DEFAULT_FILTERS: JobFilters = {
  search: '',
  source: 'all',
  experienceLevel: 'all',
  jobType: 'all',
  location: '',
  dateRange: 'all',
  alignmentLevel: 'all',
  minMatchScore: 0,
};

export const DEFAULT_SORT: JobSort = {
  field: 'matchScore',
  order: 'desc',
};

// Label mappings for display
export const EXPERIENCE_LABELS: Record<ExperienceLevel, string> = {
  entry: 'Entry Level',
  junior: 'Junior',
  mid: 'Mid-Level',
  senior: 'Senior',
  lead: 'Lead',
  executive: 'Executive',
  unknown: 'Not Specified',
};

export const JOB_TYPE_LABELS: Record<JobType, string> = {
  'full-time': 'Full-time',
  'part-time': 'Part-time',
  contract: 'Contract',
  internship: 'Internship',
  remote: 'Remote',
  hybrid: 'Hybrid',
  unknown: 'Not Specified',
};

export const SOURCE_LABELS: Record<JobSource, string> = {
  linkedin: 'LinkedIn',
  indeed: 'Indeed',
  naukri: 'Naukri',
  wellfound: 'Wellfound',
  glassdoor: 'Glassdoor',
  other: 'Other',
};

export const ALIGNMENT_LABELS: Record<ResumeAlignmentLevel, string> = {
  'Strong Match': 'Strong Match',
  'Good Match': 'Good Match',
  'Stretch Role': 'Stretch Role',
  'Ignore': 'Ignore',
  'Unknown': 'Unknown',
};

export const ALIGNMENT_COLORS: Record<ResumeAlignmentLevel, string> = {
  'Strong Match': 'bg-green-500/20 text-green-400 border-green-500/30',
  'Good Match': 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  'Stretch Role': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  'Ignore': 'bg-muted text-muted-foreground border-muted',
  'Unknown': 'bg-muted text-muted-foreground border-muted',
};
