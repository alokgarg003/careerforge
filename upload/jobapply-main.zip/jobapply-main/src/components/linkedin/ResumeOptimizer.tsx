// ============================================================================
// Resume Optimizer Component
// ============================================================================
// Upload, parse, score, and regenerate resumes - all client-side.
// Integrates with local LLM for AI-powered optimization.
// ============================================================================

import { useState, useCallback } from 'react';
import { Upload, FileText, Sparkles, Download, Target, AlertCircle, Check, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { parseResumeFile, extractCombinedSkills } from '@/lib/resume-parser';
import { createManualJob, calculateMatchScore, exportJobsToCSV } from '@/lib/job-matching';
import { useLocalLLM } from '@/hooks/useLocalLLM';
import { useLinkedIn } from '@/context/LinkedInContext';
import { ParsedResume, JobMatch, initialParsedResume } from '@/types/resume';

export function ResumeOptimizer() {
  const { toast } = useToast();
  const { data: linkedInData } = useLinkedIn();
  const { isGenerating, lastError, scoreResume, generateATSResume, config } = useLocalLLM();
  
  const [resume, setResume] = useState<ParsedResume>(initialParsedResume);
  const [resumeText, setResumeText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [jobTitle, setJobTitle] = useState('');
  const [jobCompany, setJobCompany] = useState('');
  const [scoreResult, setScoreResult] = useState<{ score: number; feedback: string } | null>(null);
  const [atsResume, setAtsResume] = useState<string | null>(null);
  const [savedJobs, setSavedJobs] = useState<JobMatch[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  // Combined skills from LinkedIn + Resume
  const combinedSkills = extractCombinedSkills(
    linkedInData.skills,
    resume.skills,
  );

  // Handle resume file upload
  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const parsed = await parseResumeFile(file);
      setResume(parsed);
      setResumeText(parsed.rawText || '');
      toast({
        title: 'Resume Parsed',
        description: `Found ${parsed.skills.length} skills and ${parsed.experience.length} experiences`,
      });
    } catch (error) {
      toast({
        title: 'Parse Error',
        description: 'Could not parse resume. Try pasting text directly.',
        variant: 'destructive',
      });
    } finally {
      setIsUploading(false);
    }
  }, [toast]);

  // Handle paste text
  const handlePasteResume = useCallback((text: string) => {
    setResumeText(text);
    // Quick skill extraction
    const skills = extractSkillsFromText(text);
    setResume(prev => ({ ...prev, rawText: text, skills }));
  }, []);

  // Score resume against job
  const handleScoreResume = useCallback(async () => {
    if (!resumeText || !jobDescription) {
      toast({
        title: 'Missing Data',
        description: 'Please provide both resume and job description',
        variant: 'destructive',
      });
      return;
    }

    if (!config.isConnected) {
      // Fallback to simple keyword matching
      const { score, matchingSkills, missingKeywords } = calculateMatchScore(
        jobDescription,
        combinedSkills.allSkills,
      );
      
      setScoreResult({
        score,
        feedback: `**Match Score: ${score}/100**\n\n**Matching Skills:** ${matchingSkills.join(', ') || 'None found'}\n\n**Missing Keywords:** ${missingKeywords.join(', ') || 'None'}\n\n*Connect to Ollama for detailed AI analysis*`,
      });
      return;
    }

    const result = await scoreResume(resumeText, jobDescription);
    if (result) {
      setScoreResult(result);
    } else {
      toast({
        title: 'Scoring Failed',
        description: lastError || 'Could not score resume',
        variant: 'destructive',
      });
    }
  }, [resumeText, jobDescription, config.isConnected, combinedSkills.allSkills, scoreResume, toast, lastError]);

  // Generate ATS-optimized resume
  const handleGenerateATS = useCallback(async () => {
    if (!resumeText || !jobDescription) {
      toast({
        title: 'Missing Data',
        description: 'Please provide both resume and job description',
        variant: 'destructive',
      });
      return;
    }

    if (!config.isConnected) {
      toast({
        title: 'AI Not Connected',
        description: 'Start Ollama to generate ATS resume: ollama run mistral',
        variant: 'destructive',
      });
      return;
    }

    const result = await generateATSResume(resumeText, jobDescription, combinedSkills.allSkills);
    if (result) {
      setAtsResume(result);
    } else {
      toast({
        title: 'Generation Failed',
        description: lastError || 'Could not generate ATS resume',
        variant: 'destructive',
      });
    }
  }, [resumeText, jobDescription, config.isConnected, combinedSkills.allSkills, generateATSResume, toast, lastError]);

  // Save job for tracking
  const handleSaveJob = useCallback(() => {
    if (!jobTitle || !jobDescription) return;

    const newJob = createManualJob(
      jobTitle,
      jobCompany,
      jobDescription,
      combinedSkills.allSkills,
    );
    
    setSavedJobs(prev => [newJob, ...prev]);
    toast({
      title: 'Job Saved',
      description: `${jobTitle} added with ${newJob.matchScore}% match`,
    });
  }, [jobTitle, jobCompany, jobDescription, combinedSkills.allSkills, toast]);

  // Export saved jobs
  const handleExportJobs = useCallback(() => {
    if (savedJobs.length === 0) return;
    
    const csv = exportJobsToCSV(savedJobs);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `job-matches-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }, [savedJobs]);

  // Download ATS resume
  const handleDownloadATS = useCallback(() => {
    if (!atsResume) return;
    
    const blob = new Blob([atsResume], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ats-resume-${new Date().toISOString().split('T')[0]}.md`;
    a.click();
    URL.revokeObjectURL(url);
  }, [atsResume]);

  return (
    <div className="space-y-6">
      {/* Header with AI Status */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Resume Optimizer</h2>
          <p className="text-muted-foreground text-sm">
            Score and optimize your resume for specific jobs
          </p>
        </div>
        <Badge variant={config.isConnected ? 'default' : 'outline'}>
          {config.isConnected ? (
            <>
              <Check className="h-3 w-3 mr-1" />
              AI Connected
            </>
          ) : (
            <>
              <AlertCircle className="h-3 w-3 mr-1" />
              Basic Mode
            </>
          )}
        </Badge>
      </div>

      {/* Skills Overview */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg">Your Skills Profile</CardTitle>
          <CardDescription>
            Combined from LinkedIn ({linkedInData.skills.length}) and Resume ({resume.skills.length})
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {combinedSkills.allSkills.slice(0, 20).map((skill, i) => (
              <Badge key={i} variant="secondary">{skill}</Badge>
            ))}
            {combinedSkills.allSkills.length > 20 && (
              <Badge variant="outline">+{combinedSkills.allSkills.length - 20} more</Badge>
            )}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="upload">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="upload">Upload Resume</TabsTrigger>
          <TabsTrigger value="score">Score Match</TabsTrigger>
          <TabsTrigger value="optimize">ATS Optimize</TabsTrigger>
          <TabsTrigger value="jobs">Saved Jobs ({savedJobs.length})</TabsTrigger>
        </TabsList>

        {/* Upload Tab */}
        <TabsContent value="upload" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload or Paste Resume
              </CardTitle>
              <CardDescription>
                Supports PDF (basic), TXT, and pasted text. All parsing happens locally.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex gap-4">
                <label className="flex-1">
                  <div className="border-2 border-dashed rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors">
                    <FileText className="h-10 w-10 mx-auto text-muted-foreground mb-2" />
                    <p className="text-sm text-muted-foreground">
                      {isUploading ? 'Parsing...' : 'Click to upload PDF, TXT, or MD'}
                    </p>
                    {resume.fileName && (
                      <p className="text-sm text-primary mt-2">
                        Loaded: {resume.fileName}
                      </p>
                    )}
                  </div>
                  <input
                    type="file"
                    accept=".pdf,.txt,.md"
                    onChange={handleFileUpload}
                    className="hidden"
                    disabled={isUploading}
                  />
                </label>
              </div>

              <div className="relative">
                <Textarea
                  placeholder="Or paste your resume text here..."
                  value={resumeText}
                  onChange={(e) => handlePasteResume(e.target.value)}
                  className="min-h-[200px] font-mono text-sm"
                />
                {resumeText && (
                  <Badge className="absolute top-2 right-2" variant="secondary">
                    {resumeText.length} chars
                  </Badge>
                )}
              </div>

              {resume.skills.length > 0 && (
                <div className="p-4 bg-muted/50 rounded-lg">
                  <p className="text-sm font-medium mb-2">Extracted Skills:</p>
                  <div className="flex flex-wrap gap-1">
                    {resume.skills.map((skill, i) => (
                      <Badge key={i} variant="outline" className="text-xs">{skill}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Score Tab */}
        <TabsContent value="score" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Job Description</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    placeholder="Job Title"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                  />
                  <Input
                    placeholder="Company"
                    value={jobCompany}
                    onChange={(e) => setJobCompany(e.target.value)}
                  />
                </div>
                <Textarea
                  placeholder="Paste job description here..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  className="min-h-[250px]"
                />
                <div className="flex gap-2">
                  <Button onClick={handleScoreResume} disabled={isGenerating || !resumeText}>
                    {isGenerating ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Scoring...
                      </>
                    ) : (
                      <>
                        <Target className="h-4 w-4 mr-2" />
                        Score Match
                      </>
                    )}
                  </Button>
                  <Button variant="outline" onClick={handleSaveJob} disabled={!jobTitle}>
                    Save Job
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Match Results</CardTitle>
              </CardHeader>
              <CardContent>
                {scoreResult ? (
                  <div className="space-y-4">
                    <div className="text-center p-6 bg-muted/50 rounded-lg">
                      <div className="text-5xl font-bold mb-2">
                        {scoreResult.score}%
                      </div>
                      <Progress value={scoreResult.score} className="h-2" />
                      <p className="text-sm text-muted-foreground mt-2">
                        {scoreResult.score >= 70 ? 'Strong Match' : 
                         scoreResult.score >= 50 ? 'Moderate Match' : 'Needs Improvement'}
                      </p>
                    </div>
                    <div className="prose prose-sm dark:prose-invert max-w-none">
                      <pre className="whitespace-pre-wrap text-sm bg-background p-4 rounded-lg border">
                        {scoreResult.feedback}
                      </pre>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Score your resume against a job description</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Optimize Tab */}
        <TabsContent value="optimize" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" />
                ATS-Optimized Resume
              </CardTitle>
              <CardDescription>
                Generate an ATS-friendly version of your resume tailored to the job
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!config.isConnected && (
                <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-lg">
                  <p className="text-sm">
                    <strong>Local AI Required:</strong> Run <code className="bg-muted px-1 rounded">ollama run mistral</code> to enable AI optimization.
                  </p>
                </div>
              )}

              <Button
                onClick={handleGenerateATS}
                disabled={isGenerating || !resumeText || !jobDescription || !config.isConnected}
                className="w-full"
              >
                {isGenerating ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Generate ATS Resume
                  </>
                )}
              </Button>

              {atsResume && (
                <div className="space-y-4">
                  <div className="flex justify-end">
                    <Button variant="outline" onClick={handleDownloadATS}>
                      <Download className="h-4 w-4 mr-2" />
                      Download Markdown
                    </Button>
                  </div>
                  <div className="bg-muted/50 rounded-lg p-4 max-h-[500px] overflow-auto">
                    <pre className="whitespace-pre-wrap text-sm font-mono">
                      {atsResume}
                    </pre>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Saved Jobs Tab */}
        <TabsContent value="jobs" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Saved Jobs</CardTitle>
                <Button variant="outline" size="sm" onClick={handleExportJobs} disabled={savedJobs.length === 0}>
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {savedJobs.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <FileText className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No saved jobs yet. Score a job to save it.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {savedJobs.map((job) => (
                    <div key={job.id} className="p-4 border rounded-lg">
                      <div className="flex items-start justify-between">
                        <div>
                          <h4 className="font-medium">{job.title}</h4>
                          <p className="text-sm text-muted-foreground">{job.company}</p>
                        </div>
                        <Badge variant={job.matchScore >= 70 ? 'default' : job.matchScore >= 50 ? 'secondary' : 'outline'}>
                          {job.matchScore}%
                        </Badge>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {job.matchingSkills.slice(0, 5).map((skill, i) => (
                          <Badge key={i} variant="outline" className="text-xs bg-green-500/10">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Helper function for quick skill extraction from text
function extractSkillsFromText(text: string): string[] {
  const techSkills = [
    'JavaScript', 'TypeScript', 'Python', 'Java', 'React', 'Node.js', 'SQL',
    'AWS', 'Docker', 'Kubernetes', 'Git', 'API', 'REST', 'GraphQL',
    'Machine Learning', 'AI', 'Data Analysis', 'Agile', 'Scrum',
  ];
  
  const found = new Set<string>();
  const lower = text.toLowerCase();
  
  for (const skill of techSkills) {
    if (lower.includes(skill.toLowerCase())) {
      found.add(skill);
    }
  }
  
  return Array.from(found);
}
