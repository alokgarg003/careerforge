// ============================================================================
// Network Analytics Dashboard
// ============================================================================
// Shows AGGREGATED network statistics only. No individual data exposed.
// Demonstrates understanding of privacy-preserving analytics.
// ============================================================================

import { Users, TrendingUp, Globe, Building2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useLinkedIn } from '@/context/LinkedInContext';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

export function NetworkAnalyticsDashboard() {
  const { data, analytics } = useLinkedIn();

  if (!data.isLoaded || !analytics) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground text-center py-8">
            Upload your LinkedIn export to see network analytics
          </p>
        </CardContent>
      </Card>
    );
  }

  const { networkStats } = analytics;

  // Prepare cumulative growth data
  const cumulativeGrowth = networkStats.connectionsByMonth.reduce<{ month: string; total: number; added: number }[]>(
    (acc, curr) => {
      const prevTotal = acc.length > 0 ? acc[acc.length - 1].total : 0;
      acc.push({
        month: curr.month,
        total: prevTotal + curr.count,
        added: curr.count,
      });
      return acc;
    },
    []
  );

  return (
    <div className="space-y-6">
      {/* Privacy Notice */}
      <Card className="border-amber-500/20 bg-amber-500/5">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Badge variant="outline" className="border-amber-500 text-amber-600">Privacy Note</Badge>
            <p className="text-sm text-muted-foreground">
              All network data shown here is aggregated. Individual connection names, emails, and profile URLs 
              are explicitly excluded. This demonstrates privacy-respecting analytics.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{networkStats.totalConnections.toLocaleString()}</p>
                <p className="text-xs text-muted-foreground">Total Connections</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <TrendingUp className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{networkStats.connectionsByYear.length}</p>
                <p className="text-xs text-muted-foreground">Years Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Building2 className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{networkStats.locationDistribution.length}</p>
                <p className="text-xs text-muted-foreground">Companies Represented</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Globe className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {networkStats.connectionsByMonth.length > 0 
                    ? Math.round(networkStats.totalConnections / networkStats.connectionsByMonth.length)
                    : 0
                  }
                </p>
                <p className="text-xs text-muted-foreground">Avg/Month</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Network Growth Over Time */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Network Growth Over Time
            </CardTitle>
            <CardDescription>Cumulative connections by month</CardDescription>
          </CardHeader>
          <CardContent>
            {cumulativeGrowth.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={cumulativeGrowth}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(221, 83%, 53%)" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(221, 83%, 53%)" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => {
                      const [year, month] = value.split('-');
                      return `${month}/${year.slice(2)}`;
                    }}
                    interval="preserveStartEnd"
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    labelFormatter={(value) => `Month: ${value}`}
                  />
                  <Area
                    type="monotone"
                    dataKey="total"
                    stroke="hsl(221, 83%, 53%)"
                    fillOpacity={1}
                    fill="url(#colorTotal)"
                    name="Total Connections"
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">
                No connection timeline data available
              </p>
            )}
          </CardContent>
        </Card>

        {/* Connections by Year */}
        <Card>
          <CardHeader>
            <CardTitle>Connections by Year</CardTitle>
            <CardDescription>New connections per year</CardDescription>
          </CardHeader>
          <CardContent>
            {networkStats.connectionsByYear.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={networkStats.connectionsByYear}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="year" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(142, 71%, 45%)" radius={[4, 4, 0, 0]} name="Connections" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No yearly data available</p>
            )}
          </CardContent>
        </Card>

        {/* Top Companies in Network */}
        <Card>
          <CardHeader>
            <CardTitle>Top Companies in Network</CardTitle>
            <CardDescription>Companies represented by connections</CardDescription>
          </CardHeader>
          <CardContent>
            {networkStats.locationDistribution.length > 0 ? (
              <div className="space-y-3 max-h-[250px] overflow-y-auto pr-2">
                {networkStats.locationDistribution.slice(0, 10).map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-sm truncate max-w-[200px]">{item.location}</span>
                    <Badge variant="secondary">{item.count}</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No company data available</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Network Reflection */}
      <Card className="border-green-500/20 bg-green-500/5">
        <CardHeader>
          <CardTitle>Network Reflection</CardTitle>
          <CardDescription>System-level observations about professional network</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Network scale</p>
              <p className="text-xs text-muted-foreground">
                {networkStats.totalConnections > 500
                  ? `A robust network of ${networkStats.totalConnections.toLocaleString()} connections suggests active professional engagement.`
                  : `A focused network of ${networkStats.totalConnections.toLocaleString()} connections, indicating quality over quantity approach.`
                }
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Growth pattern</p>
              <p className="text-xs text-muted-foreground">
                {networkStats.connectionsByYear.length > 0 && (
                  <>
                    Networking activity spans {networkStats.connectionsByYear.length} years, with 
                    {networkStats.connectionsByYear[networkStats.connectionsByYear.length - 1]?.count > 
                     networkStats.connectionsByYear[0]?.count
                      ? ' increasing momentum in recent years.'
                      : ' consistent engagement over time.'}
                  </>
                )}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Privacy stance</p>
              <p className="text-xs text-muted-foreground">
                No individual identities are shown here. This analysis demonstrates how to extract 
                meaningful insights while respecting the privacy of network connections.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
