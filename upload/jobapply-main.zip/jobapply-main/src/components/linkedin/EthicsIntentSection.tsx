// ============================================================================
// Ethics & Intent Section
// ============================================================================
// Explains the purpose and ethical boundaries of this project.
// Required for demonstrating responsible data handling.
// ============================================================================

import { Shield, Eye, EyeOff, Heart, Lock, FileText } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function EthicsIntentSection() {
  return (
    <div className="space-y-6">
      {/* Main Purpose */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            Why This Project Exists
          </CardTitle>
          <CardDescription>
            A transparent explanation of intent and responsible data use
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="prose prose-sm dark:prose-invert max-w-none">
            <p className="text-muted-foreground leading-relaxed">
              This LinkedIn Career Intelligence Dashboard is a <strong>self-analysis tool</strong> built 
              for personal use and portfolio demonstration. It exists to showcase:
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg border bg-card">
              <div className="flex items-center gap-2 mb-2">
                <FileText className="h-5 w-5 text-blue-500" />
                <p className="font-medium">Analytical Thinking</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Demonstrating ability to extract meaningful insights from raw data exports 
                and present them in an actionable format.
              </p>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="flex items-center gap-2 mb-2">
                <Heart className="h-5 w-5 text-red-500" />
                <p className="font-medium">Product Sense</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Building a user-focused interface that prioritizes clarity, 
                usability, and genuine value over feature bloat.
              </p>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="flex items-center gap-2 mb-2">
                <Lock className="h-5 w-5 text-green-500" />
                <p className="font-medium">Ethical Data Handling</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Showing how to work with personal data responsibly—processing 
                client-side, excluding sensitive fields, and respecting privacy.
              </p>
            </div>
            <div className="p-4 rounded-lg border bg-card">
              <div className="flex items-center gap-2 mb-2">
                <Eye className="h-5 w-5 text-purple-500" />
                <p className="font-medium">Self-Reflection</p>
              </div>
              <p className="text-sm text-muted-foreground">
                Using career data as a mirror for understanding professional 
                growth patterns and informing future decisions.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* What's Included vs Excluded */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-green-500" />
              What IS Shown
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {[
                'My own career timeline and positions',
                'Aggregated network growth statistics',
                'Skills and endorsement counts',
                'Job application patterns (my activity)',
                'Companies I followed or applied to',
                'Education and certifications',
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <div className="h-1.5 w-1.5 rounded-full bg-green-500" />
                  {item}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <EyeOff className="h-5 w-5 text-red-500" />
              What is EXCLUDED
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {[
                'Names of individual connections',
                'Email addresses of anyone',
                'Profile URLs (mine or others)',
                'Private messages or conversations',
                'Specific content of posts or comments',
                'Any data that could identify others',
              ].map((item, index) => (
                <li key={index} className="flex items-center gap-2 text-sm">
                  <div className="h-1.5 w-1.5 rounded-full bg-red-500" />
                  {item}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Technical Safeguards */}
      <Card>
        <CardHeader>
          <CardTitle>Technical Safeguards</CardTitle>
          <CardDescription>How privacy is enforced technically</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <Badge variant="secondary" className="mb-2">Client-Side Only</Badge>
              <p className="text-sm text-muted-foreground">
                All data processing happens in your browser. Nothing is uploaded to any server. 
                Data stays on your device.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-muted/50 border">
              <Badge variant="secondary" className="mb-2">Automatic Filtering</Badge>
              <p className="text-sm text-muted-foreground">
                The parser automatically excludes fields containing emails, names, URLs, 
                and message content.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-muted/50 border">
              <Badge variant="secondary" className="mb-2">Aggregation Only</Badge>
              <p className="text-sm text-muted-foreground">
                Network data is shown only as aggregates (counts, distributions). 
                Individual records are never displayed.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* What This Is NOT */}
      <Card className="border-amber-500/20 bg-amber-500/5">
        <CardHeader>
          <CardTitle className="text-amber-700 dark:text-amber-400">
            What This Project is NOT
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {[
              'This is NOT a LinkedIn clone or alternative',
              'This does NOT scrape or fetch any live LinkedIn data',
              'This does NOT automate any LinkedIn actions',
              'This is NOT intended for analyzing other people\'s data',
              'This is NOT a surveillance or tracking tool',
            ].map((item, index) => (
              <li key={index} className="flex items-start gap-2 text-sm text-amber-800 dark:text-amber-300">
                <span className="font-bold">✗</span>
                {item}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Disclaimer */}
      <Card>
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <Badge variant="outline" className="mb-2">Self-Use Data Disclaimer</Badge>
            <p className="text-sm text-muted-foreground max-w-2xl mx-auto">
              This dashboard analyzes data from my personal LinkedIn export, which I have the right to access 
              and analyze. The data shown here is for personal career reflection and portfolio demonstration 
              purposes only. No third-party data is collected, stored, or analyzed beyond aggregated statistics 
              that do not identify individuals.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
