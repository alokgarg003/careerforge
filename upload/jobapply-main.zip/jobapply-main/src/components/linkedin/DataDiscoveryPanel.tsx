// ============================================================================
// Data Discovery Panel
// ============================================================================
// Shows what data was found in the LinkedIn export and what is being used.
// Transparency about data handling is key for ethical demonstration.
// ============================================================================

import { FileText, Check, X, AlertTriangle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useLinkedIn } from '@/context/LinkedInContext';

const categoryColors: Record<string, string> = {
  profile: 'bg-blue-500',
  connections: 'bg-green-500',
  companies: 'bg-purple-500',
  jobs: 'bg-orange-500',
  skills: 'bg-cyan-500',
  education: 'bg-indigo-500',
  activity: 'bg-red-500',
  other: 'bg-gray-500',
};

export function DataDiscoveryPanel() {
  const { data } = useLinkedIn();
  const discovery = data.dataDiscovery;

  if (!discovery) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Data Discovery
        </CardTitle>
        <CardDescription>
          Analysis of your LinkedIn export • {discovery.summary.usableFiles} of {discovery.summary.totalFiles} files used for analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px] pr-4">
          <div className="space-y-3">
            {discovery.files.map((file, index) => (
              <div
                key={index}
                className="flex items-start gap-3 p-3 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
              >
                <div className={`mt-0.5 h-2 w-2 rounded-full ${categoryColors[file.category]}`} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-sm truncate">{file.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {file.rowCount} rows
                    </Badge>
                    {file.usableForAnalysis ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <X className="h-4 w-4 text-muted-foreground" />
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Category: <span className="capitalize">{file.category}</span>
                  </p>
                  {file.privacyConcerns.length > 0 && (
                    <div className="flex items-center gap-1 mt-2">
                      <AlertTriangle className="h-3 w-3 text-amber-500" />
                      <span className="text-xs text-amber-600">
                        Excluded columns: {file.privacyConcerns.join(', ')}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        <div className="mt-4 p-3 rounded-lg bg-muted/50 border">
          <p className="text-sm font-medium">Data Range</p>
          <p className="text-xs text-muted-foreground">
            {discovery.summary.dateRange.earliest} to {discovery.summary.dateRange.latest}
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
