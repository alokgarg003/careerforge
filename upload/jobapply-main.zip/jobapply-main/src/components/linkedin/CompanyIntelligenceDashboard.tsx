// ============================================================================
// Company Intelligence Dashboard
// ============================================================================
// Shows companies followed and worked at for strategic analysis.
// Demonstrates product thinking about career decisions.
// ============================================================================

import { useState } from 'react';
import { Building, Search, MapPin, Briefcase, Filter } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useLinkedIn } from '@/context/LinkedInContext';

type InteractionFilter = 'all' | 'followed' | 'applied' | 'worked' | 'connected';

export function CompanyIntelligenceDashboard() {
  const { data } = useLinkedIn();
  const [search, setSearch] = useState('');
  const [interactionFilter, setInteractionFilter] = useState<InteractionFilter>('all');

  if (!data.isLoaded) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground text-center py-8">
            Upload your LinkedIn export to see company intelligence
          </p>
        </CardContent>
      </Card>
    );
  }

  // Combine companies from different sources
  const allCompanies = [
    ...data.companies,
    ...data.positions.map(p => ({
      name: p.companyName,
      industry: undefined,
      location: p.location,
      interactionType: 'worked' as const,
    })),
    ...data.jobApplications.map(j => ({
      name: j.companyName,
      industry: undefined,
      location: undefined,
      interactionType: 'applied' as const,
    })),
  ].filter(c => c.name);

  // Deduplicate by name
  const uniqueCompanies = Array.from(
    new Map(allCompanies.map(c => [c.name.toLowerCase(), c])).values()
  );

  // Apply filters
  const filteredCompanies = uniqueCompanies
    .filter(c => {
      if (interactionFilter !== 'all' && c.interactionType !== interactionFilter) {
        return false;
      }
      if (search && !c.name.toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      return true;
    })
    .sort((a, b) => a.name.localeCompare(b.name));

  // Stats
  const stats = {
    total: uniqueCompanies.length,
    followed: uniqueCompanies.filter(c => c.interactionType === 'followed').length,
    worked: uniqueCompanies.filter(c => c.interactionType === 'worked').length,
    applied: uniqueCompanies.filter(c => c.interactionType === 'applied').length,
  };

  const interactionColors: Record<string, string> = {
    followed: 'bg-blue-500',
    worked: 'bg-green-500',
    applied: 'bg-orange-500',
    connected: 'bg-purple-500',
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Building className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-xs text-muted-foreground">Total Companies</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <Building className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.followed}</p>
                <p className="text-xs text-muted-foreground">Followed</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <Briefcase className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.worked}</p>
                <p className="text-xs text-muted-foreground">Worked At</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Building className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.applied}</p>
                <p className="text-xs text-muted-foreground">Applied To</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search companies..."
                className="pl-9"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
            <Select value={interactionFilter} onValueChange={(v) => setInteractionFilter(v as InteractionFilter)}>
              <SelectTrigger className="w-full md:w-[200px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Interactions</SelectItem>
                <SelectItem value="followed">Followed</SelectItem>
                <SelectItem value="worked">Worked At</SelectItem>
                <SelectItem value="applied">Applied To</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Company List */}
      <Card>
        <CardHeader>
          <CardTitle>Companies ({filteredCompanies.length})</CardTitle>
          <CardDescription>Companies you have interacted with on LinkedIn</CardDescription>
        </CardHeader>
        <CardContent>
          {filteredCompanies.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[500px] overflow-y-auto pr-2">
              {filteredCompanies.map((company, index) => (
                <div
                  key={index}
                  className="p-4 rounded-lg border bg-card hover:bg-muted/50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="min-w-0 flex-1">
                      <p className="font-medium text-sm truncate">{company.name}</p>
                      {company.location && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                          <MapPin className="h-3 w-3" />
                          {company.location}
                        </p>
                      )}
                      {company.industry && (
                        <p className="text-xs text-muted-foreground mt-1">{company.industry}</p>
                      )}
                    </div>
                    <div className={`h-2 w-2 rounded-full ${interactionColors[company.interactionType]}`} />
                  </div>
                  <Badge variant="secondary" className="mt-2 text-xs capitalize">
                    {company.interactionType}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">
              No companies match your filters
            </p>
          )}
        </CardContent>
      </Card>

      {/* Company Reflection */}
      <Card className="border-purple-500/20 bg-purple-500/5">
        <CardHeader>
          <CardTitle>Company Intelligence Reflection</CardTitle>
          <CardDescription>Strategic thinking about career targets</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Why this matters</p>
              <p className="text-xs text-muted-foreground">
                Tracking company interactions helps identify patterns in career interests. 
                The ratio of followed ({stats.followed}) to applied ({stats.applied}) shows 
                research-to-action conversion in job searching.
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Strategic insight</p>
              <p className="text-xs text-muted-foreground">
                {stats.worked > 0 && (
                  <>
                    Experience across {stats.worked} organizations provides diverse perspective. 
                    {stats.applied > stats.worked * 3 
                      ? ' High application volume suggests active job market exploration.'
                      : ' Selective application strategy indicates targeted career moves.'}
                  </>
                )}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
