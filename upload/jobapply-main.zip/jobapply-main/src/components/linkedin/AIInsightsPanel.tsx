// ============================================================================
// AI Insights Panel
// ============================================================================
// Provides AI-powered career insights using local LLM (Ollama/LMStudio).
// All processing happens locally - no data leaves the browser.
// ============================================================================

import { useState, useCallback } from 'react';
import { Sparkles, Brain, RefreshCw, Settings, Check, X, Loader2, Lightbulb, Target, Users } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useLocalLLM } from '@/hooks/useLocalLLM';
import { useLinkedIn } from '@/context/LinkedInContext';

interface SavedInsight {
  id: string;
  type: 'career' | 'network' | 'custom';
  query: string;
  response: string;
  generatedAt: Date;
}

export function AIInsightsPanel() {
  const { toast } = useToast();
  const { data, analytics } = useLinkedIn();
  const {
    config,
    isGenerating,
    lastError,
    testConnection,
    generate,
    updateConfig,
    generateCareerInsight,
    analyzeNetworkForJobs,
  } = useLocalLLM();

  const [customQuery, setCustomQuery] = useState('');
  const [savedInsights, setSavedInsights] = useState<SavedInsight[]>([]);
  const [currentInsight, setCurrentInsight] = useState<string | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [tempEndpoint, setTempEndpoint] = useState(config.endpoint);
  const [tempModel, setTempModel] = useState(config.model);

  // Test AI connection
  const handleTestConnection = useCallback(async () => {
    const success = await testConnection({ endpoint: tempEndpoint, model: tempModel });
    if (success) {
      toast({ title: 'Connected', description: 'Local AI is ready' });
      setSettingsOpen(false);
    } else {
      toast({ 
        title: 'Connection Failed', 
        description: 'Start Ollama with: ollama run mistral',
        variant: 'destructive',
      });
    }
  }, [tempEndpoint, tempModel, testConnection, toast]);

  // Save settings
  const handleSaveSettings = useCallback(() => {
    updateConfig({ endpoint: tempEndpoint, model: tempModel });
    handleTestConnection();
  }, [tempEndpoint, tempModel, updateConfig, handleTestConnection]);

  // Generate career insights
  const handleCareerInsight = useCallback(async () => {
    if (!analytics) return;

    const positions = data.positions.map(p => ({
      title: p.title,
      company: p.companyName,
      years: p.startDate && p.endDate 
        ? Math.round((p.endDate.getTime() - p.startDate.getTime()) / (365.25 * 24 * 60 * 60 * 1000) * 10) / 10
        : 0,
    }));

    const skills = data.skills.map(s => s.name);
    
    const result = await generateCareerInsight(skills, positions);
    if (result) {
      setCurrentInsight(result);
      setSavedInsights(prev => [{
        id: Date.now().toString(),
        type: 'career',
        query: 'Career trajectory analysis',
        response: result,
        generatedAt: new Date(),
      }, ...prev]);
    } else {
      toast({
        title: 'Generation Failed',
        description: lastError || 'Could not generate insights',
        variant: 'destructive',
      });
    }
  }, [analytics, data.positions, data.skills, generateCareerInsight, lastError, toast]);

  // Analyze network
  const handleNetworkAnalysis = useCallback(async () => {
    // Build company connections from positions
    const connectionsByCompany: Record<string, number> = {};
    for (const pos of data.positions) {
      if (pos.companyName) {
        connectionsByCompany[pos.companyName] = (connectionsByCompany[pos.companyName] || 0) + 1;
      }
    }
    
    // Add followed companies
    for (const company of data.companies) {
      if (company.name) {
        connectionsByCompany[company.name] = (connectionsByCompany[company.name] || 0) + 1;
      }
    }

    const industries = data.connectionStats.industryDistribution.map(i => i.industry);
    const targetRole = data.positions[0]?.title || 'Senior Engineer';

    const result = await analyzeNetworkForJobs(targetRole, connectionsByCompany, industries);
    if (result) {
      setCurrentInsight(result);
      setSavedInsights(prev => [{
        id: Date.now().toString(),
        type: 'network',
        query: `Network strategy for ${targetRole}`,
        response: result,
        generatedAt: new Date(),
      }, ...prev]);
    }
  }, [data.positions, data.companies, data.connectionStats, analyzeNetworkForJobs]);

  // Custom query
  const handleCustomQuery = useCallback(async () => {
    if (!customQuery.trim()) return;

    // Build context from LinkedIn data
    const context = `
User Profile:
- Name: ${data.profile?.firstName} ${data.profile?.lastName}
- Headline: ${data.profile?.headline}
- Industry: ${data.profile?.industry}
- Location: ${data.profile?.location}

Skills (${data.skills.length}): ${data.skills.slice(0, 15).map(s => s.name).join(', ')}

Recent Positions:
${data.positions.slice(0, 3).map(p => `- ${p.title} at ${p.companyName}`).join('\n')}

Network: ${data.connectionStats.totalConnections} connections
Job Applications: ${data.jobApplications.length}
    `.trim();

    const result = await generate({ prompt: customQuery, context });
    if (result) {
      setCurrentInsight(result.text);
      setSavedInsights(prev => [{
        id: Date.now().toString(),
        type: 'custom',
        query: customQuery,
        response: result.text,
        generatedAt: new Date(),
      }, ...prev]);
      setCustomQuery('');
    }
  }, [customQuery, data, generate]);

  return (
    <div className="space-y-6">
      {/* Header with Connection Status */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Sparkles className="h-6 w-6" />
            AI Career Insights
          </h2>
          <p className="text-muted-foreground text-sm">
            Powered by local AI - your data never leaves your machine
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={config.isConnected ? 'default' : 'destructive'}>
            {config.isConnected ? (
              <>
                <Check className="h-3 w-3 mr-1" />
                {config.model}
              </>
            ) : (
              <>
                <X className="h-3 w-3 mr-1" />
                Not Connected
              </>
            )}
          </Badge>
          <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="icon">
                <Settings className="h-4 w-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Local AI Settings</DialogTitle>
                <DialogDescription>
                  Configure your local LLM connection (Ollama or LMStudio)
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div>
                  <label className="text-sm font-medium">API Endpoint</label>
                  <Input
                    value={tempEndpoint}
                    onChange={(e) => setTempEndpoint(e.target.value)}
                    placeholder="http://localhost:11434"
                  />
                </div>
                <div>
                  <label className="text-sm font-medium">Model</label>
                  <Input
                    value={tempModel}
                    onChange={(e) => setTempModel(e.target.value)}
                    placeholder="mistral"
                  />
                </div>
                <div className="p-3 bg-muted rounded-lg text-sm">
                  <p className="font-medium mb-1">Quick Start:</p>
                  <code className="text-xs">ollama run mistral</code>
                </div>
                <Button onClick={handleSaveSettings} className="w-full">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Test & Save
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Connection Guide (when not connected) */}
      {!config.isConnected && (
        <Card className="border-yellow-500/50 bg-yellow-500/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <Brain className="h-8 w-8 text-yellow-500" />
              <div>
                <h3 className="font-medium">Setup Local AI</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  Install Ollama for AI-powered insights:
                </p>
                <ol className="text-sm space-y-1 list-decimal ml-4">
                  <li>Download Ollama from <code className="bg-muted px-1 rounded">ollama.com</code></li>
                  <li>Run: <code className="bg-muted px-1 rounded">ollama run mistral</code></li>
                  <li>Click the settings icon above to test connection</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Quick Insight Buttons */}
      <div className="grid sm:grid-cols-3 gap-4">
        <Button
          variant="outline"
          className="h-auto p-4 flex flex-col items-center gap-2"
          onClick={handleCareerInsight}
          disabled={isGenerating || !data.isLoaded}
        >
          <Lightbulb className="h-6 w-6" />
          <span className="font-medium">Career Insights</span>
          <span className="text-xs text-muted-foreground">Analyze your trajectory</span>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-4 flex flex-col items-center gap-2"
          onClick={handleNetworkAnalysis}
          disabled={isGenerating || !data.isLoaded}
        >
          <Users className="h-6 w-6" />
          <span className="font-medium">Network Strategy</span>
          <span className="text-xs text-muted-foreground">Optimize for job search</span>
        </Button>

        <Button
          variant="outline"
          className="h-auto p-4 flex flex-col items-center gap-2"
          onClick={() => document.getElementById('custom-query')?.focus()}
          disabled={isGenerating || !data.isLoaded}
        >
          <Target className="h-6 w-6" />
          <span className="font-medium">Custom Query</span>
          <span className="text-xs text-muted-foreground">Ask anything</span>
        </Button>
      </div>

      {/* Custom Query Input */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex gap-2">
            <Textarea
              id="custom-query"
              placeholder="Ask about your career, skills, networking strategy, job search tips..."
              value={customQuery}
              onChange={(e) => setCustomQuery(e.target.value)}
              className="min-h-[80px]"
            />
            <Button 
              onClick={handleCustomQuery} 
              disabled={isGenerating || !customQuery.trim() || !config.isConnected}
              className="self-end"
            >
              {isGenerating ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Current Insight Display */}
      {currentInsight && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Latest Insight</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="prose prose-sm dark:prose-invert max-w-none">
              <pre className="whitespace-pre-wrap bg-muted/50 p-4 rounded-lg text-sm">
                {currentInsight}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Saved Insights History */}
      {savedInsights.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Insight History</CardTitle>
            <CardDescription>
              {savedInsights.length} insights generated this session
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {savedInsights.slice(0, 5).map((insight) => (
                <div 
                  key={insight.id} 
                  className="p-3 border rounded-lg cursor-pointer hover:bg-muted/50 transition-colors"
                  onClick={() => setCurrentInsight(insight.response)}
                >
                  <div className="flex items-center justify-between mb-1">
                    <Badge variant="outline" className="text-xs">
                      {insight.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {insight.generatedAt.toLocaleTimeString()}
                    </span>
                  </div>
                  <p className="text-sm font-medium">{insight.query}</p>
                  <p className="text-xs text-muted-foreground line-clamp-2">
                    {insight.response.slice(0, 150)}...
                  </p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
