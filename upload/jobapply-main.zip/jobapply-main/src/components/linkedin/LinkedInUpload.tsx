// ============================================================================
// LinkedIn Export Upload Component
// ============================================================================
// Handles ZIP file upload with drag-and-drop support.
// All processing happens client-side in the browser.
// ============================================================================

import { useCallback, useState } from 'react';
import { Upload, FileArchive, AlertCircle, CheckCircle, Loader2 } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useLinkedIn } from '@/context/LinkedInContext';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

export function LinkedInUpload() {
  const { loadFromFile, isLoading, error, data } = useLinkedIn();
  const { toast } = useToast();
  const [isDragOver, setIsDragOver] = useState(false);

  const handleFile = useCallback(async (file: File) => {
    if (!file.name.toLowerCase().endsWith('.zip')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload a ZIP file exported from LinkedIn.',
        variant: 'destructive',
      });
      return;
    }

    await loadFromFile(file);
    
    toast({
      title: 'Data loaded successfully',
      description: 'Your LinkedIn export has been parsed and analyzed.',
    });
  }, [loadFromFile, toast]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);

    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  }, [handleFile]);

  if (data.isLoaded) {
    return (
      <Card className="border-green-500/20 bg-green-500/5">
        <CardContent className="pt-6">
          <div className="flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-500" />
            <div>
              <p className="font-medium text-foreground">Data loaded successfully</p>
              <p className="text-sm text-muted-foreground">
                Loaded at {data.loadedAt?.toLocaleString()} • {data.dataDiscovery?.summary.totalFiles || 0} files processed
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card
      className={cn(
        'border-2 border-dashed transition-colors',
        isDragOver ? 'border-primary bg-primary/5' : 'border-muted-foreground/25',
        error && 'border-destructive/50 bg-destructive/5'
      )}
      onDragOver={(e) => { e.preventDefault(); setIsDragOver(true); }}
      onDragLeave={() => setIsDragOver(false)}
      onDrop={handleDrop}
    >
      <CardContent className="pt-6">
        <div className="flex flex-col items-center gap-4 py-8">
          {isLoading ? (
            <>
              <Loader2 className="h-12 w-12 text-primary animate-spin" />
              <div className="text-center">
                <p className="font-medium text-foreground">Processing your LinkedIn export...</p>
                <p className="text-sm text-muted-foreground">This may take a moment</p>
              </div>
            </>
          ) : error ? (
            <>
              <AlertCircle className="h-12 w-12 text-destructive" />
              <div className="text-center">
                <p className="font-medium text-destructive">Failed to parse export</p>
                <p className="text-sm text-muted-foreground">{error}</p>
              </div>
            </>
          ) : (
            <>
              <div className="p-4 rounded-full bg-primary/10">
                <FileArchive className="h-10 w-10 text-primary" />
              </div>
              <div className="text-center">
                <p className="font-medium text-foreground">Upload your LinkedIn Data Export</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Drag and drop your ZIP file here, or click to browse
                </p>
              </div>
              <label>
                <Button variant="outline" className="cursor-pointer" asChild>
                  <span>
                    <Upload className="h-4 w-4 mr-2" />
                    Select ZIP File
                  </span>
                </Button>
                <input
                  type="file"
                  accept=".zip"
                  className="hidden"
                  onChange={handleChange}
                />
              </label>
              <p className="text-xs text-muted-foreground max-w-md text-center">
                Your data is processed entirely in your browser. Nothing is uploaded to any server.
                Privacy-sensitive information is automatically filtered out.
              </p>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
