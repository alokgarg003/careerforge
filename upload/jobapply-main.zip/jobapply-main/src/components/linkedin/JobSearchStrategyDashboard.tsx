// ============================================================================
// Job Search Strategy Dashboard (Enhanced)
// ============================================================================
// Visualizes job search activity, fetches jobs from free APIs, and shows
// data-driven approach to career moves.
// ============================================================================

import { useState, useCallback } from 'react';
import { Briefcase, TrendingUp, Target, Clock, Search, Download, Loader2, ExternalLink, RefreshCw, Sparkles } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useLinkedIn } from '@/context/LinkedInContext';
import { useToast } from '@/hooks/use-toast';
import { searchAllJobAPIs, getAPIStatus, clearJobCache } from '@/lib/job-scraper';
import { generateMatchInsights, exportJobsToCSV, analyzeSkillTrends } from '@/lib/job-matching';
import { JobMatch } from '@/types/resume';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['hsl(var(--primary))', 'hsl(142, 71%, 45%)', 'hsl(262, 83%, 58%)', 'hsl(25, 95%, 53%)', 'hsl(190, 90%, 50%)'];

export function JobSearchStrategyDashboard() {
  const { data, analytics } = useLinkedIn();
  const { toast } = useToast();
  
  const [fetchedJobs, setFetchedJobs] = useState<JobMatch[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [searchProgress, setSearchProgress] = useState('');
  const [customKeywords, setCustomKeywords] = useState('');
  const [lastSearchSources, setLastSearchSources] = useState<{ name: string; count: number; success: boolean }[]>([]);

  // Get user skills from LinkedIn data
  const userSkills = data.skills.map(s => s.name);

  // Fetch jobs from free APIs
  const handleFetchJobs = useCallback(async () => {
    if (userSkills.length === 0 && !customKeywords.trim()) {
      toast({
        title: 'No skills available',
        description: 'Upload your LinkedIn data or enter custom keywords to search jobs',
        variant: 'destructive',
      });
      return;
    }

    setIsSearching(true);
    setSearchProgress('Initializing search...');

    try {
      const keywords = customKeywords.trim()
        ? customKeywords.split(',').map(k => k.trim()).filter(Boolean)
        : userSkills.slice(0, 5);

      const result = await searchAllJobAPIs(
        {
          keywords,
          remote: true,
        },
        userSkills,
        {
          maxResults: 75,
          onProgress: (source, count) => {
            setSearchProgress(`Found ${count} jobs from ${source}...`);
          },
        }
      );

      setFetchedJobs(result.jobs);
      setLastSearchSources(result.sources);

      const successfulSources = result.sources.filter(s => s.success && s.count > 0);
      toast({
        title: 'Job search complete!',
        description: `Found ${result.jobs.length} jobs from ${successfulSources.length} sources`,
      });
    } catch (error) {
      toast({
        title: 'Search failed',
        description: error instanceof Error ? error.message : 'Failed to fetch jobs',
        variant: 'destructive',
      });
    } finally {
      setIsSearching(false);
      setSearchProgress('');
    }
  }, [userSkills, customKeywords, toast]);

  // Export jobs to CSV
  const handleExportJobs = useCallback(() => {
    if (fetchedJobs.length === 0) {
      toast({ title: 'No jobs to export', variant: 'destructive' });
      return;
    }

    const csv = exportJobsToCSV(fetchedJobs);
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `job-matches-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({ title: 'Jobs exported!', description: `${fetchedJobs.length} jobs saved to CSV` });
  }, [fetchedJobs, toast]);

  // Clear cache and refresh
  const handleClearCache = useCallback(() => {
    clearJobCache();
    setFetchedJobs([]);
    setLastSearchSources([]);
    toast({ title: 'Cache cleared', description: 'Ready for fresh job search' });
  }, [toast]);

  // Generate insights from fetched jobs
  const jobInsights = generateMatchInsights(fetchedJobs, userSkills);
  const skillTrends = analyzeSkillTrends(fetchedJobs);

  if (!data.isLoaded || !analytics) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="text-center py-8 space-y-4">
            <p className="text-muted-foreground">
              Upload your LinkedIn export to see job search analytics
            </p>
            <p className="text-sm text-muted-foreground">
              Or use the search below with custom keywords
            </p>
            <div className="flex gap-2 max-w-md mx-auto">
              <Input
                placeholder="e.g., React, Python, DevOps"
                value={customKeywords}
                onChange={(e) => setCustomKeywords(e.target.value)}
              />
              <Button onClick={handleFetchJobs} disabled={isSearching}>
                {isSearching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Job role analysis
  const roleFrequency: Record<string, number> = {};
  for (const app of data.jobApplications) {
    if (app.jobTitle) {
      const normalized = app.jobTitle
        .toLowerCase()
        .replace(/senior|junior|lead|principal|staff|sr\.|jr\./gi, '')
        .trim();
      roleFrequency[normalized] = (roleFrequency[normalized] || 0) + 1;
    }
  }

  const topRoles = Object.entries(roleFrequency)
    .map(([role, count]) => ({ role, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 8);

  // Company frequency in applications
  const companyFrequency: Record<string, number> = {};
  for (const app of data.jobApplications) {
    if (app.companyName) {
      companyFrequency[app.companyName] = (companyFrequency[app.companyName] || 0) + 1;
    }
  }

  const topCompanies = Object.entries(companyFrequency)
    .map(([company, count]) => ({ company, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Funnel data
  const funnelData = [
    { stage: 'Saved Jobs', count: analytics.savedJobsCount },
    { stage: 'Applied', count: analytics.totalApplications },
  ];

  // Match score distribution for fetched jobs
  const scoreDistribution = [
    { range: '90-100', count: fetchedJobs.filter(j => j.matchScore >= 90).length },
    { range: '70-89', count: fetchedJobs.filter(j => j.matchScore >= 70 && j.matchScore < 90).length },
    { range: '50-69', count: fetchedJobs.filter(j => j.matchScore >= 50 && j.matchScore < 70).length },
    { range: '0-49', count: fetchedJobs.filter(j => j.matchScore < 50).length },
  ].filter(d => d.count > 0);

  return (
    <div className="space-y-6">
      {/* Job Search Section */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-primary" />
            Live Job Search (Free APIs)
          </CardTitle>
          <CardDescription>
            Fetch real-time job listings from Remotive, Jobicy, and Arbeitnow
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-3">
            <Input
              placeholder="Custom keywords (optional): React, Python, DevOps..."
              value={customKeywords}
              onChange={(e) => setCustomKeywords(e.target.value)}
              className="flex-1"
            />
            <div className="flex gap-2">
              <Button onClick={handleFetchJobs} disabled={isSearching}>
                {isSearching ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="h-4 w-4 mr-2" />
                    Search Jobs
                  </>
                )}
              </Button>
              <Button variant="outline" size="icon" onClick={handleClearCache} title="Clear cache">
                <RefreshCw className="h-4 w-4" />
              </Button>
              {fetchedJobs.length > 0 && (
                <Button variant="outline" size="icon" onClick={handleExportJobs} title="Export to CSV">
                  <Download className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>

          {isSearching && (
            <div className="space-y-2">
              <Progress value={33} className="h-2" />
              <p className="text-sm text-muted-foreground">{searchProgress}</p>
            </div>
          )}

          {lastSearchSources.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {lastSearchSources.map((source) => (
                <Badge
                  key={source.name}
                  variant={source.success ? 'default' : 'secondary'}
                >
                  {source.name}: {source.count} jobs
                </Badge>
              ))}
            </div>
          )}

          {/* API Status */}
          <div className="flex flex-wrap gap-2 text-xs text-muted-foreground">
            <span>Available APIs:</span>
            {getAPIStatus().map((api) => (
              <Badge key={api.name} variant="outline" className="text-xs">
                {api.name} {api.enabled ? '✓' : '✗'}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Fetched Jobs Results */}
      {fetchedJobs.length > 0 && (
        <Tabs defaultValue="jobs" className="space-y-4">
          <TabsList>
            <TabsTrigger value="jobs">
              Jobs ({fetchedJobs.length})
            </TabsTrigger>
            <TabsTrigger value="insights">
              Insights
            </TabsTrigger>
          </TabsList>

          <TabsContent value="jobs" className="space-y-4">
            {/* Score Distribution */}
            {scoreDistribution.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Match Score Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4">
                    {scoreDistribution.map((d, i) => (
                      <div key={d.range} className="text-center">
                        <div className="text-2xl font-bold" style={{ color: COLORS[i] }}>{d.count}</div>
                        <div className="text-xs text-muted-foreground">{d.range}%</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Job Cards */}
            <div className="grid gap-3 max-h-[600px] overflow-y-auto">
              {fetchedJobs.slice(0, 30).map((job) => (
                <Card key={job.id} className="hover:border-primary/50 transition-colors">
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium truncate">{job.title}</h4>
                          {job.url && (
                            <a
                              href={job.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-muted-foreground hover:text-primary"
                            >
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground">{job.company} • {job.location}</p>
                        
                        <div className="flex flex-wrap gap-1 mt-2">
                          {job.matchingSkills.slice(0, 5).map((skill) => (
                            <Badge key={skill} variant="secondary" className="text-xs bg-green-500/10 text-green-600">
                              {skill}
                            </Badge>
                          ))}
                          {job.matchingSkills.length > 5 && (
                            <Badge variant="outline" className="text-xs">
                              +{job.matchingSkills.length - 5}
                            </Badge>
                          )}
                        </div>

                        {job.missingSkills.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {job.missingSkills.slice(0, 3).map((skill) => (
                              <Badge key={skill} variant="outline" className="text-xs text-orange-500 border-orange-500/30">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>

                      <div className="text-right shrink-0">
                        <div
                          className={`text-2xl font-bold ${
                            job.matchScore >= 70 ? 'text-green-500' :
                            job.matchScore >= 50 ? 'text-yellow-500' :
                            'text-muted-foreground'
                          }`}
                        >
                          {job.matchScore}%
                        </div>
                        <p className="text-xs text-muted-foreground">Match</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {fetchedJobs.length > 30 && (
                <p className="text-center text-sm text-muted-foreground py-2">
                  Showing 30 of {fetchedJobs.length} jobs. Export to CSV to see all.
                </p>
              )}
            </div>
          </TabsContent>

          <TabsContent value="insights" className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              {/* Key Metrics */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Search Insights</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Average Match Score</span>
                    <span className="font-medium">{jobInsights.averageScore}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Jobs Analyzed</span>
                    <span className="font-medium">{fetchedJobs.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">High Match Jobs (70%+)</span>
                    <span className="font-medium">{fetchedJobs.filter(j => j.matchScore >= 70).length}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Skill Gaps */}
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Skills to Develop</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {jobInsights.skillGaps.map((skill) => (
                      <Badge key={skill} variant="outline" className="text-orange-500 border-orange-500/30">
                        {skill}
                      </Badge>
                    ))}
                    {jobInsights.skillGaps.length === 0 && (
                      <p className="text-sm text-muted-foreground">No major gaps detected!</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Trending Skills */}
              <Card className="md:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Trending Skills in Jobs</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-2">
                    {skillTrends.trending.map((skill, i) => (
                      <Badge
                        key={skill}
                        variant={i < 3 ? 'default' : 'secondary'}
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recommendations */}
              <Card className="md:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Recommendations</CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {jobInsights.recommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <span className="text-primary">→</span>
                        {rec}
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      )}

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-primary/10">
                <Briefcase className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.totalApplications}</p>
                <p className="text-xs text-muted-foreground">Applications</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <Search className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.savedJobsCount}</p>
                <p className="text-xs text-muted-foreground">Saved Jobs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Target className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{topRoles.length}</p>
                <p className="text-xs text-muted-foreground">Role Types</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Clock className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.applicationsByMonth.length}</p>
                <p className="text-xs text-muted-foreground">Active Months</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Application Timeline */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Application Activity Over Time
            </CardTitle>
            <CardDescription>Number of job applications by month</CardDescription>
          </CardHeader>
          <CardContent>
            {analytics.applicationsByMonth.length > 0 ? (
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={analytics.applicationsByMonth}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 12 }}
                    tickFormatter={(value) => {
                      const [year, month] = value.split('-');
                      return `${month}/${year.slice(2)}`;
                    }}
                  />
                  <YAxis tick={{ fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Line
                    type="monotone"
                    dataKey="count"
                    stroke="hsl(var(--primary))"
                    strokeWidth={2}
                    dot={{ fill: 'hsl(var(--primary))' }}
                    name="Applications"
                  />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">
                No application timeline data available
              </p>
            )}
          </CardContent>
        </Card>

        {/* Role Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Target Roles</CardTitle>
            <CardDescription>Most frequently applied role types</CardDescription>
          </CardHeader>
          <CardContent>
            {topRoles.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={topRoles} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" tick={{ fontSize: 12 }} />
                  <YAxis
                    type="category"
                    dataKey="role"
                    tick={{ fontSize: 10 }}
                    width={120}
                    tickFormatter={(value) => value.length > 20 ? `${value.slice(0, 20)}...` : value}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar dataKey="count" fill="hsl(262, 83%, 58%)" radius={[0, 4, 4, 0]} name="Applications" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No role data available</p>
            )}
          </CardContent>
        </Card>

        {/* Job Search Funnel */}
        <Card>
          <CardHeader>
            <CardTitle>Job Search Funnel</CardTitle>
            <CardDescription>From saved to applied</CardDescription>
          </CardHeader>
          <CardContent>
            {funnelData.some(d => d.count > 0) ? (
              <div className="space-y-6">
                {funnelData.map((stage, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>{stage.stage}</span>
                      <span className="font-medium">{stage.count}</span>
                    </div>
                    <div className="h-8 bg-muted rounded-lg overflow-hidden">
                      <div
                        className="h-full rounded-lg transition-all duration-500"
                        style={{
                          width: `${Math.max((stage.count / Math.max(...funnelData.map(d => d.count))) * 100, 10)}%`,
                          backgroundColor: COLORS[index],
                        }}
                      />
                    </div>
                  </div>
                ))}
                {analytics.savedJobsCount > 0 && analytics.totalApplications > 0 && (
                  <div className="p-3 rounded-lg bg-muted/50 border">
                    <p className="text-sm font-medium">Conversion Rate</p>
                    <p className="text-xs text-muted-foreground">
                      {Math.round((analytics.totalApplications / analytics.savedJobsCount) * 100)}% of saved jobs converted to applications
                    </p>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No funnel data available</p>
            )}
          </CardContent>
        </Card>

        {/* Top Target Companies */}
        <Card>
          <CardHeader>
            <CardTitle>Top Target Companies</CardTitle>
            <CardDescription>Companies with most applications</CardDescription>
          </CardHeader>
          <CardContent>
            {topCompanies.length > 0 ? (
              <div className="space-y-3">
                {topCompanies.map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                    <span className="text-sm truncate max-w-[200px]">{item.company}</span>
                    <Badge variant="secondary">{item.count} apps</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No company data available</p>
            )}
          </CardContent>
        </Card>

        {/* Skills Profile */}
        <Card>
          <CardHeader>
            <CardTitle>Skills Profile</CardTitle>
            <CardDescription>Your skill portfolio</CardDescription>
          </CardHeader>
          <CardContent>
            {data.skills.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {data.skills.slice(0, 20).map((skill, index) => (
                  <Badge
                    key={index}
                    variant={skill.endorsementCount && skill.endorsementCount > 5 ? 'default' : 'secondary'}
                  >
                    {skill.name}
                    {skill.endorsementCount ? ` (${skill.endorsementCount})` : ''}
                  </Badge>
                ))}
                {data.skills.length > 20 && (
                  <Badge variant="outline">+{data.skills.length - 20} more</Badge>
                )}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No skills data available</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Job Search Reflection */}
      <Card className="border-orange-500/20 bg-orange-500/5">
        <CardHeader>
          <CardTitle>Job Search Reflection</CardTitle>
          <CardDescription>Patterns observed and strategy adjustments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Patterns noticed</p>
              <p className="text-xs text-muted-foreground">
                {analytics.totalApplications > 50
                  ? `High volume of ${analytics.totalApplications} applications suggests comprehensive market exploration. Focus on ${topRoles[0]?.role || 'target roles'} is evident.`
                  : analytics.totalApplications > 0
                    ? `Selective approach with ${analytics.totalApplications} applications indicates targeted job searching.`
                    : 'Limited application data available for pattern analysis.'
                }
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Strategy insights</p>
              <p className="text-xs text-muted-foreground">
                {analytics.applicationsByMonth.length > 3
                  ? `Job search activity spans ${analytics.applicationsByMonth.length} months, showing sustained effort.`
                  : 'Concentrated job search period suggests focused campaign.'
                }
                {topCompanies.length > 0 && ` Target companies include ${topCompanies[0].company}.`}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">What I adjusted</p>
              <p className="text-xs text-muted-foreground">
                This data helps identify role focus areas and application timing patterns. 
                Understanding these metrics enables more strategic job search decisions.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
