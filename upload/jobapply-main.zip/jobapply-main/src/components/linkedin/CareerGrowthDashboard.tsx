// ============================================================================
// Career Growth Dashboard
// ============================================================================
// Visualizes career evolution: roles, skills, education, certifications.
// Includes reflection panels for self-analysis.
// ============================================================================

import { Briefcase, GraduationCap, Award, TrendingUp, Clock, Building } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useLinkedIn } from '@/context/LinkedInContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const COLORS = ['hsl(221, 83%, 53%)', 'hsl(142, 71%, 45%)', 'hsl(262, 83%, 58%)', 'hsl(25, 95%, 53%)', 'hsl(190, 90%, 50%)'];

export function CareerGrowthDashboard() {
  const { data, analytics } = useLinkedIn();

  if (!data.isLoaded || !analytics) {
    return (
      <Card>
        <CardContent className="pt-6">
          <p className="text-muted-foreground text-center py-8">
            Upload your LinkedIn export to see career growth analysis
          </p>
        </CardContent>
      </Card>
    );
  }

  const formatDate = (date: Date | null) => {
    if (!date) return 'Present';
    return date.toLocaleDateString('en-US', { month: 'short', year: 'numeric' });
  };

  return (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-blue-500/10">
                <TrendingUp className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.totalYearsExperience}</p>
                <p className="text-xs text-muted-foreground">Years Experience</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-green-500/10">
                <Briefcase className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.positionsCount}</p>
                <p className="text-xs text-muted-foreground">Positions Held</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-purple-500/10">
                <Building className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.companiesWorkedAt}</p>
                <p className="text-xs text-muted-foreground">Companies</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-orange-500/10">
                <Clock className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-2xl font-bold">{analytics.averageTenureMonths}</p>
                <p className="text-xs text-muted-foreground">Avg. Tenure (mo)</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Role Timeline */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Career Timeline
            </CardTitle>
            <CardDescription>Your professional journey</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2">
              {data.positions.length === 0 ? (
                <p className="text-muted-foreground text-sm">No position data available</p>
              ) : (
                data.positions
                  .sort((a, b) => {
                    const dateA = a.startDate?.getTime() || 0;
                    const dateB = b.startDate?.getTime() || 0;
                    return dateB - dateA;
                  })
                  .map((position, index) => (
                    <div key={index} className="relative pl-6 pb-4 border-l-2 border-muted last:pb-0">
                      <div className="absolute left-[-5px] top-0 h-2.5 w-2.5 rounded-full bg-primary" />
                      <div className="space-y-1">
                        <p className="font-medium text-sm">{position.title || 'Unknown Title'}</p>
                        <p className="text-sm text-muted-foreground">{position.companyName}</p>
                        <span className="text-xs text-muted-foreground block">
                          {formatDate(position.startDate)} — {formatDate(position.endDate)}
                          {position.isCurrent && (
                            <Badge variant="secondary" className="ml-2 text-xs">Current</Badge>
                          )}
                        </span>
                        {position.location && (
                          <p className="text-xs text-muted-foreground">{position.location}</p>
                        )}
                      </div>
                    </div>
                  ))
              )}
            </div>
          </CardContent>
        </Card>

        {/* Skills Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              Skills Distribution
            </CardTitle>
            <CardDescription>Skills by category</CardDescription>
          </CardHeader>
          <CardContent>
            {analytics.skillCategories.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={analytics.skillCategories}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={5}
                    dataKey="count"
                    nameKey="category"
                    label={({ category, count }) => `${category}: ${count}`}
                  >
                    {analytics.skillCategories.map((_, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No skills data available</p>
            )}
          </CardContent>
        </Card>

        {/* Top Skills */}
        <Card>
          <CardHeader>
            <CardTitle>Top Skills</CardTitle>
            <CardDescription>Skills with most endorsements</CardDescription>
          </CardHeader>
          <CardContent>
            {analytics.topSkills.length > 0 ? (
              <div className="space-y-3">
                {analytics.topSkills.slice(0, 8).map((skill, index) => (
                  <div key={index} className="space-y-1">
                    <div className="flex justify-between text-sm">
                      <span>{skill.skill}</span>
                      <span className="text-muted-foreground">{skill.endorsements}</span>
                    </div>
                    <Progress
                      value={(skill.endorsements / (analytics.topSkills[0]?.endorsements || 1)) * 100}
                      className="h-1.5"
                    />
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm text-center py-8">No skills data available</p>
            )}
          </CardContent>
        </Card>

        {/* Education & Certifications */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <GraduationCap className="h-5 w-5" />
              Education & Certifications
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {data.education.length > 0 && (
                <div>
                  <p className="text-sm font-medium mb-2">Education</p>
                  <div className="space-y-2">
                    {data.education.map((edu, index) => (
                      <div key={index} className="p-2 rounded-lg bg-muted/50">
                        <p className="text-sm font-medium">{edu.schoolName}</p>
                        <p className="text-xs text-muted-foreground">
                          {edu.degreeName} {edu.fieldOfStudy && `in ${edu.fieldOfStudy}`}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {data.certifications.length > 0 && (
                <div>
                  <p className="text-sm font-medium mb-2">Certifications</p>
                  <div className="flex flex-wrap gap-2">
                    {data.certifications.map((cert, index) => (
                      <Badge key={index} variant="outline">
                        {cert.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
              {data.education.length === 0 && data.certifications.length === 0 && (
                <p className="text-muted-foreground text-sm text-center py-4">
                  No education or certification data available
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reflection Panel */}
      <Card className="border-blue-500/20 bg-blue-500/5">
        <CardHeader>
          <CardTitle>Career Reflection</CardTitle>
          <CardDescription>What this data reveals about my professional journey</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">What the data shows</p>
              <p className="text-xs text-muted-foreground">
                {analytics.totalYearsExperience > 5 
                  ? `A ${analytics.totalYearsExperience}+ year career trajectory across ${analytics.companiesWorkedAt} organizations, showing consistent growth in ${analytics.skillCategories[0]?.category || 'technical'} capabilities.`
                  : `Building foundational experience across ${analytics.companiesWorkedAt} organizations with focus on ${analytics.skillCategories[0]?.category || 'core'} skills.`
                }
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Key insights</p>
              <p className="text-xs text-muted-foreground">
                Average tenure of {analytics.averageTenureMonths} months suggests 
                {analytics.averageTenureMonths > 24 ? ' commitment to deep skill development' : ' diverse experience gathering'}. 
                {analytics.topSkills.length > 5 && ` Strong competency in ${analytics.topSkills.slice(0, 3).map(s => s.skill).join(', ')}.`}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-background border">
              <p className="font-medium text-sm mb-2">Growth opportunity</p>
              <p className="text-xs text-muted-foreground">
                {analytics.skillCategories.find(c => c.category === 'Leadership')?.count 
                  ? 'Continue developing leadership capabilities alongside technical depth.'
                  : 'Consider developing leadership and management skills to complement technical expertise.'
                }
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
