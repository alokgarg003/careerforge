import React, { useState } from 'react';
import { LayoutGrid, TableIcon, Download, Trash2, Upload } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { JobCard } from './JobCard';
import { JobTable } from './JobTable';
import { JobFiltersBar } from './JobFiltersBar';
import { CSVUpload } from './CSVUpload';
import { useJobContext } from '@/context/JobContext';
import { downloadCSV } from '@/lib/csv-parser';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';

type ViewMode = 'cards' | 'table';

export const JobListings: React.FC = () => {
  const [viewMode, setViewMode] = useState<ViewMode>('cards');
  const [showUpload, setShowUpload] = useState(false);
  
  const {
    filteredJobs,
    filters,
    sort,
    stats,
    setFilters,
    setSort,
    resetFilters,
    importFromCSV,
    clearJobs,
    isLoading,
  } = useJobContext();

  const handleExport = () => {
    downloadCSV(filteredJobs);
  };

  const handleImport = (content: string): number => {
    const count = importFromCSV(content);
    if (count > 0) {
      setShowUpload(false);
    }
    return count;
  };

  return (
    <div className="space-y-6">
      {/* Header actions */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Dialog open={showUpload} onOpenChange={setShowUpload}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Upload className="h-4 w-4" />
                Import CSV
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Import Jobs from CSV</DialogTitle>
              </DialogHeader>
              <CSVUpload onUpload={handleImport} isLoading={isLoading} />
            </DialogContent>
          </Dialog>

          <Button
            variant="outline"
            className="gap-2"
            onClick={handleExport}
            disabled={filteredJobs.length === 0}
          >
            <Download className="h-4 w-4" />
            Export CSV
          </Button>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="outline"
                className="gap-2 text-destructive hover:text-destructive"
                disabled={stats.total === 0}
              >
                <Trash2 className="h-4 w-4" />
                Clear All
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Clear all jobs?</AlertDialogTitle>
                <AlertDialogDescription>
                  This will remove all {stats.total} job listings. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={clearJobs}>Clear All</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        <Tabs value={viewMode} onValueChange={(v) => setViewMode(v as ViewMode)}>
          <TabsList>
            <TabsTrigger value="cards" className="gap-2">
              <LayoutGrid className="h-4 w-4" />
              Cards
            </TabsTrigger>
            <TabsTrigger value="table" className="gap-2">
              <TableIcon className="h-4 w-4" />
              Table
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Filters */}
      <JobFiltersBar
        filters={filters}
        onFilterChange={setFilters}
        onReset={resetFilters}
        resultCount={stats.filtered}
        totalCount={stats.total}
      />

      {/* Job listings */}
      {stats.total === 0 ? (
        <div className="text-center py-16">
          <div className="max-w-md mx-auto">
            <CSVUpload onUpload={handleImport} isLoading={isLoading} />
          </div>
        </div>
      ) : viewMode === 'cards' ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredJobs.map((job) => (
            <JobCard key={job.id} job={job} />
          ))}
        </div>
      ) : (
        <JobTable jobs={filteredJobs} sort={sort} onSortChange={setSort} />
      )}

      {/* Empty state for filters */}
      {stats.total > 0 && filteredJobs.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No jobs match your filters.</p>
          <Button variant="link" onClick={resetFilters}>
            Clear all filters
          </Button>
        </div>
      )}
    </div>
  );
};
