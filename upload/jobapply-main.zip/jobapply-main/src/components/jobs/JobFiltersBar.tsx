import React from 'react';
import { Search, X, Target } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { JobFilters, JobSource, ExperienceLevel, JobType, ResumeAlignmentLevel } from '@/types/job';
import { SOURCE_LABELS, EXPERIENCE_LABELS, JOB_TYPE_LABELS, ALIGNMENT_LABELS } from '@/types/job';

interface JobFiltersBarProps {
  filters: JobFilters;
  onFilterChange: (filters: Partial<JobFilters>) => void;
  onReset: () => void;
  resultCount: number;
  totalCount: number;
}

export const JobFiltersBar: React.FC<JobFiltersBarProps> = ({
  filters,
  onFilterChange,
  onReset,
  resultCount,
  totalCount,
}) => {
  const hasActiveFilters =
    filters.search ||
    filters.source !== 'all' ||
    filters.experienceLevel !== 'all' ||
    filters.jobType !== 'all' ||
    filters.location ||
    filters.dateRange !== 'all' ||
    filters.alignmentLevel !== 'all' ||
    filters.minMatchScore > 0;

  return (
    <div className="space-y-4">
      {/* Search bar */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search jobs by title, company, skills..."
          value={filters.search}
          onChange={(e) => onFilterChange({ search: e.target.value })}
          className="pl-10 pr-10"
        />
        {filters.search && (
          <Button
            variant="ghost"
            size="sm"
            className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
            onClick={() => onFilterChange({ search: '' })}
          >
            <X className="h-4 w-4" />
          </Button>
        )}
      </div>

      {/* Filter selects */}
      <div className="flex flex-wrap gap-3 items-end">
        <Select
          value={filters.alignmentLevel}
          onValueChange={(value) => onFilterChange({ alignmentLevel: value as ResumeAlignmentLevel | 'all' })}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Alignment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Alignments</SelectItem>
            {(Object.keys(ALIGNMENT_LABELS) as ResumeAlignmentLevel[]).map((level) => (
              <SelectItem key={level} value={level}>
                {ALIGNMENT_LABELS[level]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.source}
          onValueChange={(value) => onFilterChange({ source: value as JobSource | 'all' })}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Source" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Sources</SelectItem>
            {(Object.keys(SOURCE_LABELS) as JobSource[]).map((source) => (
              <SelectItem key={source} value={source}>
                {SOURCE_LABELS[source]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.experienceLevel}
          onValueChange={(value) =>
            onFilterChange({ experienceLevel: value as ExperienceLevel | 'all' })
          }
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Experience" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            {(Object.keys(EXPERIENCE_LABELS) as ExperienceLevel[]).map((level) => (
              <SelectItem key={level} value={level}>
                {EXPERIENCE_LABELS[level]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={filters.jobType}
          onValueChange={(value) => onFilterChange({ jobType: value as JobType | 'all' })}
        >
          <SelectTrigger className="w-[150px]">
            <SelectValue placeholder="Job Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            {(Object.keys(JOB_TYPE_LABELS) as JobType[]).map((type) => (
              <SelectItem key={type} value={type}>
                {JOB_TYPE_LABELS[type]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Input
          placeholder="Location..."
          value={filters.location}
          onChange={(e) => onFilterChange({ location: e.target.value })}
          className="w-[180px]"
        />

        {/* Match Score Filter */}
        <div className="flex items-center gap-2 px-3 py-2 border rounded-md bg-background min-w-[200px]">
          <Target className="h-4 w-4 text-muted-foreground shrink-0" />
          <div className="flex-1">
            <Slider
              value={[filters.minMatchScore]}
              onValueChange={(value) => onFilterChange({ minMatchScore: value[0] })}
              max={100}
              step={5}
              className="w-full"
            />
          </div>
          <span className="text-xs text-muted-foreground w-10 text-right">
            ≥{filters.minMatchScore}%
          </span>
        </div>

        {hasActiveFilters && (
          <Button variant="outline" onClick={onReset} className="gap-2">
            <X className="h-4 w-4" />
            Clear
          </Button>
        )}
      </div>

      {/* Results count */}
      <div className="text-sm text-muted-foreground">
        Showing <span className="font-medium text-foreground">{resultCount}</span> of{' '}
        <span className="font-medium text-foreground">{totalCount}</span> jobs
      </div>
    </div>
  );
};
