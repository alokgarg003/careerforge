import React from 'react';
import { ChevronUp, ChevronDown, ExternalLink, Target } from 'lucide-react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import type { Job, JobSort, SortField } from '@/types/job';
import { SOURCE_LABELS, JOB_TYPE_LABELS, ALIGNMENT_COLORS } from '@/types/job';
import { cn } from '@/lib/utils';

interface JobTableProps {
  jobs: Job[];
  sort: JobSort;
  onSortChange: (sort: Partial<JobSort>) => void;
}

const sourceColors: Record<string, string> = {
  linkedin: 'bg-blue-500/10 text-blue-600',
  indeed: 'bg-purple-500/10 text-purple-600',
  naukri: 'bg-orange-500/10 text-orange-600',
  wellfound: 'bg-green-500/10 text-green-600',
  glassdoor: 'bg-teal-500/10 text-teal-600',
  other: 'bg-gray-500/10 text-gray-600',
};

export const JobTable: React.FC<JobTableProps> = ({ jobs, sort, onSortChange }) => {
  const handleSort = (field: SortField) => {
    if (sort.field === field) {
      onSortChange({ order: sort.order === 'asc' ? 'desc' : 'asc' });
    } else {
      onSortChange({ field, order: 'desc' });
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sort.field !== field) return null;
    return sort.order === 'asc' ? (
      <ChevronUp className="h-4 w-4 ml-1" />
    ) : (
      <ChevronDown className="h-4 w-4 ml-1" />
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-500';
    if (score >= 50) return 'text-blue-500';
    if (score >= 30) return 'text-yellow-500';
    return 'text-muted-foreground';
  };

  if (jobs.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground">
        No jobs to display. Import a CSV file to get started.
      </div>
    );
  }

  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead
              className="cursor-pointer hover:bg-muted w-[60px]"
              onClick={() => handleSort('matchScore')}
            >
              <div className="flex items-center">
                <Target className="h-4 w-4" />
                <SortIcon field="matchScore" />
              </div>
            </TableHead>
            <TableHead
              className="cursor-pointer hover:bg-muted"
              onClick={() => handleSort('title')}
            >
              <div className="flex items-center">
                Job Title
                <SortIcon field="title" />
              </div>
            </TableHead>
            <TableHead
              className="cursor-pointer hover:bg-muted"
              onClick={() => handleSort('company')}
            >
              <div className="flex items-center">
                Company
                <SortIcon field="company" />
              </div>
            </TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Alignment</TableHead>
            <TableHead>Experience</TableHead>
            <TableHead>Source</TableHead>
            <TableHead className="text-right">Action</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {jobs.map((job) => (
            <TableRow key={job.id} className="hover:bg-muted/30">
              <TableCell>
                {job.matchScore !== undefined ? (
                  <span className={cn('font-bold', getScoreColor(job.matchScore))}>
                    {job.matchScore}%
                  </span>
                ) : (
                  <span className="text-muted-foreground">-</span>
                )}
              </TableCell>
              <TableCell className="font-medium max-w-[250px]">
                <span className="line-clamp-1" title={job.title}>
                  {job.title}
                </span>
              </TableCell>
              <TableCell className="max-w-[150px]">
                <span className="line-clamp-1" title={job.company}>
                  {job.company}
                </span>
              </TableCell>
              <TableCell className="max-w-[120px]">
                <span className="line-clamp-1" title={job.location}>
                  {job.location || '-'}
                </span>
              </TableCell>
              <TableCell>
                {job.resumeAlignmentLevel && job.resumeAlignmentLevel !== 'Unknown' && (
                  <Badge 
                    variant="outline" 
                    className={cn('text-xs whitespace-nowrap border', ALIGNMENT_COLORS[job.resumeAlignmentLevel])}
                  >
                    {job.resumeAlignmentLevel}
                  </Badge>
                )}
              </TableCell>
              <TableCell>
                {job.experienceRange ? (
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {job.experienceRange}
                  </span>
                ) : (
                  '-'
                )}
              </TableCell>
              <TableCell>
                <Badge className={cn('text-xs', sourceColors[job.source])}>
                  {SOURCE_LABELS[job.source]}
                </Badge>
              </TableCell>
              <TableCell className="text-right">
                <Button variant="ghost" size="sm" asChild>
                  <a href={job.url} target="_blank" rel="noopener noreferrer">
                    <ExternalLink className="h-4 w-4" />
                  </a>
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};
