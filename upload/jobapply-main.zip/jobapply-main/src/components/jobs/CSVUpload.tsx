import React, { useRef, useState } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface CSVUploadProps {
  onUpload: (content: string) => number;
  isLoading?: boolean;
}

export const CSVUpload: React.FC<CSVUploadProps> = ({ onUpload, isLoading }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [lastCount, setLastCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFile = async (file: File) => {
    if (!file.name.endsWith('.csv')) {
      toast({
        title: 'Invalid file type',
        description: 'Please upload a CSV file',
        variant: 'destructive',
      });
      setUploadStatus('error');
      return;
    }

    try {
      const content = await file.text();
      const count = onUpload(content);
      setLastCount(count);
      setUploadStatus('success');
      
      toast({
        title: 'Import successful',
        description: `Added ${count} new job listings`,
      });
    } catch (error) {
      setUploadStatus('error');
      toast({
        title: 'Import failed',
        description: 'Failed to parse CSV file',
        variant: 'destructive',
      });
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFile(file);
  };

  return (
    <Card
      className={cn(
        'border-2 border-dashed transition-all duration-200 cursor-pointer',
        isDragging && 'border-primary bg-primary/5',
        uploadStatus === 'success' && 'border-green-500 bg-green-500/5',
        uploadStatus === 'error' && 'border-destructive bg-destructive/5'
      )}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onClick={handleClick}
    >
      <CardContent className="flex flex-col items-center justify-center py-10 gap-4">
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv"
          onChange={handleInputChange}
          className="hidden"
        />
        
        {uploadStatus === 'success' ? (
          <CheckCircle className="h-12 w-12 text-green-500" />
        ) : uploadStatus === 'error' ? (
          <AlertCircle className="h-12 w-12 text-destructive" />
        ) : (
          <div className="p-4 rounded-full bg-muted">
            <Upload className="h-8 w-8 text-muted-foreground" />
          </div>
        )}

        <div className="text-center">
          <h3 className="font-semibold text-lg">
            {uploadStatus === 'success'
              ? `${lastCount} jobs imported!`
              : uploadStatus === 'error'
              ? 'Import failed'
              : 'Import Job Data'}
          </h3>
          <p className="text-sm text-muted-foreground mt-1">
            {uploadStatus === 'idle' && 'Drag and drop a CSV file or click to browse'}
            {uploadStatus === 'success' && 'Drop another file to import more'}
            {uploadStatus === 'error' && 'Please try again with a valid CSV file'}
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <FileText className="h-4 w-4" />
          <span>Supports: CSV files with job listings</span>
        </div>
      </CardContent>
    </Card>
  );
};
