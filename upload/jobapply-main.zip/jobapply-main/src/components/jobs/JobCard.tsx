import React from 'react';
import { ExternalLink, MapPin, Briefcase, Building2, Target, AlertCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import type { Job } from '@/types/job';
import { SOURCE_LABELS, JOB_TYPE_LABELS, ALIGNMENT_COLORS } from '@/types/job';
import { cn } from '@/lib/utils';

interface JobCardProps {
  job: Job;
}

const sourceColors: Record<string, string> = {
  linkedin: 'bg-blue-500/10 text-blue-600 border-blue-200',
  indeed: 'bg-purple-500/10 text-purple-600 border-purple-200',
  naukri: 'bg-orange-500/10 text-orange-600 border-orange-200',
  wellfound: 'bg-green-500/10 text-green-600 border-green-200',
  glassdoor: 'bg-teal-500/10 text-teal-600 border-teal-200',
  other: 'bg-gray-500/10 text-gray-600 border-gray-200',
};

export const JobCard: React.FC<JobCardProps> = ({ job }) => {
  const getScoreColor = (score: number) => {
    if (score >= 70) return 'text-green-500';
    if (score >= 50) return 'text-blue-500';
    if (score >= 30) return 'text-yellow-500';
    return 'text-muted-foreground';
  };

  const getProgressColor = (score: number) => {
    if (score >= 70) return 'bg-green-500';
    if (score >= 50) return 'bg-blue-500';
    if (score >= 30) return 'bg-yellow-500';
    return 'bg-muted-foreground';
  };

  return (
    <Card className="hover:shadow-md transition-shadow duration-200 overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 min-w-0">
            {/* Header with score */}
            <div className="flex items-start justify-between gap-2 mb-2">
              <h3 className="font-semibold text-lg leading-tight line-clamp-2">
                {job.title}
              </h3>
              <div className="flex items-center gap-2 shrink-0">
                {job.matchScore !== undefined && (
                  <div className="flex items-center gap-1">
                    <Target className={cn('h-4 w-4', getScoreColor(job.matchScore))} />
                    <span className={cn('font-bold text-sm', getScoreColor(job.matchScore))}>
                      {job.matchScore}%
                    </span>
                  </div>
                )}
                <Badge
                  variant="outline"
                  className={cn('shrink-0', sourceColors[job.source])}
                >
                  {SOURCE_LABELS[job.source]}
                </Badge>
              </div>
            </div>

            {/* Match score bar */}
            {job.matchScore !== undefined && (
              <div className="mb-3">
                <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                  <div 
                    className={cn('h-full transition-all', getProgressColor(job.matchScore))}
                    style={{ width: `${job.matchScore}%` }}
                  />
                </div>
              </div>
            )}

            {/* Company & Location */}
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground mb-3">
              <span className="flex items-center gap-1.5">
                <Building2 className="h-4 w-4" />
                {job.company}
              </span>
              {job.location && (
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" />
                  {job.location}
                </span>
              )}
              {job.experienceRange && (
                <span className="text-xs bg-muted px-2 py-0.5 rounded">
                  {job.experienceRange}
                </span>
              )}
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-3">
              {job.resumeAlignmentLevel && job.resumeAlignmentLevel !== 'Unknown' && (
                <Badge 
                  variant="outline" 
                  className={cn('text-xs border', ALIGNMENT_COLORS[job.resumeAlignmentLevel])}
                >
                  {job.resumeAlignmentLevel}
                </Badge>
              )}
              {job.jobType !== 'unknown' && (
                <Badge variant="secondary" className="text-xs">
                  <Briefcase className="h-3 w-3 mr-1" />
                  {JOB_TYPE_LABELS[job.jobType]}
                </Badge>
              )}
              {job.isRemote && (
                <Badge variant="secondary" className="text-xs bg-emerald-500/10 text-emerald-600">
                  Remote
                </Badge>
              )}
            </div>

            {/* Key Skills */}
            {job.keySkills && (
              <div className="mb-3">
                <p className="text-xs text-muted-foreground mb-1">Key Skills:</p>
                <div className="flex flex-wrap gap-1">
                  {job.keySkills.split(',').slice(0, 6).map((skill, i) => (
                    <span 
                      key={i} 
                      className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded"
                    >
                      {skill.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Why this job fits */}
            {job.whyThisJobFits && (
              <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                {job.whyThisJobFits}
              </p>
            )}

            {/* Missing Skills */}
            {job.missingSkills && (
              <div className="flex items-start gap-1.5 text-xs text-amber-600">
                <AlertCircle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                <span className="line-clamp-1">Missing: {job.missingSkills}</span>
              </div>
            )}
          </div>
        </div>

        {/* Action */}
        <div className="mt-4 pt-4 border-t flex justify-end">
          <Button
            variant="outline"
            size="sm"
            className="gap-2"
            asChild
          >
            <a href={job.url} target="_blank" rel="noopener noreferrer">
              View Job
              <ExternalLink className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
