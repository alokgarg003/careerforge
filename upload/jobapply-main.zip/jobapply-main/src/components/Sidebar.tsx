import { NavLink } from "react-router-dom";
import { 
  Home, 
  Briefcase, 
  BarChart3, 
  Brain, 
  Search, 
  Sparkles,
  Shield,
  ChevronLeft,
  ChevronRight,
  Menu
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useJobContext } from "@/context/JobContext";

const navigation = [
  { 
    name: "Command Center", 
    href: "/", 
    icon: Home,
    description: "Overview & Quick Actions"
  },
  { 
    name: "Job Search", 
    href: "/jobs", 
    icon: Search,
    description: "Browse & Filter Jobs"
  },
  { 
    name: "Live Jobs", 
    href: "/live-jobs", 
    icon: Sparkles,
    description: "Real-time Job Scraping"
  },
  { 
    name: "Analytics", 
    href: "/analytics", 
    icon: BarChart3,
    description: "Data Insights"
  },
  { 
    name: "Intelligence Hub", 
    href: "/linkedin", 
    icon: Brain,
    description: "LinkedIn & Resume AI"
  },
];

export function Sidebar() {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const { stats } = useJobContext();

  return (
    <>
      {/* Mobile Header */}
      <div className="md:hidden fixed top-0 left-0 right-0 z-50 h-14 bg-sidebar border-b border-sidebar-border flex items-center px-4">
        <Button
          variant="ghost"
          size="icon"
          className="text-sidebar-foreground"
          onClick={() => setIsCollapsed(!isCollapsed)}
        >
          <Menu className="h-5 w-5" />
        </Button>
        <div className="flex items-center gap-2 ml-3">
          <div className="h-7 w-7 rounded-lg gradient-primary flex items-center justify-center">
            <Shield className="h-4 w-4 text-white" />
          </div>
          <span className="font-bold text-sidebar-foreground">Intelligence OS</span>
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div 
        className={cn(
          "hidden md:flex md:flex-col md:fixed md:inset-y-0 transition-all duration-300 z-40",
          isCollapsed ? "md:w-20" : "md:w-72"
        )}
      >
        <div className="flex flex-col flex-grow bg-sidebar overflow-y-auto scrollbar-thin">
          {/* Logo */}
          <div className={cn(
            "flex items-center h-16 px-4 border-b border-sidebar-border",
            isCollapsed ? "justify-center" : "justify-between"
          )}>
            <div className="flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center glow-primary">
                <Shield className="h-5 w-5 text-white" />
              </div>
              {!isCollapsed && (
                <div className="animate-fade-in">
                  <h1 className="text-base font-bold text-sidebar-foreground">
                    Intelligence OS
                  </h1>
                  <p className="text-[10px] text-sidebar-foreground/60">Privacy-First Career AI</p>
                </div>
              )}
            </div>
            <Button
              variant="ghost"
              size="icon"
              className={cn(
                "text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent",
                isCollapsed && "hidden"
              )}
              onClick={() => setIsCollapsed(true)}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
          </div>

          {/* Stats Banner */}
          {!isCollapsed && stats.total > 0 && (
            <div className="mx-4 mt-4 p-3 rounded-lg bg-sidebar-accent/50 border border-sidebar-border animate-fade-in">
              <div className="flex items-center justify-between text-xs">
                <span className="text-sidebar-foreground/70">Total Jobs</span>
                <span className="font-bold text-sidebar-primary">{stats.total}</span>
              </div>
              <div className="flex items-center justify-between text-xs mt-1">
                <span className="text-sidebar-foreground/70">Strong Matches</span>
                <span className="font-bold text-success">{stats.byAlignment?.['Strong Match'] || 0}</span>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 px-3 py-4 space-y-1">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    "group flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200",
                    isActive
                      ? "bg-sidebar-primary/20 text-sidebar-primary border border-sidebar-primary/30 glow-primary"
                      : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground",
                    isCollapsed && "justify-center px-2"
                  )
                }
              >
                <item.icon className={cn(
                  "h-5 w-5 shrink-0 transition-transform group-hover:scale-110",
                  isCollapsed && "h-6 w-6"
                )} />
                {!isCollapsed && (
                  <div className="flex flex-col animate-fade-in">
                    <span className="text-sm font-medium">{item.name}</span>
                    <span className="text-[10px] text-sidebar-foreground/50">
                      {item.description}
                    </span>
                  </div>
                )}
              </NavLink>
            ))}
          </nav>

          {/* Collapse Button */}
          {isCollapsed && (
            <div className="px-3 py-4">
              <Button
                variant="ghost"
                size="icon"
                className="w-full text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent"
                onClick={() => setIsCollapsed(false)}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}

          {/* Footer */}
          {!isCollapsed && (
            <div className="p-4 border-t border-sidebar-border">
              <div className="flex items-center gap-2 text-[10px] text-sidebar-foreground/50">
                <div className="h-2 w-2 rounded-full bg-success pulse-live" />
                <span>100% Local • Privacy-First</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Mobile Navigation Overlay */}
      {isCollapsed && (
        <div 
          className="md:hidden fixed inset-0 z-40 bg-background/80 backdrop-blur-sm"
          onClick={() => setIsCollapsed(false)}
        >
          <div 
            className="w-72 h-full bg-sidebar animate-slide-in-right"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Same content as desktop */}
            <div className="flex items-center h-16 px-4 border-b border-sidebar-border justify-between">
              <div className="flex items-center gap-3">
                <div className="h-9 w-9 rounded-xl gradient-primary flex items-center justify-center">
                  <Shield className="h-5 w-5 text-white" />
                </div>
                <div>
                  <h1 className="text-base font-bold text-sidebar-foreground">Intelligence OS</h1>
                  <p className="text-[10px] text-sidebar-foreground/60">Privacy-First Career AI</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="text-sidebar-foreground/70"
                onClick={() => setIsCollapsed(false)}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
            </div>
            <nav className="px-3 py-4 space-y-1">
              {navigation.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsCollapsed(false)}
                  className={({ isActive }) =>
                    cn(
                      "group flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200",
                      isActive
                        ? "bg-sidebar-primary/20 text-sidebar-primary border border-sidebar-primary/30"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                    )
                  }
                >
                  <item.icon className="h-5 w-5 shrink-0" />
                  <div className="flex flex-col">
                    <span className="text-sm font-medium">{item.name}</span>
                    <span className="text-[10px] text-sidebar-foreground/50">{item.description}</span>
                  </div>
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
