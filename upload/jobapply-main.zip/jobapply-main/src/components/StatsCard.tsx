import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'accent';
  onClick?: () => void;
}

const variantStyles = {
  default: {
    icon: 'bg-muted text-muted-foreground',
    glow: '',
  },
  primary: {
    icon: 'bg-primary/20 text-primary',
    glow: 'glow-primary',
  },
  success: {
    icon: 'bg-success/20 text-success',
    glow: 'glow-success',
  },
  warning: {
    icon: 'bg-warning/20 text-warning',
    glow: '',
  },
  accent: {
    icon: 'bg-accent/20 text-accent',
    glow: 'glow-accent',
  },
};

export function StatsCard({ 
  title, 
  value, 
  icon: Icon, 
  description, 
  trend,
  variant = 'default',
  onClick 
}: StatsCardProps) {
  const styles = variantStyles[variant];

  return (
    <Card 
      className={cn(
        "glass-hover group",
        onClick && "cursor-pointer",
        styles.glow
      )}
      onClick={onClick}
    >
      <CardContent className="pt-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <p className="text-sm font-medium text-muted-foreground">{title}</p>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold tracking-tight">{value}</span>
              {trend && (
                <span className={cn(
                  "text-xs font-medium px-1.5 py-0.5 rounded-full",
                  trend.isPositive 
                    ? "bg-success/20 text-success" 
                    : "bg-destructive/20 text-destructive"
                )}>
                  {trend.isPositive ? '+' : ''}{trend.value}%
                </span>
              )}
            </div>
            {description && (
              <p className="text-xs text-muted-foreground">{description}</p>
            )}
          </div>
          <div className={cn(
            "h-12 w-12 rounded-xl flex items-center justify-center transition-transform group-hover:scale-110",
            styles.icon
          )}>
            <Icon className="h-6 w-6" />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
